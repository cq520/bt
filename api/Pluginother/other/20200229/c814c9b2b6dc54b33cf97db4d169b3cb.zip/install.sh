#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH




#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    pip install re
    pip install requests
    pip install psutil
    pip install dnspython
    #设置777权限 避免出现因为权限不足导致添加新的服务器无法启动的现象
    sudo -i chmod -R 777 /www/server/panel/plugin/frpc/frp_client/
	sudo -i chmod -R 777 /www/server/panel/plugin/frpc/BT_Auth

	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
