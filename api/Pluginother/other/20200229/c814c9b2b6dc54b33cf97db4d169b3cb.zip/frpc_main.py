#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: Sudem <mail@szhcloud.cn>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   frp客户端管理工具
#|   Version: 2.4
#|   Logs:
#|         兼容 增强版本的 服务端

#|         修复 开机自启动的设置项目错误
#|         兼容适配 增强版本，引入 增强版本专用的启动器 BT_FRP

#+--------------------------------------------------------------------
import sys,os,json,base64,datetime,io
import re,psutil,requests,dns.resolver

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

class py_object:
      pass

class frpc_main:
    __plugin_path = "/www/server/panel/plugin/frpc/"
    __config = None
    # 构造方法
    def __init__(self):
        # 缺少授权文件 连接服务器进行授权
        # 通过授权换取准入票据, 用以和服务器通信,通过插件服务器转发请求实现服务端的远程控制
        if not os.path.exists(self.__plugin_path + 'auth.json'):
            self.Auth_Reg()
        else:
            auth = json.loads(public.ReadFile(self.__plugin_path +  'auth.json'))
            if "Plugin_Ver" not in auth:
                #删除旧版本的配置、日志文件
                os.popen("rm -rf "+self.__plugin_path+"frp_client/config")
                os.popen("rm -rf " + self.__plugin_path + "frp_client/logs")
                self.Auth_Reg()
            else:
                # 如果插件的版本发生了变化,更新授权
                info = json.loads(public.ReadFile(self.__plugin_path + 'info.json'))
                if "Plugin_Ver" in auth and info['versions'] != auth['Plugin_Ver']:
                    self.Auth_Update()
                # 如果面板的版本发生了变换,更新授权
                if "BT_Ver" in auth :
                    try:
                        if session['version'] != auth['BT_Ver']:
                            self.Auth_Update()
                    except:
                        print ("Run This Script In Shell")

                if not os.path.exists(self.__plugin_path + 'frp_client/config/'):
                    os.mkdir(self.__plugin_path + "frp_client/config")
                if not os.path.exists(self.__plugin_path + 'frp_client/logs'):
                    os.mkdir(self.__plugin_path + "frp_client/logs")

    # | ===============================
    # | 全局 管理函数
    # | ===============================


    # 将frpc设置为开机自启动
    def Service_AutoRunAdd(self, args):
        if not os.path.exists(self.__plugin_path + 'BT_frpc'):
            return {'status': 'Failed', 'msg': '错误核心配置文件丢失!'}
        if self.Service_AutoRunStatus() == 'off':
            # 复制开机启动脚本
            os.popen('cp ' + self.__plugin_path + 'BT_frpc /etc/rc.d/init.d/BT_frpc')
            # 判断系统类型
            osys = system_info()
            System = osys.GetSystemVersion()
            if re.findall(r'CentOS', System):
                # 注册开机启动
                os.popen('chkconfig --add BT_frpc')
            elif re.findall(r"Debian", System) or re.findall(r'Ubuntu', System):
                os.open('sudo update-rc.d BT_frpc defaults')
            else:
                return {'status': 'Failed', 'msg': '错误!frpc暂时不兼容您的系统开机启动'}
            return {'status': "success"}
        else:
            return {'status': 'Failed', 'msg': '错误!BT_frpc已经是开机启动项了'}

    # 查看当前系统开机启动命令的状态
    def Service_AutoRunStatus(self):
            if not os.path.exists('/etc/rc.d/init.d/BT_frpc'):
                return 'off'
            else:
                return 'on'

    # 删除当前的系统的开机启动
    def Service_AutoRunDel(self, args):
        osys = system_info()
        System = osys.GetSystemVersion()
        if  os.path.exists('/etc/rc.d/init.d/BT_frpc'):
            if re.findall(r'CentOS', System):
                # 注册开机启动
                os.popen('chkconfig --del BT_frpc')
            elif re.findall(r"Debian", System) or re.findall(r'Ubuntu', System):
                os.open('sudo update-rc.d -f BT_frpc remove')
            os.popen('rm -rf /etc/rc.d/init.d/BT_frpc')
        return {'status': 'success'}

    # 获取服务器信息列表
    def Service_List(self, args):
        server = {}
        num = 0
        files = os.listdir(self.__plugin_path + '/frp_client/config/')
        for file in files:
            info = file.split('.')
            if info[1] == 'info':
                num = num + 1
                server[num] = {}
                info = json.loads(public.ReadFile(self.__plugin_path + '/frp_client/config/' + file))['server']
                server[num]['ip'] = info['ip']
                server[num]['ServerID']=info['ServerID']
                server[num]['status'] = self.Server_Status(server[num]['ServerID'])
                server[num]['ServerTip'] = info['ServerTip']
                server[num]['ServerType'] = info['ServerType']
                if info['ServerType'] == "dev":
                    #从授权文件中读取 UserToken UserKey
                    auth = json.loads(public.ReadFile(self.__plugin_path + 'auth.json'))
                    UserToken = auth['UserToken']
                    UserKey = auth['UserKey']
                    RequestToken = public.md5(info['token']+UserToken+UserKey)
                    data = "BTToken="+info['token']+"&UserToken="+UserToken+"&RequestToken="+RequestToken
                    data = base64.b64encode(data.encode()).decode()
                    token = "v2sX5xewBJMODCrNsmlTEE7i79ly4dInpJPltpkwThgCMpwwZDaxaheskVY4aQPo"
                    token = public.md5(token+data)
                    #构造访问网址
                    url = "http://auth.iw3c.top/?api=frps_dev&fun=show&Data="+data+"&Token="+token
                    server[num]['link']="<a class=\"btlink\" target=\"_blank\" href=\""+url+"\" >FRPS 增强版</a>"
                server[num]['sport'] = info['sport']
                server[num]['lport'] = info['lport']
                server[num]['token'] = info['token']
            server['num'] = num
            server['AutoRun'] = self.Service_AutoRunStatus()
        return server

    #启动所有 frp客户端线程
    def Service_Start(self, args):
        files = os.listdir(self.__plugin_path + '/frp_client/config/')
        for file in files:
            info = file.split('.')
            if info[1] == 'info':
                ServerID = info[0]
                status = self.Server_Status(ServerID).split('_')[0]
                if status == "stop":
                    self.Server_Connect(ServerID)
        return {'status': 'success'}

    # 停止所有frp客户端线程
    def Service_Stop(self, args):
        pid = ''
        files = os.listdir(self.__plugin_path + '/frp_client/config/')
        for file in files:
            info = file.split('.')
            if info[1] == 'info':
                ServerID = info[0]
                status = self.Server_Status(ServerID).split('_')[0]
                if status == "start":
                    self.Server_DisConnect(ServerID)
        return {'status': 'success'}

    # 重启所有frp服务器
    def Service_Reload(self, args):
        self.Service_Stop("")
        self.Service_Start("")
        return  {'status': 'success'}




    # | ===============================
    # | 客户端管理函数
    # | ===============================

    # 启动某个客户端
    def Server_Start(self, args):
        args.ServerID = args.ServerID.strip()
        self.Server_Connect(args.ServerID)
        return {'status': 'success'}

    # 停止某个客户端
    def Server_Stop(self, args):
        ServerID = args.ServerID.strip()
        self.Server_DisConnect(ServerID)
        return {'status': 'success'}

    # 获得服务器的响应延迟

    def Server_Delay(self, args):
        ServerID = args.ServerID.strip()
        config = json.loads(public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'))['server']
        ip = config ['ip']
        lines = os.popen('ping -c 4 ' + ip)
        log = {}
        num = 0
        for path in lines:
            log[num] = path
            num = num + 1
        num = num - 1
        info = log[num].split('/')
        return {'status': 'success', 'delay': info[5]}

    # 添加新的客户端
    def Server_Add(self,args):
        args.ip = args.ip.strip()
        args.token = args.token.strip()
        # 生成本地客户端ID
        if args.ServerType =="dev":
            ServerID = public.md5(args.ip+public.GetRandomString(16))[0:16].upper();
        else:
            ServerID = public.md5(args.ip)[0:16].upper();
        # 检查配置文件是否已经存在
        if args.ServerType!="dev" and os.path.exists(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'):
            return {'status': 'Failed', 'msg': '错误!指定的服务器已存在'}
        # 写入配置文件
        data = json.dumps({'server': {'ip': args.ip, 'ServerTip': args.ServerTip, 'token': args.token, 'sport': args.sport,
                                      'lport': args.lport,"ServerID":ServerID,"ServerType":args.ServerType},"FRPS_ID":args.FRPS_ID,'tcp': {}, 'web': {}, 'udp': {}})
        public.WriteFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info', data)
        self.Server_Connect(ServerID)
        return {'status': 'success'}

    # 删除指定的客户端
    def Server_Delete(self,args):
        ServerID = args.ServerID
        self.Server_DisConnect(ServerID)
        os.popen("rm -rf " + self.__plugin_path + 'frp_client/config/frpc_' + ServerID + '.ini')
        os.popen("rm -rf " + self.__plugin_path + 'frp_client/config/' + ServerID + '.info')
        # 增强版服务端的节点配置信息文件
        os.popen("rm -rf " + self.__plugin_path + 'frp_client/config/' + ServerID + '.json')
        # 删除日志文件
        os.popen("rm -rf " + self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.log')
        num = 1
        while num <= 3:
            day = str(self.GetLastday(num))
            os.popen("rm -rf " + self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.' + day + '.log')
            num = num + 1
        return {'status': 'success'}

    # 连接指定的客户端
    def Server_Connect(self,ServerID):
        if self.Server_Process(ServerID) == 'dead':
            config = json.loads(public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'))['server']
            #检查连接服务端是否是增强版本的服务端
            if config['ServerType'] != "dev":
                Frp_config = '''
[common]
server_addr = %s
server_port = %s
token = %s

admin_addr = 0.0.0.0
admin_port = %s

log_file= logs/frpc_%s.log
log_level = info
log_max_days = 3
'''%(config['ip'],config['sport'],config['token'],config['lport'],ServerID)
                public.WriteFile(self.__plugin_path + 'frp_client/config/frpc_' + ServerID + '.ini', Frp_config)
                public.ExecShell('cd ' + self.__plugin_path + 'frp_client/ &&  ./frpc -c ' + self.__plugin_path + 'frp_client/config/frpc_' + ServerID + '.ini  &')
                # 重载指定客户端的节点配置
                self.Server_Proxy_Load(ServerID)
            else:
                #启动 增强版本服务端连接工具 frp_client/BT_FRP 连接
                os.popen("cd "+self.__plugin_path+"frp_client/ && ./BT_FRP -R "+config['token']+" "+ServerID +" &")


    # 断开指定的客户端的连接
    def Server_DisConnect(self, ServerID):
        # 判断指定客户端的类型
        config = json.loads(public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'))['server']
        # 检查连接服务端是否是增强版本的服务端
        if config['ServerType'] == "dev":
            #杀死增强版的宿主进程
            lines = os.popen("ps -ef | grep \"BT_FRP -R "+config['token']+" "+ServerID+"\"")
            for path in lines:
                colum = path.split()
                pid = colum[1];
                os.popen("kill " + pid);
        lines = os.popen('ps -ef | grep frpc_' + ServerID + '.ini')
        for path in lines:
            colum = path.split()
            pid = colum[1];
            os.popen("kill " + pid);

    #判断指定客户端的状态
    def Server_Status(self, ServerID):
        lines = os.popen('ps -ef | grep frpc_' + ServerID + '.ini')
        status = "stop"
        for path in lines:
            colum = path.split()
            if colum[7] == './frpc':
                status = "start"
        config = json.loads(public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'))
        if config['server']['ServerType'] == "dev":
            ServerID = config['FRPS_ID']
        # 从log中读取详细状态
        log = {}
        last = str(self.getYesterday())
        num = 1
        if os.path.exists(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.' + last + '.log'):
            file = open(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.' + last + '.log')
            for line in file:
                line = line.strip('\n')
                log[num] = line
                num = num + 1
            file.close()
        if os.path.exists(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.log'):
            file = open(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.log')
            for line in file:
                line = line.strip('\n')
                log[num] = line
                num = num + 1
            file.close()
        num = num - 1
        while status == "start" or status == "stop":
            if num == 0:
                return "stop"
            if re.findall(r'login to server success', log[num]):
                status = status + "_connect"
            if re.findall(r'connect: connection refused', log[num]):
                status = status + "_disconnect"
            if re.findall(r'connect: connection timed out', log[num]):
                status = status + "_disconnect"
            if re.findall(r'login to server failed: authorization failed', log[num]):
                status = status + "_disauth"
            num = num - 1
            if num == 0:break;
        return status



    # 获得某个服务器的日志信息
    def Server_Logs(self, args):
        ServerID = args.ServerID
        config = json.loads(public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'))
        if config['server']['ServerType'] == "dev":
            ServerID = config['FRPS_ID']
        alllogs = ""
        last = str(self.getYesterday())
        if os.path.exists(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + "." + last + '.log'):
            alllogs = public.ReadFile(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + "." + last + '.log')
        if os.path.exists(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.log'):
            alllogs = alllogs + public.ReadFile(self.__plugin_path + 'frp_client/logs/frpc_' + ServerID + '.log')
        listlogs = alllogs.split("\n")
        lens = len(listlogs)
        start = lens - 101
        logs = ""
        if start < 0:
            start = 0
        while start != (lens - 1):
            logs = logs + listlogs[start] + "\n"
            start = start + 1
        if lens == 0:
            logs = '日志文件不存在'
        return {'logs': logs}

     # 更新某个服务器的配置信息
    def Server_Update(self, args):
        ServerID = args.ServerID.strip()
        self.Server_DisConnect(ServerID)
        info = public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info')
        data = json.loads(info)
        tcp = data['tcp']
        web = data['web']
        udp = data['udp']
        data = json.dumps({'server': {'ip': args.ip, 'ServerTip': args.ServerTip, 'token': args.token, 'sport': args.sport,
                                      'lport': args.lport,"ServerID":ServerID,"ServerType":args.ServerType}, 'tcp': tcp, 'web': web, 'udp': udp})
        public.WriteFile(self.__plugin_path + 'frp_client/config/' + args.ServerID + '.info', data)
        self.Server_Connect(args.ServerID)
        return {'status': 'success'}

    #重载指定客户端的节点配置文件
    def Server_Proxy_Load(self,ServerID):
        config = json.loads(public.ReadFile(self.__plugin_path + 'frp_client/config/' + ServerID + '.info'))
        Frp_config = '''
[common]
server_addr = %s
server_port = %s
token = %s

admin_addr = 0.0.0.0
admin_port = %s

log_file= logs/frpc_%s.log
log_level = info
log_max_days = 3'''%(config['server']['ip'],config['server']['sport'],config['server']['token'],config['server']['lport'],ServerID)
        # 写入TCP的配置信息
        for Id in config['tcp']:
            if re.findall(r'-', config['tcp'][Id]['Sport']) or re.findall(r',', config['tcp'][Id]['Sport']):
                Frp_config = Frp_config + '''


[range:tcp_%s-%s_%s]'''%(config['tcp'][Id]['Sport'],config['tcp'][Id]['Lport'],Id)
            else:
                Frp_config = Frp_config + '''


[tcp_%s-%s_%s]'''%(config['tcp'][Id]['Sport'],config['tcp'][Id]['Lport'],Id)
            Frp_config = Frp_config + '''
type = tcp
local_ip = %s
local_port = %s
remote_port= %s
use_encryption = true
use_compression = true'''%(config['tcp'][Id]['Lip'], config['tcp'][Id]['Lport'], config['tcp'][Id]['Sport'])
        # 写入UDP的配置信息
        for Id in config['udp']:
            if re.findall(r'-', config['udp'][Id]['Sport']) or re.findall(r',', config['udp'][Id]['Sport']):
                Frp_config = Frp_config + '''


[range:udp_%s-%s_%s]''' % (config['udp'][Id]['Sport'], config['udp'][Id]['Lport'], Id)
            else:
                Frp_config = Frp_config + '''


[udp_%s-%s_%s]''' % (config['udp'][Id]['Sport'], config['udp'][Id]['Lport'], Id)
            Frp_config = Frp_config + '''
type = udp
local_ip = %s
local_port = %s
remote_port= %s
use_encryption = true
use_compression = true''' % (config['udp'][Id]['Lip'], config['udp'][Id]['Lport'], config['udp'][Id]['Sport'])
            # 写入WEB的配置信息
        for Id in config['web']:
            Frp_config = Frp_config + '''


[web_%s-%s_%s]'''%(config['web'][Id]['webtype'],config['web'][Id]['Domain'],Id)
            Frp_config = Frp_config + '''
type = %s
local_ip = %s
local_port = %s
custom_domains= %s
use_encryption = true
use_compression = true''' % ( config['web'][Id]['webtype'],config['web'][Id]['Lip'], config['web'][Id]['Lport'], config['web'][Id]['Domain'])

        public.WriteFile(self.__plugin_path + 'frp_client/config/frpc_' + ServerID + '.ini', Frp_config)
        public.ExecShell('cd ' + self.__plugin_path + 'frp_client/ && ./frpc reload -c ' + 'config/frpc_' + ServerID + '.ini')

    #判断指定的客户端进程是否已经启动
    def Server_Process(self,ServerID):
        lines = os.popen('ps -ef | grep frpc_' + ServerID + '.ini')
        Process = 'dead'
        for path in lines:
            colum = path.split()
            if colum[7] == './frpc':
                Process = 'live'
        return Process

    # 从授信服务器获取指定的Token 对应的配置信息
    def Server_GetTokenConfig(self,args):
        url = "http://auth.iw3c.top/?api=frps&fun=get&token=" + args.token.strip()
        response = requests.get(url).text
        try:
            data = json.loads(response)
        except:
            return {"status": "failed", "msg": "从授信服务器获取配置信息失败!未知错误!"}
        if data['status'] =="failed":
            return {"status": "failed", "msg": "从授信服务器获取配置信息失败!错误代码:"+data['code']+"msg:"+data['msg']}
        return {"status": "success", "ip": data['info']['ip'], "port": data['info']['port'] , "type": data['info']['type'],"FRPS_ID":data['info']['FRPS_ID']}

    # 检查IP地址/域名是否可以解析
    def Server_AddressCheck(self,args):
        args.Address= args.Address.strip()
        # 判断 字符串是不是ip地址
        if not self.Is_IpAddress(args.Address):
            # 通过 DNS 解析 域名ip
            res = self.DNS_IpFind(args.Address)
            if res['status'] != "success":
                return res
            else:
                ip = res['ip']
        else:
            ip = args.Address
        # 解析ip地址所在位置
        IpLocal=self.Get_Iplocal(ip)
        return {"status":"success", "IpLocal": IpLocal, "ip": ip}

    # | ===============================
    # | 节点配置函数
    # | ===============================

    # 获取指定服务器上的节点配置信息
    def Proxy_List(self, args):
        args.ID = args.ID.strip()
        if args.Type != "dev":
            if os.path.exists(self.__plugin_path + 'frp_client/config/' + args.ID + '.info'):
                info = public.ReadFile(self.__plugin_path + 'frp_client/config/' + args.ID + '.info')
            else:
                return json.dumps({'status': 'Failed', 'msg': '指定的服务器配置文件不存在'})
        else:
            if os.path.exists(self.__plugin_path + 'frp_client/config/' + args.ID + '.json'):
                info = public.ReadFile(self.__plugin_path + 'frp_client/config/' + args.ID + '.json')
            else:
                return json.dumps({'status': 'Failed', 'msg': '指定的服务器配置文件不存在'})
        data = json.loads(info)
        tcp = data['tcp']
        web = data['web']
        udp = data['udp']
        num = 1
        List = {}
        for Id in tcp:
            List.update({num: {'type': 'tcp', 'Lip': tcp[Id]['Lip'], 'Sport': tcp[Id]['Sport'],
                               'Lport': tcp[Id]['Lport'], 'info': tcp[Id]['info'], 'Id': Id}})
            num = num + 1
        for Id in udp:
            List.update({num: {'type': 'udp', 'Lip': udp[Id]['Lip'], 'Sport': udp[Id]['Sport'],
                               'Lport': udp[Id]['Lport'], 'info': udp[Id]['info'], 'Id': Id}})
            num = num + 1
        for Id in web:
            List.update({num: {'type': 'web', 'Lip': web[Id]['Lip'], 'webtype': web[Id]['webtype'],
                               'Domain': web[Id]['Domain'], 'info': web[Id]['info'], 'Id': Id}})
            num = num + 1
        return {'status': 'success', 'data': List, 'num': num - 1}

    # 添加某个节点
    def Proxy_Add(self, args):
        # 从配置文件读取json数据并转换成对象
        args.ID = args.ID.strip()
        info = public.ReadFile(self.__plugin_path + 'frp_client/config/' + args.ID + '.info')
        data = json.loads(info)
        tcp = data['tcp']
        web = data['web']
        udp = data['udp']
        server = data['server']
        Id = public.GetRandomString(6)
        if args.type == 'tcp':
            tcp.update({Id: {'type': args.type, 'Lip': args.Lip, 'Sport': args.Sport,
                                'Lport': args.Lport, 'info': args.info}})
        if args.type == 'udp':
            udp.update({Id: {'type': args.type, 'Lip': args.Lip, 'Sport': args.Sport,
                                 'Lport': args.Lport, 'info': args.info}})
        if args.type == 'web':
            if args.webtype == 'http':
                web.update({Id: {'type': args.type, 'Lip': args.Lip, 'webtype': 'http',
                                     'Domain': args.Domain, 'info': args.info, 'Lport': args.Lport}})
            if args.webtype == 'https':
                    web.update({Id: {'type': args.type, 'Lip': args.Lip, 'webtype': 'https',
                                     'Domain': args.Domain, 'info': args.info, 'Lport': args.Lport}})
            if args.webtype == 'http_https':
                Lport=args.Lport.split("-")
                web.update({Id: {'type': args.type, 'Lip': args.Lip, 'webtype': 'http',
                                 'Domain': args.Domain, 'info': args.info, 'Lport': Lport[0]}})
                Id = public.GetRandomString(6)
                web.update({Id: {'type': args.type, 'Lip': args.Lip, 'webtype': 'https',
                                     'Domain': args.Domain, 'info': args.info, 'Lport': Lport[1]}})
        info = {'server': server, 'tcp': tcp, 'udp': udp, 'web': web}
        public.WriteFile(self.__plugin_path + 'frp_client/config/' + args.ID + '.info', json.dumps(info))
        # 重载指定的服务器
        self.Server_Proxy_Load(args.ID)
        return {'status': 'success'}

     # 删除指定服务器上某个节点的配置
    def Proxy_Del(self, args):
        args.ID = args.ID.strip()
        info = public.ReadFile(self.__plugin_path + 'frp_client/config/' + args.ID + '.info')
        data = json.loads(info)
        tcp = data['tcp']
        web = data['web']
        udp = data['udp']
        server = data['server']
        for Id in tcp:
            if Id == args.Id:
                tcp.pop(Id)
                break
        for Id in udp:
            if Id == args.Id:
                udp.pop(Id)
                break
        for Id in web:
            if Id == args.Id:
                web.pop(Id)
                break
        info = {'server': server, 'tcp': tcp, 'udp': udp, 'web': web}
        public.WriteFile(self.__plugin_path + 'frp_client/config/' + args.ID + '.info', json.dumps(info))
        # 重载指定的服务器
        self.Server_Proxy_Load(args.ID)
        return {'status': 'success'}




    #| ===============================
    #| 辅助功能函数
    #| ===============================

    # 获取昨天的日期
    def getYesterday(self):
        today = datetime.date.today()
        oneday = datetime.timedelta(days=1)
        yesterday = today - oneday
        return yesterday

    # 获得 n 天前的日期
    def GetLastday(self,day):
        today = datetime.date.today()
        oneday = datetime.timedelta(days=day)
        lastday = today - oneday
        return lastday

    # 解析指定域名所对应的A记录地址
    # @domain 需要解析的域名
    def DNS_IpFind(self,domain):
        ip = '0.0.0.0'
        # log信息仅仅是系统执行except逻辑处理,无实际价值
        log = ''
        mes = ''
        record = dns.resolver.query(domain, 'A')
        try:
            for i in record.response.answer:
                for j in i.items:
                    try:
                        # 取得查询到的第一条A记录数据
                        ip = j.address
                        break
                    except:
                        log = 'Object Not An Ip Address'
        except:
            mes = 'DNS解析失败,请检查服务器DNS配置是否正确'
            return {'status': 'failed', 'mes': mes}
        if ip == '0.0.0.0.':
            mes = '没有找到此域名的A记录,请检查服务端地址是否正确'
            return {'status': 'failed', 'mes': mes}
        else:
            return {'status': 'success', 'ip': ip}

    # 判断字符串是否是ip地址
    def Is_IpAddress(self,ip):
        regex = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')
        if regex.match(ip):
            return True
        else:
            return False

    # 获取指定ip地址的位置信息
    def Get_Iplocal(self, ip):
        url = "http://v2.api.iw3c.top/?api=ip&ip=" + ip
        response = requests.get(url).text
        data = json.loads(response)['data']
        if data['Hlocal']:
            return data['Hlocal'] + "--" + data['isp']
        else:
            return data['local'] + "--" + data['isp']

        # 系统授权注册
        # Version: 2.0
        # Notice : 接入 auth.iw3c.top (V2.1),多节点支持
        #          安全优化 采用 全新的 BT_Auth 工具 避免授权授信服务器遭到攻击
        # Tip:
        #          本次更新重点 强化了对所谓开心版、破解版的处理
        #          为了保证 服务端、授信服务器的绝对安全 ,自 2.0 版本开始,宝塔面板的破解版安装本插件 将锁定远程功能
        #          锁定远程功能后 只能连接 FRPS 的基础版 和 其它自建 FRPS 服务端

    def Auth_Reg(self):
        osys = system_info()
        System_Version = osys.GetSystemVersion()
        CPU_Model = osys.GetCPUModel()
        CPU_Num = osys.GetCPUNum()
        Mac_Address = public.get_mac_address()
        BT_Version = session['version']
        info = json.loads(public.ReadFile(self.__plugin_path + 'info.json'))
        Plugin_Version = info['versions']
        data = "MAC=" + Mac_Address + "&CPU_Model=" + CPU_Model + "&CPU_Num=" + CPU_Num + "&Sys=" + System_Version+"&BT_Ver="+BT_Version+"&Plugin_Ver="+Plugin_Version
        data = base64.b64encode(data.encode()).decode()
        #执行BT_Auth 进行授权
        os.popen("cd "+self.__plugin_path +" && ./BT_Auth -A "+data);

        # 系统授权授信 更新
        # Version : 2.0
        # Tips: 当用户机器上安装的插件版本,宝塔面板版本发生改变时，为了确保数据安全，更新授权授信数据
    def Auth_Update(self):
        osys = system_info()
        Mac_Address = public.get_mac_address()
        BT_Version = session['version']
        info = json.loads(public.ReadFile(self.__plugin_path + 'info.json'))
        Plugin_Version = info['versions']
        data = "MAC="+Mac_Address+"&BT="+BT_Version+"&Plugin="+Plugin_Version;
        data = base64.b64encode(data.encode()).decode()
        auth = json.loads(public.ReadFile(self.__plugin_path + 'auth.json'))
        # 执行BT_Auth 进行授权
        os.popen("cd " + self.__plugin_path + " && ./BT_Auth -U " + data+" "+auth['UserKey']);



    def GET_FRP_VERSION(self,args):
        version = ""
        lines = os.popen("cd "+self.__plugin_path + "/frp_client && ./frpc -v" )
        for data in lines:
            version = version + data
        version = version.replace("\n","")
        return {"status":"success","version":version}


    def WinShellDownload(self,args):
        FrpVersion = self.GET_FRP_VERSION("")["version"]
        if not os.path.exists(self.__plugin_path + 'frp_client/winbuild/'):
            os.mkdir(self.__plugin_path + 'frp_client/winbuild/')
        # 从IW3C 的镜像中心下载 合适的frp win 镜像
        # 判断对应的版本文件是否存在
        if not os.path.exists(self.__plugin_path+"frp_client/winbuild/frp_"+FrpVersion+"_windows_amd64.zip"):
            download = "true"
            os.system("cd " + self.__plugin_path + "frp_client/winbuild/ &&  wget https://src.iw3c.top/disk/%E7%8E%AF%E5%A2%83/frp/frp_" + FrpVersion + "_windows_amd64.zip && unzip frp_" + FrpVersion + "_windows_amd64.zip ")
        else:
            download = "false"
            os.system("cd "+self.__plugin_path + "frp_client/winbuild && rm -rf frp_"+FrpVersion+"_windows_amd64 ")
            os.system("cd "+self.__plugin_path + "frp_client/winbuild && unzip frp_"+FrpVersion+"_windows_amd64.zip")
            os.system("cd "+self.__plugin_path + "frp_client/winbuild && rm -rf frp_window64")
        os.system("cd "+self.__plugin_path + "frp_client/winbuild && mv frp_"+FrpVersion+"_windows_amd64 frp_window64")
        #return "cd "+self.__plugin_path + "frp_client/winbuild && mv frp_"+FrpVersion+"_windows_amd64 frp_window64"
        ## 删除文件夹下不必要的文件
        os.system("cd "+self.__plugin_path + "frp_client/winbuild/frp_window64 && rm -rf systemd frpc.ini frpc_full.ini frps.exe frps.ini frps_full.ini")
        #重新加载配置文件 并复制配置文件脚本
        self.Server_Proxy_Load(args.ServerID)
        os.system("rm -rf "+self.__plugin_path + "frp_client/winbuild/frp_window64/frpc_"+args.ServerID+".ini")
        os.system("cp "+self.__plugin_path+"frp_client/config/frpc_"+args.ServerID+".ini "+self.__plugin_path + "frp_client/winbuild/frp_window64/frpc_"+args.ServerID+".ini")
        # 编写bat 脚本
        bat = '''
@echo off
echo "||=====================================================||"
echo "||FRPC Linux BT Panel Plugin (IW3C) Windows Bat Shell  ||"
echo "||=====================================================||"
echo "||         Author:Sudem mail@szhcloud.cn               ||"
echo "||         Copyright:2017-2019 iw3c.top                ||"
echo "||         Version:B_1.0_FRPC_2.5                      ||"
echo "||=====================================================||"
if not exist logs md logs
echo FRPC Program Run Success!Please Not Close This Window!
frpc.exe -c frpc_%s.ini
''' % args.ServerID
        public.WriteFile(self.__plugin_path + "frp_client/winbuild/frp_window64/autorun.bat",bat)
        zipname = args.ServerID+"_"+public.GetRandomString(16)
        # 压缩文件夹
        os.system("cd "+self.__plugin_path + "frp_client/winbuild/frp_window64  && zip -r "+zipname + ".zip ./")
        # 返回文件下载地址
        downloadurl = "download?filename="+self.__plugin_path + "frp_client/winbuild/frp_window64/"+ zipname +".zip"
        return {"status":"success","download":download,"downloadurl":downloadurl}


class   system_info:
    def GetSystemVersion(self):
        # 取操作系统版本
        import public
        version = public.readFile('/etc/redhat-release')
        if not version:
            version = public.readFile('/etc/issue').strip().split("\n")[0].replace('\\n', '').replace('\l','').strip();
        else:
            version = version.replace('release ', '').strip();
        return version

    def GetCPUModel(self):
        # 取得CPU的型号
        model = os.popen("cat /proc/cpuinfo | grep 'model name' |uniq").readlines()[0]
        model = model.split(":")[1].strip()
        return model

    def GetCPUNum(self):
        num = psutil.cpu_count()
        return str(num)


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session
#在命令行模式下 执行本脚本将自动启动全部服务器
else :
    #命令行模式 启动所有服务器
    frpc=frpc_main()
    frpc.Service_Start("")