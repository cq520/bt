#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfwebdav
#+--------------------------------------------------------------------

__all__ = ['mfwebdav_main']

import sys,os,json,re,time,math,copy

try:
    from urllib.parse import unquote
except:
    from urllib import unquote

try:
    import psutil
except:
    psutil = None

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = basedir

    

if __name__ != '__main__':
    #添加包引用位置并引用公共包
    sys.path.append("class/")
    import public
    from BTPanel import cache,session

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])
    
def GetOS():
    osname = ""
    if os.path.exists('/etc/redhat-release'):
        osname = open('/etc/redhat-release').read().split()[0]
    elif os.path.exists('/etc/issue'):
        osname = open('/etc/issue').read().split()[0]
    return osname



class mfwebdav_main:
    __plugin_path = plugin_path
    __config = None
    __webdav_pro_shell = "ps -ef |grep mfwebdav.py |grep -v grep | awk '{print $2}'"
    __OSname = GetOS()
    

    #构造方法
    def  __init__(self):
        self.__config = self.__get_config() or {"sharePath":"","username":"",
                                                "password":"","port":8008,"nomime":0
                                                }
        
    def get_webdav_pro(self):
        #L = public.ExecShell("davserver -d status")
        if not self.__OSname and psutil:
            L = ['','']
            from webdavpro import process
            
            if process['pid'] and  process['pid'].poll() is None:
                return ['running','']
            
            L = public.ExecShell('netstat -ano | findstr "0.0.0.0:%s"'%self.__config['port'])
            #print(L)
            if L[0]: return L
                
            pids = psutil.pids()
            for pid in pids:
                try:
                    p = psutil.Process(pid)
                except: #psutil.NoSuchProcess
                    continue
                name = p.name()
                if 'python' not in name or '.py' not in name: continue
                try:
                    s = ' '.join(p.cmdline())
                except: #AccessDenied: psutil.AccessDenied
                    #print ('psutil.AccessDenied',p)
                    break
                if 'mfwebdav.py' in s:
                    L = [s, '']
                    break
            
                
                # print('pid-%s,pname-%s' % (pid, p.name()))
                #if p.name() == 'dllhost.exe':
                    #cmd = 'taskkill /F /IM dllhost.exe'
                    #os.system(cmd)
        else:
            L = public.ExecShell(self.__webdav_pro_shell)
            L = L[0].strip(),L[1]
        #print(L)
        return L
        
    def index(self, args):
        d = copy.deepcopy(self.__config or {})
        d['webdav_proc'] = self.get_webdav_pro()
        return {'conf':d}

    def save_webdav_conf(self, args):
        try:
            if not os.path.isdir('/tmp'): os.mkdir('/tmp')
        except:
            pass
        sharePath = args.sharePath.strip()
        username = args.username.strip()
        password = args.password.strip()
        port = int(args.port.strip() or "8008")
        nomime = int(args.nomime) if "nomime" in args else 0
        readonly = int(args.readonly) if "readonly" in args else 0
        lock_manager = int(args.lock_manager) if "lock_manager" in args else 0
        if not sharePath or not os.path.isdir(sharePath) or sharePath[0]!='/':
            return {"status":0, "msg":"共享路径不存在"}

        
        username2 = args.username2.strip()
        password2 = args.password2.strip()
        users = {}
        if username2:
            users[username2] = {
                            "password": password2,
                            "description": "",
                            "roles": ["reader"],
                            }
        if username:
            users[username] = {
                            "password": password,
                            "description": "",
                            "roles": ["admin"],
                            }
        
        self.__config = {"sharePath":sharePath,
                         "username":username,
                         "password":password,
                         "username2":username2,
                         "password2":password2,
                         "port":port,
                         "users":users,
                         'lock_manager':lock_manager,
                         "nomime":nomime,
                         "readonly":readonly


                        }
        config_file = self.__plugin_path +'/'+ 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return {"status":1, "msg":"设置成功"}


    def getCmd(self):
        d = self.__config
        #cmd="davserver -J -D %(sharePath)s -H 0.0.0.0 -P %(port)s "
        #if d.get("username") and d.get('password'):
        #    cmd += " -u %(username)s -p %(password)s " #-d status
        #else:
        #    cmd += " -n "
        #if d.get('nomime'):
        #    cmd += " -M "
        #return cmd%d
        cmd = "python /www/server/panel/plugin/mfwebdav/mfwebdav.py --root="+d['sharePath']
        
        if self.__OSname:
            cmd = "nohup "+cmd+' >/dev/null 2>&1 &'
        #else:
        #    cmd=  "start /min "+cmd
        return cmd
        
        
    def start_webdav(self, args):
        #s = self.getCmd()+' -d start'
        #L = public.ExecShell(s)
        pro = self.get_webdav_pro()
        if pro[0]:
            return {'msg':"程序已运行，无需启动", "status":0}
        s = self.getCmd()
        
        if not self.__OSname  and psutil:
            import subprocess
            pro = subprocess.Popen(s) #, shell=True
            from webdavpro import process
            if process['pid'] :
                try:
                    process['pid'].kill()
                    process['pid'].wait()
                except:
                    pass
            
            process['pid'] = pro
            time.sleep(0.5)
            return {'msg':"程序已经启动", "status":1}
            
            #from threading import Thread #每个线程都跟主进程的pid一样
            #from multiprocessing import Process #每个进程都有不同的pid
            #动态定义函数
            #work_code = compile('def work(): return "bar"', "<string>", "exec")
            #work_func = FunctionType(work_code.co_consts[0], globals(), "work")
            #work = lambda : public.ExecShell(s)
            #Thread(target=work).start()
            #p = Process(target=work)
            #p.daemon = True
            #p.start()
        else:
            
            L = public.ExecShell(s)
        
        #print(L)
        return {'msg':"程序已经启动", "status":1}
        
        
    def reload_webdav(self, args):
        #s = self.getCmd()+' -d restart'
        self.stop_webdav(args)
        s = self.getCmd()
        L = public.ExecShell(s)
        return {'msg':"程序已经重新启动", "status":1}
        
    def stop_webdav(self, args):
        #s="""davserver -d stop """
        #L = public.ExecShell(s)
        if not self.__OSname and psutil:
            from webdavpro import process
            if process['pid'] :
                try:
                    process['pid'].kill()
                    process['pid'].wait()
                except:
                    pass
            
            
            pids = psutil.pids()
            for pid in pids:
                try:
                    p = psutil.Process(pid)
                except:
                    continue
                if 'python' not in p.name() or '.py' not in p.name(): continue
                try:
                    s = ' '.join(p.cmdline())
                except: #AccessDenied: psutil.AccessDenied
                    #print ('psutil.AccessDenied',p)
                    break
                if 'mfwebdav.py' in s:
                    p.kill()
                    break
        else:
            pro = self.get_webdav_pro()
            if pro[0]:
                L = public.ExecShell("kill -9 %s"%(pro[0]))
                #print(L)
            s="""netstat -nlp | grep :%s | awk '{print $7}' | awk -F"/" '{print $1}'"""%(self.__config['port'] or 8008)
            L = public.ExecShell(s)
            if L[0].strip():
                L = public.ExecShell("kill -9 %s"%(L[0].strip()))
                #print(L)
        return {'msg':"程序已经关闭", "status":1}
        
            

    def __get_config(self,key=None,force=False):
        if not self.__config or force:
            config_file = self.__plugin_path + '/'+ 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)
            
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config


    


    
    


        
        
    
    
        
    

