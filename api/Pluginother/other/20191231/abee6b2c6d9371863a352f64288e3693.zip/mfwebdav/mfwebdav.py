#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfwebdav
#+--------------------------------------------------------------------


from wsgidav.fs_dav_provider import FilesystemProvider
from wsgidav.wsgidav_app import WsgiDAVApp
from wsgidav import compat, util
import os
import json

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))

confPth = os.path.join(basedir, 'config.json')
with open(confPth) as f:
    conf = json.load(f)


import re
import sys
from wsgidav.server.server_cli import _init_config, _logger, use_lxml, SUPPORTED_SERVERS, run

#net use W: http://192.168.184.129:8008/ /USER:*\admin 123456
#net use Y: https://cloud.wangzhengzhen.com/remote.php/webdav  /user:qizheng /persistent:YES password
#python mfwebdav.py --host=0.0.0.0 --port=8008 --root=/www
#systemctl stop firewalld.service

def run(server=None):
    config = _init_config()
    if conf.get('port'):
        config['port'] = conf['port']
    if conf.get('host'):
        config['host'] = conf['host']
    config['host'] = '0.0.0.0'
    if not config.get('provider_mapping') or 1:
        readonly =  True if conf.get('readonly') else False
        config["provider_mapping"]={"/": FilesystemProvider(str(conf['sharePath']), readonly)}
    
    if conf.get('username') and conf.get('password') or conf.get('users'):
        '''
        config["http_authenticator"].update(
                {"accept_basic": False,
                 "accept_digest":True ,
                ## "domain_controller": "wsgidav.dc.pam_dc.PAMDomainController",
                 "default_to_digest": False}
            )
        config["pam_dc"] = {"service": "login"}
        config['hotfixes'] = {'winxp_accept_root_share_login':True}
        '''
        conf['property_manager'] = True
        if conf.get('lock_manager'):
            conf['lock_manager'] = True
            
        if not conf.get('users'):
            conf['users'] = {
                            conf['username']: {
                                "password": conf['password'],
                                "description": "",
                                "roles": ["editor"],
                            },
                        }
        print conf['users']
        config["simple_dc"].update(
                {
                    "user_mapping": {
                        "*": conf['users']
                    }
                }
            )
        
    util.init_logging(config)
    app = WsgiDAVApp(config)

    server = server or config["server"]
    
    handler = SUPPORTED_SERVERS.get(server)
    if not handler:
        raise RuntimeError(
            "Unsupported server type {!r} (expected {!r})".format(
                server, "', '".join(SUPPORTED_SERVERS.keys())
            )
        )
    if not use_lxml and config["verbose"] >= 3:
        _logger.warning(
            "Could not import lxml: using xml instead (up to 10% slower). "
            "Consider `pip install lxml`(see https://pypi.python.org/pypi/lxml)."
        )
    handler(app, config, server)


if __name__ == '__main__':
    #sys.argv[0] = re.sub(r'(-script\.pyw|\.exe)?$', '', sys.argv[0])
    try:
        sys.exit(run())
    except:
        sys.exit(run('gevent'))


'''
share_path = conf['sharePath']
provider = FilesystemProvider(share_path)

config = {
        "host": "0.0.0.0",
        "port": conf.get('port') or 8008,
        "provider_mapping": {"/": provider},
        # None: dc.simple_dc.SimpleDomainController(user_mapping)
        "http_authenticator": {"domain_controller": None},
        "simple_dc": {"user_mapping": {"*": True}},  # anonymous access
        "verbose": 1,
        "enable_loggers": [],
        "property_manager": True,  # None: no property manager
        "lock_manager": bool(conf['islock']) if 'islock' in conf else True,  # True: use lock_manager.LockManager
    }


if with_ssl:
    config.update(
        {
            "ssl_certificate": os.path.join(
                package_path, "wsgidav/server/sample_bogo_server.crt"
            ),
            "ssl_private_key": os.path.join(
                package_path, "wsgidav/server/sample_bogo_server.key"
            ),
            "ssl_certificate_chain": None,
            # "accept_digest": True,
            # "default_to_digest": True,
        }
    )


# We want output captured for tests
util.init_logging(config)

print(config)

app = WsgiDAVApp(config)

# from wsgidav.server.server_cli import _runBuiltIn
# _runBuiltIn(app, config, None)
from wsgidav.server.server_cli import _run_cheroot

_run_cheroot(app, config, "cheroot")
# blocking...

'''