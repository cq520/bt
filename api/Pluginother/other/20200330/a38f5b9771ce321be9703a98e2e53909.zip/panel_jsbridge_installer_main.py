#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发DEMO
#+--------------------------------------------------------------------
import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class panel_jsbridge_installer_main:
    __plugin_path = "/www/server/panel/plugin/demo/"
    __config = None

    #构造方法
    def  __init__(self):
        pass
    
    def getStatus(self,args):
        f=public.ReadFile("/www/server/panel/BTPanel/templates/default/layout.html",mode='r')
        g=f.find("loadScript(['/static/btJSBridge/bridge.js?_='+(new Date()).getTime()])")
        return {'code': (g!=-1) , 'data':""}
    def install(self,args):
        if(self.getStatus([])['code']==True):
            return {"status":False,"msg":"您已安装,无法重复安装"}
        if(os.path.isfile("/www/server/panel/BTPanel/static/btJSBridge/bridge.js") == False):
            return {"status":False,"msg":"主文件不存在!请去官网下载JSBridge然后按照教程操作(见项目主页)"}
        f=public.ReadFile("/www/server/panel/BTPanel/templates/default/layout.html",mode='r')
        f=f.replace("</body>","<script>loadScript(['/static/btJSBridge/bridge.js?_='+(new Date()).getTime()])</script></body>");
        result = public.WriteFile("/www/server/panel/BTPanel/templates/default/layout.html",f,mode='w+')
        if result:
            public.restart_panel()
            return {"status": True , 'msg':"启用成功！"}
        else:
            return {"status": False , 'msg':"启用失败！(写入模板文件失败)"}
    def uninstall(self,args):
        
        if(self.getStatus([])['code']==False):
            return {'status':False,"msg":"您已卸载,无法重复卸载"}
        f=public.ReadFile("/www/server/panel/BTPanel/templates/default/layout.html",mode='r')
        f=f.replace("<script>loadScript(['/static/btJSBridge/bridge.js?_='+(new Date()).getTime()])</script>","")
        result = public.WriteFile("/www/server/panel/BTPanel/templates/default/layout.html",f,mode='w+')
        if result:
            public.restart_panel()
            return {'status': True , 'msg':"禁用成功！"}
        else:
            return {'status': False , 'msg':"禁用失败！(写入模板文件失败)"}