#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author:helin <834980053@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   内网穿透frpc
#+--------------------------------------------------------------------
import sys,os,json,platform,requests,crontab,system,random,string

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public
import panelTask
t = panelTask.bt_task()
#添加计划任务库
c = crontab.crontab()
s = system.system()
import shutil

#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class freefrpc_main:
    __plugin_path = "/www/server/panel/plugin/freefrpc/"
    __config = None

    #构造方法
    def  __init__(self):
        self.server_info_url = self.__plugin_path + 'server_info.json'
        self.frpc_ini_url = '/frp/frpc.ini'
    #判断函数是否存在
    def get_frpc_info(self,args):
    	#判断文件夹并创建
    	path='/frp'
    	isExists=os.path.exists(path)
    	if not isExists:
            os.makedirs(path) 
    	
    	file_frpc='/frp/frpc'
    	file_ini='/frp/frpc.ini'
    	file_domain='/frp/domain.txt'
    	frp_info = {}
    	#判断文件是否存在
    	frp_info['frpc']=os.path.exists(file_frpc)
    	frp_info['ini']=os.path.exists(file_ini)
    	#判断程序是否运行
    	frp_info['run']=public.process_exists('frpc',exe=None)
    	#获取系统类型
    	frp_info['os'] = '获取中....'
    	#读取系统位数
    	frp_info['sysbit']= '获取中....'
    	frp_info['cpu_type'] = '获取中....'
    	frp_info['phpmyadmin'] = phpmyadmin_info()
    	#获取域名信息
    	if frp_info['run']:
    		#读取用户信息配置
    		user_info = json.loads(public.ReadFile(self.__plugin_path + '/user.json',mode='r'))
    		#server_info =json.loads(public.ReadFile(self.server_info_url,mode='r'))
    		frp_info['user_key'] = user_info['user_key']
    		frp_info['tcp_port'] = user_info['ssh_port']
    		frp_info['win_port'] = str(int(user_info['ssh_port'])+10000)
    		frp_info['subdomain'] = user_info['subdomain']
    		frp_info['domain'] = user_info
    	return frp_info
    #获取系统信息
    def get_sys_info(self,args):
    	#判断文件夹并创建
    	frp_info = {}
    	#获取系统类型
    	frp_info['os'] = get_os()
    	#读取系统位数
    	frp_info['sysbit']=platform.architecture()[0]
    	frp_info['cpu_type'] = get_cup_type()
    	return frp_info
    	#卸载frpc
    def del_frpc(self,args):
	    del_wjj='/frp'
	    	#强制删除文件夹
	    shutil.rmtree(del_wjj)
	    	#删除开机启动项的行
	    if get_os() == 'centos':
	    	do_shell = t.create_task('卸载frp',0,'sed -i "/frpc/d" /etc/rc.d/rc.local',other='')
	    elif get_os() == 'ubuntu':
	    	do_shell = t.create_task('卸载frp',0,'sed -i "/frpc/d" /etc/rc.local',other='')
	    return True
	#结束进程
    def kill_frpc(self,args):
    	do_shell=t.create_task('重载内网穿透配置',0,"kill -9 $(ps -ef | grep -E 'frpc' | grep -v grep | awk '{print$2}' )",other='')
    	return do_shell	    
    #重启frp
    def frpc_reload(self,args):
   		do_shell_nr='nohup /frp/frpc -c /frp/frpc.ini >/dev/null 2>&1 &';
   		return t.create_task('部署内网穿透',0,do_shell_nr,other='')
   		
    def load_html(self,args):
    	html_url = self.__plugin_path + '/templates/' + args.html_name
    	return public.ReadFile(html_url,mode='r')
    def load_server_info(self,args):
    	server_info_url = self.__plugin_path + 'server_info.json'
    	return json.loads(public.ReadFile(server_info_url,mode='r'))
    #获取服务商的详细信息
    def get_more(self,args):
    	server_id = args.server_id
    	server_info_url = self.__plugin_path + 'server_info.json'
    	server_info = json.loads(public.ReadFile(server_info_url,mode='r'))
    	server_more_info = {}
    	for s in server_info:
    		if s['server_id'] == server_id:
    			server_more_info = s
    	return server_more_info
    #开始部署
    def frpc_to_load(self,args):
    	#获取软件下载地址
    	frpc_down_url = self.frpc_down_url(args)
    	#获取开机自启动文件位置
    	rc_file = self.rc_file_url(args)
    	#读取数据信息
    	more_info = {}
    	more_info  = json.loads(args.pzdm)
    	#tocken 解密
    	token = decrypt(int(more_info['aes']), more_info['token'])
    	#frpc.ini配置信息
    	frpc_ini_text = '[common]\n' + 'server_addr = ' + more_info['server_addr'] + '\nserver_port = ' + more_info['server_port'] + '\ntoken = ' + token +'\nadmin_addr = 127.0.0.1\nadmin_port = 7400\nadmin_user = admin\nadmin_pwd = admin\n'
    	user_key = more_info['userid']
    	frpc_http_info = '[http_' + user_key + ']\n' + 'type = http\n' + 'local_ip = 127.0.0.1\n' + 'local_port = 80\n' + 'subdomain = ' + more_info['http_domain'] +'\n'
    	frpc_http2_info = '[http2_' + user_key + ']\n' + 'type = http\n' + 'local_ip = 127.0.0.1\n' + 'local_port = 8888\n' + 'subdomain = ' + more_info['http_domain'] +'mb\n'
    	frpc_https_info = '[https_' + user_key + ']\n' + 'type = https\n' + 'local_ip = 127.0.0.1\n' + 'local_port = 80\n' + 'subdomain = ' + more_info['https_domain'] +'\n'
    	frpc_phpmyadmin_info = '[http3_' + user_key + ']\n' + 'type = http\n' + 'local_ip = 127.0.0.1\n' + 'local_port = 888\n' + 'subdomain = ' + more_info['http_domain'] +'sql\n'
    	#ssh端口信息
    	ssh_port = more_info['tcpport']
    	frpc_ssh_port = '[ssh_' + user_key + ']\ntype = tcp\nlocal_ip = 127.0.0.1\nlocal_port = 22\nremote_port = ' + ssh_port +'\n'
    	#win远程链接
    	#win_port= str(int(ssh_port)+10000)
    	#frpc_win_port = '[win_' + user_key + ']\ntype = tcp\nlocal_ip = 127.0.0.1\nlocal_port = 3389\nremote_port = ' + win_port +'\n'
    	
    	
    	frpc_ini = frpc_ini_text + frpc_http_info + frpc_http2_info + frpc_https_info + frpc_phpmyadmin_info + frpc_ssh_port #+ frpc_win_port
    	#信息写入配置文件
    	frpc_ini_file='/frp/frpc.ini'
    	fo = open(frpc_ini_file, "w")
    	fo.write( frpc_ini)
    	fo.close()
    	#信息写入个人配置文件
    	user_ini_file=self.__plugin_path + 'user.json'
    	#user_server_id = args.server_id
    	fo = open(user_ini_file, "w")
    	user_ini_info = {}
    	#user_ini_info['server_id']=user_server_id
    	user_ini_info['user_key']=user_key
    	user_ini_info['systype']=args.systype
    	user_ini_info['cputype']=args.cputype
    	user_ini_info['sysbit']=args.sysbit
    	user_ini_info['httpdk'] = more_info['http_prot']
    	#http本地端口
    	user_ini_info['http_local_prot'] = 80
    	user_ini_info['httpsdk'] = more_info['https_prot']
    	user_ini_info['https_local_prot'] = 80
    	user_ini_info['mb_local_prot'] = 8888
    	user_ini_info['phpmyadmin_local_prot'] = 888
    	user_ini_info['server_addr']=more_info['server_addr']
    	user_ini_info['server_port']=more_info['server_port']
    	user_ini_info['token']=token
    	user_ini_info['ssh_port'] = ssh_port
    	user_ini_info['subdomain'] = more_info['subdomain']
    	user_ini_info['http_domain'] = more_info['http_domain']
    	user_ini_info['https_domain'] = more_info['https_domain']
    	fo.write(json.dumps(user_ini_info))
    	fo.close()
    	#添加计划任务库
    	if args.frpcfdx == 'yes':
    		self.frpc_fdx(args)
    	#下载软件并赋予权限
    	shell_nr = 'wget -P /frp/  ' + frpc_down_url + '\nchmod a+x /frp/frpc  \nnohup /frp/frpc -c /frp/frpc.ini >/dev/null 2>&1 &'
    	if args.autoopen == 'yes':
    		shell_nr = shell_nr + 'sed -i "/exit 0/d" /etc/rc.local\necho "nohup /frp/frpc -c /frp/frpc.ini >/dev/null 2>&1 &" >> '+rc_file+'\necho "exit 0" >> '+rc_file
    	
    	return t.create_task('部署内网穿透软件',0,shell_nr,other='')

    	
    def frpc_down_url(self,args):
    	base_url = 'http://api.yunwk.top/frp/'
    	if args.sysbit == '64' and args.cputype == 'arm':
    		base_url = base_url + 'frp_arm64/frpc'
    	if args.sysbit == '32' and args.cputype == 'arm':
    		base_url = base_url + 'frp_arm/frpc'
    	if args.sysbit == '64' and args.cputype == 'x86':
    		base_url = base_url + 'frp_amd64/frpc'
    	if args.sysbit == '32' and args.cputype == 'x86':
    		base_url = base_url + 'frp_amd/frpc'
    	return base_url
    #自启动文件位置
    def rc_file_url(self,args):
    	rc_url = ''
    	if args.systype == 'ubuntu':
    		rc_url = '/etc/rc.local'
    	if args.systype == 'centos':
    		rc_url = '/etc/rc.d/rc.local'
    	return rc_url
    	
    #自定义配置修改
    def user_ym_ini(self,args):
    	user_ini_file=self.__plugin_path + 'user.json'
    	user_ini = json.loads(public.ReadFile(user_ini_file,mode='r'))
    	user_ini['httpym'] = args.httpym
    	user_ini['http_local_prot'] = args.httpdk
    	user_ini['httpsym'] = args.httpsym
    	user_ini['https_local_prot'] = args.httpsdk
    	user_ini['httpym2'] = args.httpym2
    	user_ini['mb_local_prot'] = args.httpdk2
    	user_ini['sjkglym'] = args.sjkglym
    	user_ini['phpmyadmin_local_prot'] = args.pmadk
    	user_ini['sshdk'] = args.sshdk
    	
    	fo = open(user_ini_file, "w")
    	fo.write(json.dumps(user_ini))
    	fo.close()
    	#修改配置文件信息
    	frpc_ini_text = '[common]\n' + 'server_addr = ' + user_ini['server_addr'] + '\nserver_port = ' + user_ini['server_port'] + '\ntoken = ' + user_ini['token'] +'\nadmin_addr = 127.0.0.1\nadmin_port = 7400\nadmin_user = admin\nadmin_pwd = admin\n'
    	frpc_http_info = '[http_' + user_ini['user_key'] + ']\n' + 'type = http\n' + 'local_ip = 127.0.0.1\n' + 'local_port = '+ user_ini['http_local_prot'] +'\n' + 'subdomain = ' + user_ini['http_domain'] +'\n' + 'custom_domains =' + user_ini['httpym'] +'\n'
    	frpc_http2_info = '[http2_' + user_ini['user_key'] + ']\n' + 'type = http\n' + 'local_ip = 127.0.0.1\n' + 'local_port = '+ user_ini['mb_local_prot'] +'\n' + 'subdomain = ' + user_ini['http_domain'] +'mb\n' + 'custom_domains =' + user_ini['httpym2'] +'\n'
    	frpc_https_info = '[https_' + user_ini['user_key'] + ']\n' + 'type = https\n' + 'local_ip = 127.0.0.1\n' + 'local_port = '+ user_ini['https_local_prot'] +'\n' + 'subdomain = ' + user_ini['https_domain'] +'\n' + 'custom_domains =' + user_ini['httpsym'] +'\n'
    	frpc_phpmyadmin_info = '[http3_' + user_ini['user_key'] + ']\n' + 'type = http\n' + 'local_ip = 127.0.0.1\n' + 'local_port = '+ user_ini['phpmyadmin_local_prot'] +'\n' + 'subdomain = ' + user_ini['http_domain'] +'sql\n'  + 'custom_domains =' + user_ini['sjkglym'] +'\n'
    	
    	frpc_ssh_port = '[ssh_' + user_ini['user_key'] + ']\ntype = tcp\nlocal_ip = 127.0.0.1\nlocal_port = '+ user_ini['sshdk'] +'\nremote_port = ' + user_ini['ssh_port'] +'\n'
    	
    	#win_port = str(int(user_ini['ssh_port'])+10000)
    	#frpc_win_port = '[win_' + user_ini['user_key'] + ']\ntype = tcp\nlocal_ip = 127.0.0.1\nlocal_port = 3389' +'\nremote_port = ' + win_port +'\n'
    	
    	
    	frpc_ini = frpc_ini_text + frpc_http_info + frpc_http2_info + frpc_https_info + frpc_phpmyadmin_info + frpc_ssh_port #+ frpc_win_port
    	
    	
    	frpc_ini_file='/frp/frpc.ini'
    	fo = open(frpc_ini_file, "w")
    	fo.write( frpc_ini)
    	fo.close()
    	#重启内网穿透
    	shell_nr='/frp/frpc reload -c /frp/frpc.ini'
   		#s_i_r=t.create_task('重载内网穿透配置',0,shell_nr,other='')
    	return t.create_task('内网穿透重启',0,shell_nr,other='')
    #获取用户自定义域名信息
    def get_user_ym_info(self,args):
    	user_ini_file=self.__plugin_path + 'user.json'
    	user_ini = json.loads(public.ReadFile(user_ini_file,mode='r'))
    	return user_ini
    	
    def frpc_fdx(self,args):
    	crontab_ini={}
    	crontab_ini['name']='内网穿透防掉线'
    	crontab_ini['type']='minute-n'
    	crontab_ini['where1']=10
    	crontab_ini['hour']=''
    	crontab_ini['minute']=''
    	crontab_ini['week']=''
    	crontab_ini['save']=''
    	crontab_ini['backupTo']='localhost'
    	crontab_ini['sType']='toShell'
    	crontab_ini['sName']='frpcfdx'
    	crontab_ini['sBody']='ps -fe|grep frpc |grep -v grep\nif [ $? -ne 0 ] ;\nthen\necho "启动内网穿透....."\nnohup /frp/frpc -c /frp/frpc.ini >/dev/null 2>&1 &\nelse\necho "内网穿透运行中....."\nfi'
    	crontab_ini['urladdress']=''
    	#创建计划任务
    	return_nr = c.AddCrontab(crontab_ini)
    	return True
    #用户添加自己的服务器
    def add_server_info(self,args):
    	#读取原来的信息
    	server_info = {}
    	server_info = json.loads(public.ReadFile(self.server_info_url,mode='r'))
    	new_server = {}
    	new_server['server_id'] = str(random.randint(100,200))
    	new_server['server_name'] = args.sname
    	new_server['server_addr'] = args.saddr
    	new_server['server_port'] = args.sport
    	new_server['token'] = args.stoken
    	new_server['subdomain_host'] = args.sym
    	new_server['vhost_http_port'] = args.httpdk
    	new_server['vhost_https_port'] = args.httpsdk
    	new_server['tcp_begin_port'] = args.stcpb
    	new_server['tcp_end_port'] = args.stcpe
    	new_server['server_area'] = '用户自定义区域'
    	new_server['tips'] = args.stips
    	server_info.append(new_server)
    	#写回配置文件中去
    	fo = open(self.server_info_url, "w")
    	fo.write(json.dumps(server_info))
    	fo.close()
    	return True
    		
#获取os   		
def get_os():
    os_info={}
    os_info['status']=True
    syst = s.GetSystemTotal('')
    #if os.path.exists('/etc/redhat-release'):
    #    os_info['os'] = 'centos';
    #elif os.path.exists('/usr/bin/yum'):
    #    os_info['os'] = 'centos';
    #elif os.path.exists('/etc/issue'): 
    #    os_info['os'] = 'ubuntu';
    os_info['os'] = syst['system']
    return os_info['os']
        
#获取处理器类型
def get_cup_type():
	cpu_type={}
	cpu_type['status'] = True
	cput = s.GetNetWork('')
	cpu_type['type'] = cput['cpu']
	return cpu_type['type'][3]
	
def phpmyadmin_info():
    return os.popen('ls /www/server/phpmyadmin | grep "phpmyadmin"').read()
    
#获取tcp端口信息
def get_tcp_prot(userkey):
    get_url='http://api.yunwk.top//bt_frpc_api/get_tcp_prot.php?userkey='+userkey
    #远程获取get数据
    rt=requests.get(get_url)
    rt=rt.json()
    return rt['msg']

#解密
def decrypt(ksa, s):
    c = bytearray(str(s).encode("utf-8"))
    n = len(c)
    if n % 2 != 0:
        return ""
    n = n // 2
    b = bytearray(n)
    j = 0
    for i in range(0, n):
        c1 = c[j]
        c2 = c[j + 1]
        j = j + 2
        c1 = c1 - 46
        c2 = c2 - 46
        b2 = c2 * 19 + c1
        b1 = b2 ^ ksa
        b[i] = b1
    return b.decode("utf-8")
   

