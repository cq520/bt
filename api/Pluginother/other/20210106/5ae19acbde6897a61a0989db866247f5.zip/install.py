#!/usr/bin/python
# coding: utf-8

import sys,os,json,time
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.abspath(__file__))
panel_path = os.path.dirname(os.path.dirname(plugin_path))
os.chdir(panel_path);

#添加包引用位置
plugin_libs_path = "%s/libs/" % (plugin_path)
sys.path.append(plugin_libs_path)

import utils
import baidu_netdisk_main

class install:

    #配置插件安装目录
    __install_path = "%s/" % (plugin_path)

    def __init__(self):
        reload(utils)
        reload(baidu_netdisk_main)
        self.utils = utils.Utils()
        self.baidu_netdisk_main = baidu_netdisk_main.baidu_netdisk_main()
        pass

    def install(self):
        os.system('pip install pyOpenSSL -I --user')
        self.baidu_netdisk_main.install()
        pass

    def uninstall(self):
        self.baidu_netdisk_main.uninstall()
        self.utils.rmtree(self.__install_path)
        pass

if __name__ == "__main__":
    b = install();
    type = sys.argv[1];
    if type == 'install':
        b.install()
        exit()
    elif type == 'uninstall':
        b.uninstall()
        exit()