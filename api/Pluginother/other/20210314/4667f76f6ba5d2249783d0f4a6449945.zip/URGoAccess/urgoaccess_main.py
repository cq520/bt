#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | URGoAccess
# +-------------------------------------------------------------------
# | WebSite: https://urhost.cn
# +-------------------------------------------------------------------
# | Author: Tiger <tiger@urmail.cn>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   URGoAccess
#+--------------------------------------------------------------------
import sys,os,json,time,datetime
from os import stat

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public
import panelTask

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class urgoaccess_main:
    __plugin_path = "/www/server/panel/plugin/urgoaccess/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    #自定义访问权限检查
    #一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    #如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    #如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    #示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    #可通过args.fun获取被请求的方法名称
    #可通过args.client_ip获取客户IP
    def _check(self,args):
        #token = '123456'
        #limit_addr = ['192.168.1.2','192.168.1.3']
        #if args.token != token: return public.returnMsg(False,'Token验证失败!')
        #if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
        #return redirect('/login')
        return True

    #访问/demo/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self,args):
        return self.get_logs(args)

    def get_sites(self,args):
        data = public.M('sites').field('name,path').select()
        ret = {}
        for i in data:
            ret[i['name']] = i ['path']
        return public.returnMsg(True,ret)
    def del_report(self,args):
        if os.path.exists(args.report):
            os.remove(args.report)
        return public.returnMsg(True,'删除成功')
    def start_generate(self,args):
        if os.path.exists(args.report):
            os.remove(args.report)
        t = panelTask.bt_task()
        shell = 'goaccess -f '+args.path+' --log-format=COMBINED -o '+args.report
        result = t.create_task('urgenerate',0,shell)
        return public.returnMsg(True,result)

    def get_list(self,args):
        time.sleep(3)
        dir_list = os.listdir(urgoaccess_main.__plugin_path+'static/report/')
        ret = {}
        #ret['length'] = len(dir_list)
        for cur_file in dir_list:
            if cur_file.endswith(".html"):
                statinfo =stat(urgoaccess_main.__plugin_path+'static/report/'+cur_file)
                #time_str = datetime.datetime.fromtimestamp(statinfo.st_atime).strftime("%Y-%m-%d %H:%M:%S")
                #timestr = time.localtime(statinfo.st_atime)
                #获取文件名和时间
                ret[cur_file] = int(statinfo.st_atime)
        ret = sorted(ret.items(), key = lambda kv:(kv[1], kv[0]), reverse = True)

        return public.returnMsg(True,ret)

    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

