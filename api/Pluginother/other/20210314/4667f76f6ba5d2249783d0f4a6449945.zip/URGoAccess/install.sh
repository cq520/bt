#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/urgoaccess/
goaccess_path=/www/server/urgoaccess/
goaccess_src_path=$goaccess_path/goaccess-1.4.6/
#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始	
	if [  -n "$(uname -a | grep Ubuntu)" ]; then
	    apt-get install libncursesw5-dev libgeoip-dev -y
	else
	    yum install wget geoip ncurses-libs ncurses-devel -y
	fi
	
	if [ ! -d $goaccess_path ]; then
	  mkdir $goaccess_path
	fi
	
	cd $goaccess_path && wget https://git.urproject.cn:3000/Tiger/goaccess/raw/branch/master/build/goaccess-1.4.6.tar.gz && tar zxvf goaccess-1.4.6.tar.gz && cd ./goaccess-1.4.6/ && ./configure --enable-utf8  && make && make install && echo '安装成功'
	
	
	#依赖安装结束
	#==================================================================

}

#卸载
Uninstall()
{
	rm -rf $install_path
	rm -rf $goaccess_path
	cd $goaccess_src_path && make uninstall
	
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
