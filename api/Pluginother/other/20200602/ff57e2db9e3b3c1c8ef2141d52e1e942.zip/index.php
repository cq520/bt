<?php
//宝塔Linux面板插件demo for PHP
//@author 阿良<287962566@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：["56","71","72","73"]，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节
class bt_main
{
    //不允许被面板访问的方法请不要设置为公有方法
    public function test()
    {
        //_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
        //可通过_version()函数获取面板版本
        //可通过_post('client_ip') 来获取访客IP

        //常量说明：
        //PLU_PATH 插件所在目录
        //PLU_NAME 插件名称
        //PLU_FUN  当前被访问的方法名称
        return array(
            _get(),
            _post(),
            _version(),
            PLU_FUN,
            PLU_NAME,
            PLU_PATH
        );
    }
	
    // 读取接口配置
    public function index()
    {
        $domain = fopen("/www/server/panel/plugin/baidu_push/domain.ini", "r") or die("Unable to open file!");
        $domain_list = fread($domain, filesize("/www/server/panel/plugin/baidu_push/domain.ini"));
        $interface = fopen("/www/server/panel/plugin/baidu_push/interface.ini", "r") or die("Unable to open file!");
        $interface_list = unserialize(fread($interface, filesize("/www/server/panel/plugin/baidu_push/interface.ini")));
        exit(json_encode(array('code' => 0, 'msg' => '', 'domain' => $domain_list, 'interface' => $interface_list)));
    }
    
    // 保存接口配置
    public function interface()
    {
        $domain_list = trim(_post('domain'));
        $interface_list['active'] = trim(_post('active'));
        $interface_list['move_id'] = trim(_post('move_id'));
        $interface_list['move'] = trim(_post('move'));
		$interface_list['sm_key'] = trim(_post('sm_key'));
		$interface_list['sm_mail'] = trim(_post('sm_mail'));
        $domain = fopen("/www/server/panel/plugin/baidu_push/domain.ini", "w");
        fwrite($domain, $domain_list);
        fclose($domain);
        $interface = fopen("/www/server/panel/plugin/baidu_push/interface.ini", "w");
        fwrite($interface, serialize($interface_list));
        fclose($interface);
        exit(json_encode(array('code' => 0, 'msg' => '接口配置保存成功')));
    }

    // 百度推送
    public function baidu_push()
    {
        $domain = trim(_post('domain'));
        $urls = trim(_post('urls'));
        $type = (int)trim(_post('type'));
        if (empty($domain)) {
            exit(json_encode(['code' => 1, 'msg' => '域名不能为空']));
        }
        if (empty($urls)) {
            exit(json_encode(['code' => 1, 'msg' => '推送链接不能为空']));
        }
        if (empty($type)) {
            exit(json_encode(['code' => 1, 'msg' => '推送类型不能为空']));
        }
        $interface = fopen("/www/server/panel/plugin/baidu_push/interface.ini", "r") or die("Unable to open file!");
        $interface_list = unserialize(fread($interface, filesize("/www/server/panel/plugin/baidu_push/interface.ini")));
        switch ($type) {
            case 1:
                $api = "http://data.zz.baidu.com/urls?site=" . $domain . "&token=" . $interface_list['active'];
                break;
            case 2:
                $api = "http://data.zz.baidu.com/urls?site=" . $domain . "&token=" . $interface_list['active'] . '&type=daily';
                break;
            default:
                exit(json_encode(['code' => 1, 'msg' => '推送类型有误']));
        }
        $headers = array('Content-Type: text/plain');
        $baidu = curl_init();
        curl_setopt($baidu, CURLOPT_URL, $api);
        curl_setopt($baidu, CURLOPT_POST, true);
        curl_setopt($baidu, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($baidu, CURLOPT_POSTFIELDS, $urls);
        curl_setopt($baidu, CURLOPT_HTTPHEADER, $headers);
        $baidu_result = json_decode(curl_exec($baidu), true);
        curl_close($baidu);
		if (!$baidu_result['error']) {
			exit(json_encode(array('code' => 0, 'msg' => '推送成功条数：' . $baidu_result['success'] . '条，剩余可推送url条数：' . $baidu_result['remain'] . '条！')));
		} else {
			exit(json_encode(array('code' => 1, 'msg' => '推送失败')));
		}
    }
}
