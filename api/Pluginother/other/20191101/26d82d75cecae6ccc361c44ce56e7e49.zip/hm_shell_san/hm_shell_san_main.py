# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: print("") <1249648969@qq.com>
# +--------------------------------------------------------------------
# |   河马webshell 查杀
# +--------------------------------------------------------------------
import os,re,public,csv,json,time,hashlib
class hm_shell_san_main:
    __hm_shell_path='/usr/local/hm'
    __biaojie='/www/server/panel/plugin/hm_shell_san/biaoji.txt'
    __jindu='/www/server/panel/plugin/hm_shell_san/result.txt'

    def __init__(self):
        #判断是否安装了河马文件
        if not  os.path.exists(self.__hm_shell_path):
            public.ExecShell('cd /usr/local/ && wget http://download.bt.cn/install/plugin/hm_shell_san/hm-linux-amd64.tgz && tar zxf hm-linux-amd64.tgz && rm -rf /usr/local/hm-linux-amd64.tgz')

    #更新
    def shell_update(self,get):
        public.ExecShell('/usr/local/hm update')
        return public.returnMsg(True, "更新成功")

    # 返回站点
    def return_site(self, get):
        data = public.M('sites').field('name,path').select()
        ret = {}
        for i in data:
            ret[i['name']] = i['path']
        return public.returnMsg(True, ret)

    def san_path(self,get):
        if not  'path' in get:return public.returnMsg(False, "目录不存在")
        if  not os.path.exists(get.path):return public.returnMsg(False, "目录不存在")
        os.system('/usr/local/hm scan %s >/www/server/panel/plugin/hm_shell_san/result.txt &'%get.path)
        return public.returnMsg(True, "已经启动扫描进程")

    #获取进度
    def get_san(self,get):
        if not os.path.exists(self.__jindu):return public.returnMsg(False, "进度文件已经不存在")
        data3=public.ReadFile(self.__jindu)
        data=re.findall('\d+/\d+',data3)
        if len(data)>1:
            list_data=data[-1].split('/')
            return int(list_data[0])*100/int(list_data[1])
        elif len(data)==1 and re.search('TOTAL',data3):
            return 100
        else:
            return 0

    #读取日志
    def get_log(self,get):
        if not os.path.exists(self.__jindu):return public.returnMsg(False, "日志文件不存在")
        data=public.ReadFile(self.__jindu)
        return public.returnMsg(True, data)

    #读取扫描后的文件
    def get_shell(self,get):
        f = open('/usr/local/result.csv', mode='r')
        reader = csv.reader(f)
        resulit=[]
        for row in reader:
            resulit.append(row)
        return resulit

    def upload_file_url(self,get):

        try:
            if os.path.exists(get.filename):

                    data = public.ExecShell('/usr/local/curl/bin/curl https://scanner.baidu.com/enqueue -F archive=@%s' % get.filename)
                    data=json.loads(data[0])
                    time.sleep(3)
                    import requests
                    default_headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
                    }
                    data_list = requests.get(url=data['url'],headers=default_headers, verify=False)
                    data2=data_list.json()
                    self.send_baota(get)
                    if 'data' in data2[0]:
                        if len(data2[0]['data'])>=1:
                            if 'descr' in data2[0]['data'][0]:
                                if 'WebShell' in data2[0]['data'][0]['descr']:
                                    return public.returnMsg(True, '此文件为webshell')
                    return public.returnMsg(True, '未查出风险')
            else:
                return public.returnMsg(False, '文件不存在')
        except:
            return public.returnMsg(True, '未查出风险')

    #打开二进制文件并计算md5
    def read_file_md5(self,filename):
        if os.path.exists(filename):
            with open(filename, 'rb') as fp:
                data = fp.read()
            file_md5 = hashlib.md5(data).hexdigest()
            return file_md5
        else:
            return False


    #上传云端
    def send_baota(self,get):
        '''
        filename  文件
        '''
        if 'filename' not in get:return public.returnMsg(False, '请选择你需要上传的文件')
        if not os.path.exists(get.filename):return public.returnMsg(False, '文件不存在')
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_submit'
        pdata={'codetxt':public.ReadFile(get.filename),'md5':self.read_file_md5(get.filename),'type':'0','host_ip':public.GetLocalIp(),'size':os.path.getsize(get.filename)}
        ret = public.httpPost(cloudUrl, pdata)
        if ret=='1':
            return self.check_webshell(get)
        elif ret=='-1':
            return self.check_webshell(get)
        else:
            return public.returnMsg(False, '系统错误')

    #检测是否是木马
    def check_webshell(self,get):
        if 'filename' not in get: return public.returnMsg(False, '请选择你需要上传的文件')
        if not os.path.exists(get.filename): return public.returnMsg(False, '文件不存在')
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_check_file'
        pdata = {'md5': self.read_file_md5(get.filename),'size': os.path.getsize(get.filename)}
        ret = public.httpPost(cloudUrl, pdata)
        if ret == '0':
            return public.returnMsg(True, '未查出风险')
        elif ret=='1':
            return public.returnMsg(True, '该文件经过系统检测为webshell！！！！')
        elif ret == '-1':
            return public.returnMsg(True, '未查询到该文件,请上传检测')
        else:
            return public.returnMsg(False, '系统错误')

    #删除文件
    def remove_file(self,get):
        if os.path.exists(get.filename):
            os.remove(get.filename)
            return public.returnMsg(False, '删除成功')
        else:
            return public.returnMsg(False, '删除失败')