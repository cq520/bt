<?php
$mod = 'install';
require_once '../includes/common.php';

$title = '安装前言';
require_once './header.php';
?>

<body>
                <div class="container"><br>
    <div class="row">
        <div class="col-xs-12">
            <pre><h4>GEP系统</h4></pre>
        </div>
        <div class="col-xs-12">
            <div class="panel panel-warning">
        <div class="panel-heading text-center">安装前言</div>
                    <div class="panel-body">
                            <pre><?=file_get_contents('http://auth.6web.cn/uplog.php')?></pre>
                            <p style="text-align: center"><iframe frameborder="0" src="https://v.qq.com/iframe/player.html?vid=b3122hs8ha7&amp;width=250&amp;height=120&amp;auto=0" allowFullScreen="true"></iframe></p>
        <a href="/install/install1.php" class="btn list-group-item">开始安装</a>
                    </div>
                    </div>
                    </div>
                    </div>
            <footer class="footer">
        <pre><center>Powered by GEP</center></pre>
    </footer>
    </body>
</html>