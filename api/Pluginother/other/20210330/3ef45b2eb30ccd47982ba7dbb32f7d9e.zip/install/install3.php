<?php
if(empty($_POST))header('Location:/install');

$mod = 'install';
require_once '../includes/common.php';

$db = array(
    'dbHost' => $_POST['dbHost'],
    'dbPort' => $_POST['dbPort'],
    'dbName' => $_POST['dbName'],
    'dbUser' => $_POST['dbUser'],
    'dbPwd' => $_POST['dbPwd']
);
$dsn = 'mysql:host='.$db['dbHost'].';port='.$db['dbPort'].';dbname='.$db['dbName'].';charset=utf8';
try {
    $DB=new PDO($dsn,$db['dbUser'],$db['dbPwd']);
} catch(Exception $e) {
    Tips::error('数据库连接错误，请重新填写。','/install/install2.php');
}
$sqlAry = explode(';',file_get_contents('install.sql'));
unset($sqlAry[count($sqlAry)-1]);
$success = 0;
$error = 0;
$errorinfo = '';
foreach ($sqlAry as $v) {
    if($DB->query($v))$success++;
    continue;
    $error++;
    $errinfo = $DB->errorinfo();
    $errorinfo .= $errinfo['0'];
}

$config = "<?php
\$db = array(
    'dbHost' => '{$_POST['dbHost']}',
    'dbPort' => '{$_POST['dbPort']}',
    'dbName' => '{$_POST['dbName']}',
    'dbUser' => '{$_POST['dbUser']}',
    'dbPwd' => '{$_POST['dbPwd']}'
);";
file_put_contents('../config.php',$config);

if(!$error && $success)file_put_contents('install.lock','安装锁');
 //@file_put_contents("install.sql",'sql文件已删除,GEP系统作者QQ2477581302');
            @file_put_contents("install.lock", 'GEP系统作者QQ2477581302');
            $step = 3;
$title = '安装完成';
require_once './header.php';
?>
    <body>
                <div class="container"><br>
    <div class="row">
        <div class="col-xs-12">
            <pre><h4>GEP系统</h4></pre>
        </div>
        <div class="col-xs-12">
            <div class="panel panel-warning">
        <div class="panel-heading text-center">数据处理完毕</div>
                    <div class="panel-body">
                        <ul class="list-group">
                            <li class="list-group-item">1、系统已成功安装完毕！</li>
                            <li class="list-group-item">2、系统管理员初始 用户名：admin 密码:123456</li>
                            <li class="list-group-item">3、GEP-欢迎您的使用！管理员后台域名/admin</li>
                            <a href="/" class="btn list-group-item">进入网站首页</a>
                        </ul>
                    </div>
                    </div>
                    </div>
                    </div>
            <footer class="footer">
        <pre><center>Powered by GEP</center></pre>
    </footer>
        </div>
    </body>
</html>