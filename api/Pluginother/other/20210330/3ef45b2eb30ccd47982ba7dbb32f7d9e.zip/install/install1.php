<?php
$mod = 'install';
require_once '../includes/common.php';

$_SESSION['install'] = '1';

$title = '环境检测';
require_once './header.php';
?>
    <body>
<div class="container"><br>
    <div class="row">
        <div class="col-xs-12">
            <pre><h4>GEP系统</h4></pre>
        </div>
        <div class="col-xs-12">
            <div class="panel panel-warning">
               <div class="panel-heading text-center">安装环境检测

</div>
                    <div class="panel-body">
                        <?php
                        $install = true;
                        if (!file_exists('./install.lock')) {
                            $check[2] = '<span class="badge">未锁定

</span>';
                        } else {
                            $check[2] = '<span class="badge">已锁定

</span>';
                            $install = false;
                        }
                        if (class_exists("PDO")) {
                            $check[0] = '<span class="badge">支持

</span>';
                        } else {
                            $check[0] = '<span class="badge">不支持

</span>';
                            $install = false;
                        }
                        if (function_exists("file_get_contents")) {
                            $check[1] = '<span class="badge">支持

</span>';
                        } else {
                            $check[1] = '<span class="badge">不支持

</span>';
                            $install = false;
                        }
                        if (version_compare(PHP_VERSION, '5.6.0', '<')) {
                            $check[3] = '<span class="badge">不支持

</span>';
                        } else {
                            $check[3] = '<span class="badge">支持

</span>';
                        }
                        if (function_exists("sg_load")) {
                            $check[4] = '<span class="badge">支持

</span>';
                        } else {
                            $check[4] = '<span class="badge">不支持

</span>';
                            $install = false;
                        }

                        ?>
                        <ul class="list-group">
                            <li class="list-group-item">检测安装是

否锁定 <?php echo $check[2]; ?></li>
                            <li class="list-group-item">PDO_MYSQL组

件 <?php echo $check[0]; ?></li>
                            <li class="list-group-item">读取文件 

<?php echo $check[1]; ?></li>
                            <li class="list-group-item">PHP版本

>=5.6 <?php echo $check[3]; ?></li>
                            <li class="list-group-item">sg11扩展 

<?php echo $check[4]; ?></li>
                            <li class="list-group-item">成功安装后

安装文件就会锁定，如需重新安装，请手动删除install目录下install.lock

配置文件！</li>
                            <?php
                            if ($install) echo '<a 

href="/install/install2.php" class="btn list-group-item">检测通过，

下一步</a>';
                            ?>
                        </ul>
                    </div>
                    </div>
                    </div>
                    </div>
<footer class="footer">
        <pre><center>Powered by GEP</center></pre>
    </footer>
        </div>
    </body>
</html>