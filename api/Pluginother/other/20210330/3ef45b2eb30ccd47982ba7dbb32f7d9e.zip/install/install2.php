<?php
$mod = 'install';
require_once '../includes/common.php';

$title = '填写信息';
require_once './header.php';
?>
    <body>
        <div class="container"><br>
    <div class="row">
        <div class="col-xs-12">
            <pre><h4>GEP系统</h4></pre>
        </div>
        <div class="col-xs-12">
            <div class="panel panel-warning">
        <div class="panel-heading text-center">MYSQL数据库信息配置</div>
                    <div class="panel-body">
                        <div class="list-group text-success">
                            <form action="/install/install3.php" method="POST">
                                <div class="row items-push">
                                    <div class="col-lg-12">
                                        <div class="form-group row">
                                            <label class="col-sm-2 control-label">数据库主机</label>
                                            <div class="col-sm-10">
                                                <input placeholder="请输入数据库主机" value="localhost" type="text" name="dbHost" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 control-label">数据库端口</label>
                                            <div class="col-sm-10">
                                                <input placeholder="请输入数据库端口" value="3306" type="text" name="dbPort" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 control-label">数据库名</label>
                                            <div class="col-sm-10">
                                                <input placeholder="请输入数据库名" type="text" name="dbName" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 control-label">数据库用户名</label>
                                            <div class="col-sm-10">
                                                <input placeholder="请输入数据库用户名" type="text" name="dbUser" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 control-label">数据库密码</label>
                                            <div class="col-sm-10">
                                                <input placeholder="请输入数据库密码" type="text" name="dbPwd" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" class="btn btn-success btn-block">确定无误，下一步</button>
                                                </div>
                                                </div>
                                    </div>
                                </div>
                            </form>
                            </div>
                            </div>
                            </div>
                        </div>
                    </div>
            <footer class="footer">
        <pre><center>Powered by GEP</center></pre>
    </footer>
        </div>
    </body>
</html>