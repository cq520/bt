<?php
$mod = 'user';
$title = '接口添加';
require_once '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userAddApi'])Tips::error('管理员未开启此功能', '/user');
require_once './user.class.php';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/apiadd.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var load = layer.msg('添加中，请稍后...',{icon:16,shade:0.8,time:false});

        var apiIp = $("input[name='apiIp']").val();
        var apiKey = $("input[name='apiKey']").val();
        var dj = $("select[name='dj']").val();
        var djurl = $("input[name='djurl']").val();
        var djuser = $("input[name='djuser']").val();
        var apiMoney = $("input[name='apiMoney']").val();
        var apiTxt = $("textarea[name='apiTxt']").val();

        if(apiIp.length < 1 || apiKey.length < 1 || apiMoney.length < 1){
            layer.alert('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'apiAdd',
                apiIp:apiIp,
                apiKey:apiKey,
                dj:dj,
                djurl:djurl,
                djuser:djuser,
                apiMoney:apiMoney,
                apiTxt:apiTxt
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/selfapi.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>