<?php
$mod = 'user';
$notLogin = true;
include '../includes/common.php';
include './user.class.php';

if($isUserLogin)header('Location:/user');
$title = '找回密码';
include '../template/'. $conf['usermub'].'/user/forget.html';
?>
<script>
    $("form").submit(function (){
		var login = $("button[type='submit']");
        var userName = $("input[name='userName']").val();
        var userPwd = $("input[name='userPwd']").val();
        var upUserId = $("input[name='upUserId']").val();
        var userMail = $("input[name='userMail']").val();
		
	    var password = $("input[name='password']").val();
        var repassword = $("input[name='repassword']").val();
		
		var upUserId = $("input[name='upUserId']").val();
        var userMail = $("input[name='userMail']").val();
        
		var hasToken = <?=isset($_GET['token'])?'true':'false'?>;
		var token = ""
		if(hasToken){
		    token = "<?=$_GET['token']?>"
		}
        
        if(hasToken){
            if(password.length<6){
		    layer.msg('密码必须大于6位');
                return false;
            }
            if(password!=repassword){
		    layer.msg('两次密码不一致，请检查', {icon: 5,time: 2000, shade: [0.3, '#000']});
                return false;
            }
        }else{
            if(!is_check_mail(userMail) ){
		    layer.msg('邮箱账号格式错误', {icon: 5,time: 2000, shade: [0.3, '#000']});
                return false;
            }
        }
		
        

		login.attr('disabled', 'true');

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act: hasToken?'repass':'forget',
                userMail:userMail,
                password:password,
                repassword:repassword,
                token:token
            },
            dataType:'json',
            success:function (data){
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/login.php'
                    },1000);
                    alert(data.msg)
                }else{
					login.removeAttr('disabled');
					alert(data.msg)
                }
            }
        });
        return false;
    });

    $('#mail').click(function (){
		var login = $("button[type='submit']");
        var userMail = $("input[name='userMail']").val();

        if(userMail.length < 1){
		    layer.msg('请输入邮箱地址');
            return false;
        }

		login.attr('disabled', 'true');

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'sendMail',
                userMail:userMail
            },
            dataType:'json',
            success:function (data){
				login.removeAttr('disabled');
                if(data.code == 1){
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    });
    function is_check_name(str) {    
        return /^[\w]{3,16}$/.test(str) 
    }
    function is_check_mail(str) {
        return /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(str)
    }
</script>