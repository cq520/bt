        <footer id="footer" class="footer bgw" role="footer">
            <div class="wrapper b-t bg-light">
              <span class="pull-right"><a href="http://bbs.98ka.ren" >GEP <?=VERSION?></a><a href ui-scroll="app" class="m-l-sm text-muted"></a></span>
              &copy; 2020 Copyright.<a href="#" ><?=$conf['webName']?></a>
           </div>
        </footer>
    <script src="../assets/js/oneui.core.min.js"></script>
    <script src="../assets/js/oneui.app.min.js"></script>
    <script src="../assets/vendor/layer/layer.js"></script>
    </body>
</html>