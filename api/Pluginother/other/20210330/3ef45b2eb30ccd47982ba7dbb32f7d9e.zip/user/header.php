<?php $gonggao = userclass::gonggao($DB); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title><?=$conf['webName']?> - <?=$title?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <link rel="stylesheet" href="../assets/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
  <script src="../assets/js/jquery.min.js"></script>
</head>
<body>
<div class="app app-header-fixed ">
    <!-- header -->
  <header id="header" class="app-header navbar" role="menu">
      <!-- navbar header -->
      <div class="navbar-header bg-dark">
        <button class="pull-right visible-xs dk" ui-toggle-class="show" target=".navbar-collapse">
          <i class="glyphicon glyphicon-cog"></i>
        </button>
        <button class="pull-right visible-xs" ui-toggle-class="off-screen" target=".app-aside" ui-scroll="app">
          <i class="glyphicon glyphicon-align-justify"></i>
        </button>
        <!-- brand -->
        <a href="#" class="navbar-brand text-lt">
          <i class="fa fa-btc"></i>
              <span class="hidden-folded m-l-xs">GEP</span>
        </a>
        <!-- / brand -->
      </div>
      <!-- / navbar header -->

      <!-- navbar collapse -->
      <div class="collapse pos-rlt navbar-collapse box-shadow bg-white-only">
       <!-- buttons -->
        <div class="nav navbar-nav hidden-xs">
          <a href="#" class="btn no-shadow navbar-btn" ui-toggle="app-aside-folded" target=".app">
            <i class="fa fa-dedent fa-fw text"></i>
            <i class="fa fa-indent fa-fw text-active"></i>
          </a>
          <a href="#" class="btn no-shadow navbar-btn" ui-toggle-class="show" target="#aside-user">
            <i class="icon-user fa-fw"></i>
          </a>
        </div>
        <!-- / buttons -->
        <!-- link and dropdown -->
        <ul class="nav navbar-nav hidden-sm">
          <li class="dropdown pos-stc">
            <a href="#" data-toggle="dropdown">
              <span>快捷操作</span>
              <span class="caret"></span>
            </a>
            <div class="dropdown-menu wrapper w-full bg-white">
              <div class="row">
                <div class="col-sm-2">
                  <div class="m-l-xs m-t-xs m-b-xs font-bold">Interface Center</div>
                  <div class="row">
                    <div class="col-xs-12">
                      <ul class="list-unstyled l-h-2x">
                        <li>
                          <a href="/user/apibuy.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>接口购买 <span class="badge badge-sm bg-warning">优惠</span></a>
                        </li>
                        <li>
                          <a href="/user/apilist.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>接口列表</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-2 b-l b-light">
                  <div class="m-l-xs m-t-xs m-b-xs font-bold">User center</div>
                  <div class="row">
                    <div class="col-xs-12">
                      <ul class="list-unstyled l-h-2x">
                        <li>
                          <a href="/user/editpwd.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>修改信息</a>
                        </li>
                         <?php $userData = userClass::getUser($DB, $_SESSION['userName']);if (empty($userData['userQq'])){ ?>
                        <li>
                          <a href="/user/bindqq.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>绑定QQ</a>
                        </li>
                        <?php } else { ?>
                        <li>
                          <a href="/user/bindqq.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>重绑QQ</a>
                        </li>
                        <?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4 b-l b-light">
                  <div class="m-l-xs m-t-xs m-b-xs font-bold">Docking</div>
                  <div class="row">
                    <div class="col-xs-6">
                      <ul class="list-unstyled l-h-2x">
                        <li>
                          <a href="/user/accessSet.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>配置中心</a>
                        </li>
                        <li>
                          <a href="/user/accessCourse.php"><i class="fa fa-fw fa-angle-right text-muted m-r-xs"></i>对接教程</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-xs-6">
                      <ul class="list-unstyled l-h-2x">
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4 b-l b-light">
                  <div class="m-l-xs m-t-xs m-b-sm font-bold">预存款 <a href="/user/pay.php" class="btn btn-info btn-xs">充值</a></div>
                  <div class="text-center">
                    <div class="inline">
          						<div class="font-thin h1" id="moneycode"><?=userClass::getMoney($DB, $_SESSION['userName'])?></div>
          						<span class="text-muted text-xs">账户余额</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
        <!-- / link and dropdown -->
        <!-- search form -->
        <form class="navbar-form navbar-form-sm navbar-left shift" ui-shift="prependTo" data-target=".navbar-collapse" role="search" ng-controller="TypeaheadDemoCtrl">
          <div class="form-group">
            <div class="input-group">
              <input type="text" ng-model="selected" typeahead="state for state in states | filter:$viewValue | limitTo:8" class="form-control input-sm bg-light no-border rounded padder" placeholder="关键词搜索...">
              <span class="input-group-btn">
                <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </div>
        </form>
        <!-- / search form -->
        <!-- nabar right -->
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">
              <i class="icon-bell fa-fw"></i>
              <span class="visible-xs-inline">Notifications</span>
              <span class="badge badge-sm up bg-danger pull-right-xs">2</span>
            </a>
            <!-- dropdown -->
            <div class="dropdown-menu w-xl animated fadeInUp">
              <div class="panel bg-white">
                <div class="panel-heading b-light bg-light">
                  <strong>站点<span>公</span>告</strong>
                </div>
                <div class="list-group">
                    <?php foreach ($gonggao as $v){ ?>
        <a href class="list-group-item">
             <span class="pull-left m-r thumb-sm">
       
             </span>
            
        <span class="clear block m-b-none">
  
                    <?=$v['time']?><br>
      
                <small class="text-muted"><?=$v['title']?></small>
   
                 </span>
         
         </a>
  
<?php } ?>                
                </div>
              </div>
            </div>
            <!-- / dropdown -->
          </li>
          <li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle clear" data-toggle="dropdown">
              <span class="thumb-sm avatar pull-right m-t-n-sm m-b-n-sm m-l-sm">
                <img src="//q1.qlogo.cn/g?b=qq&nk=<?=$_SESSION['userMail']?>&s=100" alt="gep">
                <i class="on md b-white bottom"></i>
              </span>
              <span class="hidden-sm hidden-md"><?=$_SESSION['userName']?></span> <b class="caret"></b>
            </a>
            <!-- dropdown -->
            <ul class="dropdown-menu animated fadeInRight w">
              <li>
                  <a href>
                  <a href="/user/editpwd.php">
                  <span>设置账户</span>
                </a>
              </li>
              <li>
                  <a href>
                  <a href="/user/accessSet.php">
                  <span>重置密匙</span>
                </a>
              </li>
              <li class="divider"></li>
              <li>
                  <a href>
                <a href="/user/login.php?logout">
                 <span>注销登录</span>
               </a>
              </li>
        </ul>
        <!-- / navbar right -->
      </div>
      <!-- / navbar collapse -->
  </header>
  <!-- / header -->
  
    <!-- aside -->
  <aside id="aside" class="app-aside hidden-xs bg-dark">
      <div class="aside-wrap">
        <div class="navi-wrap">
          <!-- user -->
          <div class="clearfix hidden-xs text-center hide" id="aside-user">
            <div class="dropdown wrapper">
              <a href="/user">
                <span class="thumb-lg w-auto-folded avatar m-t-sm">
                  <img src="//q1.qlogo.cn/g?b=qq&nk=<?=$_SESSION['userMail']?>&s=100" class="img-full" alt="...">
                </span>
              </a>
              <a href="#" data-toggle="dropdown" class="dropdown-toggle hidden-folded">
                <span class="clear">
                  <span class="block m-t-sm">
                    <strong class="font-bold text-lt"><?=$_SESSION['userName']?></strong> 
                    <b class="caret"></b>
                  </span>
                  <span class="text-muted text-xs block"><?=userClass::getUserLevel($DB, $_SESSION['userId'])?></span>
                </span>
              </a>
              <!-- dropdown -->
              <ul class="dropdown-menu animated fadeInRight w hidden-folded">
                <li class="wrapper b-b m-b-sm bg-info m-t-n-xs">
                  <span class="arrow top hidden-folded arrow-info"></span>
                  <div>
                    <p>您是我们这边第<?=$_SESSION['userId']?>名客户</p>
                  </div>
                  <div class="progress progress-xs m-b-none dker">
                    <div class="progress-bar bg-white" data-toggle="tooltip" data-original-title="50%" style="width: 50%"></div>
                  </div>
                </li>
                <li>
                  <a href="/user/pay.php">在线充值</a>
                </li>
                <li>
                  <a href="/user/upLevel.php">等级升级</a>
                </li>
                <li class="divider"></li>
                <li>
                  <a href="/user/login.php?logout">退出登入</a>
                </li>
              </ul>
              <!-- / dropdown -->
            </div>
            <div class="line dk hidden-folded"></div>
          </div>
          <!-- / user -->

           <!-- nav -->
          <nav ui-nav class="navi clearfix">
            <ul class="nav">
              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>导航</span>
              </li>
              <li>
                <a href="/user">
                  <i class="glyphicon glyphicon-home icon text-primary-dker"></i>
				  <b class="label bg-info pull-right">N</b>
                  <span class="font-bold">仪表盘</span>
                </a>
              </li>
              <?php if($conf['userPayMoney']){ ?>
              <li>
                <a href="/user/pay.php">
                  <i class="glyphicon glyphicon-credit-card icon text-info-lter"></i>
                  <span class="font-bold">在线充值</span>
                </a>
              </li>
              <?php } ?>
              <li>
                <a href class="auto">      
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-leaf icon text-success-lter"></i>
                  <span>信息设置</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>信息设置</span>
                    </a>
                  </li>
                 <?php if($conf['userUpLevel']){ ?>
                  <li>
                    <a href="/user/upLevel.php">
                      <span>等级升级</span>
                    </a>
                  </li>
                  <?php } ?>
                  <li>
                    <a href="/user/editpwd.php">
                      <span>修改密码</span>
                    </a>
                  </li>
                  <?php $userData = userClass::getUser($DB, $_SESSION['userName']);if (empty($userData['userQq'])){ ?>
                  <li>
                    <a href="/user/bindqq.php">
                      <span>绑定QQ</span>
                    </a>
                  </li>
                  <?php } else { ?>
                    <li>
                     <a href="/user/bindqq.php">
                      <span>重新绑定</span>
                      </a>
            </li>
           <?php } ?>
                  </ul>
                  </li>
                  <li>
                <a href class="auto">      
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-user"></i>
                  <span>下级设置</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>下级设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/loweruserlist.php">
                      <span>下级列表</span>
                    </a>
                  </li>
                  <?php if($conf['userAddLower']){ ?>
                  <li>
                    <a href="/user/loweruseradd.php">
                      <span>添加下级</span>
                    </a>
                  </li>
                  <?php } ?>
                  </ul>
                  </li>
                  <li>
                <a href class="auto">      
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-bookmark"></i>
                  <span>卡密设置</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>卡密设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/carmilist.php">
                      <span>卡密列表</span>
                    </a>
                  </li>
                  <?php if($conf['userAddCarmi']){ ?>
                  <li>
                    <a href="/user/carmiadd.php">
                      <span>添加卡密</span>
                    </a>
                  </li>
                  <?php } ?>
                  <?php if($conf['userExchangeCarmi']){ ?>
                  <li>
                    <a href="/user/carmiexchange.php">
                      <span>卡密兑换</span>
                    </a>
                  </li>
                  <?php } ?>
                  </ul>
                  </li>
              <li class="line dk"></li>

              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>产品</span>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-edit"></i>
                  <span>接口管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>接口管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/selfapi.php">
                      <span>接口仓库</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/apilist.php">
                      <b class="badge bg-info pull-right"><?=Counts::userApi($DB, $_SESSION['userName'])?></b>
                      <span>接口列表</span>
                    </a>
                  </li>
                  <?php if($conf['userAddApi']){ ?>
                  <li>
                    <a href="/user/apiadd.php">
                      <span>接口添加</span>
                    </a>
                  </li>
                  <?php } ?>
								<?php if($conf['userBuyApi']){ ?>
                  <li>
                    <a href="/user/apibuy.php">
                      <b class="badge bg-success pull-right"><?=Counts::api($DB)?></b>
                      <span>接口购买</span>
                    </a>
                  </li>
                  <?php } ?>
                </ul>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-hdd"></i>
                  <span>主机管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>主机管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/hostlist.php">
                      <span>主机列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/hostadd.php">
                      <span>主机添加</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-dashboard icon"></i>
                  <span>对接中心</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>对接中心</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/accessSet.php">
                      <span>配置中心</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/accessCourse.php">
                      <span>对接教程</span>
                    </a>
                  </li>
                </ul>
              </li>

              <li class="line dk hidden-folded"></li>

              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">          
                <span>售后</span>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-briefcase"></i>
                  <span>工单系统</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>工单系统</span>
                    </a>
                  </li>
                  <li>
                    <a href="/user/worklist.php">
                      <span>工单列表</span>
                    </a>
                  </li>
                  <?php if($conf['userAddWork']){ ?>
                  <li>
                    <a href="/user/workadd.php">
                      <span>提交工单</span>
                    </a>
                  </li>
                  <?php } ?>
                </ul>
              </li>
              <li>
                <a href="//wpa.qq.com/msgrd?v=3&uin=<?=$conf['webQq']?>&site=qq&menu=yes">
                  <i class="icon-user icon text-success-lter"></i>
                  <b class="badge bg-success pull-right">售后</b>
                  <span>联系站长</span>
                </a>
              </li>
              <li>
                <a href="/user/noticelist.php">
                  <i class="glyphicon glyphicon-bullhorn"></i>
                  <span>公告列表</span>
                </a>
              </li>
            </ul>
          </nav>
          <!-- nav -->

          <!-- aside footer -->
          <div class="wrapper m-t">
            <div class="text-center-folded">
              <span class="pull-right pull-none-folded">60%</span>
              <span class="hidden-folded">Milestone</span>
            </div>
            <div class="progress progress-xxs m-t-sm dk">
              <div class="progress-bar progress-bar-info" style="width: 60%;">
              </div>
            </div>
            <div class="text-center-folded">
              <span class="pull-right pull-none-folded">35%</span>
              <span class="hidden-folded">Release</span>
            </div>
            <div class="progress progress-xxs m-t-sm dk">
              <div class="progress-bar progress-bar-primary" style="width: 35%;">
              </div>
            </div>
          </div>
          <!-- / aside footer -->
        </div>
      </div>
  </aside>
  <!-- / aside -->