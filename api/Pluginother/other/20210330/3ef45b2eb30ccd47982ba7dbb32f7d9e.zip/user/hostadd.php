<?php
$mod = 'user';
$title = '主机添加';
include '../includes/common.php';
include './user.class.php';
if(!$conf['userhostadd'])Tips::error('管理员未开启此功能', '/user');
$userData = userClass::getUser($DB, $userName);
if(!empty($_POST)){
    $_POST['userName']=$userName;
    $_POST['userKey']=$userData['userKey'];
    list($result,$msg) = userClass::createHost($DB, $_POST);
    if(!$result)Tips::error($msg,'/user/hostadd.php');
    Tips::success('开通成功','/user/hostlist.php');
}
$apiData = userClass::getUserApiUserName($DB, $_SESSION['userName']);

include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/hostadd.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>