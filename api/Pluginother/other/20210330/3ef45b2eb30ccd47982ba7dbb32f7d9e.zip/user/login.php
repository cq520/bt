<?php
$mod = 'user';
$notLogin = true;
include '../includes/common.php';
include './user.class.php';

if(isset($_GET['logout'])){
    unset($_SESSION['userName']);
    unset($_SESSION['userMail']);
    unset($_SESSION['userId']);
    header('Location:/user/login.php');
}
if (isset($_GET['qqlogin'])) {
    $ssl = $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://' ;
    $redirect = $ssl . $_SERVER['SERVER_NAME'] . '/user/ajax.php?act=login';
    $url = qqLogin($redirect);
    header('Location:' . $url);
}
if($isUserLogin)header('Location:/user');
$title = '用户登录';
include '../template/'. $conf['usermub'].'/user/login.html';
?>
<script>
    $("form").submit(function (){
		var login = $("button[type='submit']");
        var userName = $("input[name='userName']").val();
        var userPwd = $("input[name='userPwd']").val();
        
        var isImgCode = <?=$conf['isImgCode']?>;

        if(userName.length < 1 || userPwd.length < 1){
		    layer.msg('请确保必填项不为空');
            return false;
        }
        
        if(isImgCode){
		    var imgCode = $("input[name='imgCode']").val();
		    if(imgCode.length < 1){
		    layer.msg('请输入图片验证码');
				return false;
			}
		}

		login.attr('disabled', 'true');

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'login',
                userName:userName,
                userPwd:userPwd,
                imgCode:imgCode
            },
            dataType:'json',
            success:function (data){
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
					login.removeAttr('disabled');
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
    $("#imageCode").click(function(){
       
       $(this).attr("src", '../includes/imageCode.php?tmp=' + Math.random()); 
    });
</script>