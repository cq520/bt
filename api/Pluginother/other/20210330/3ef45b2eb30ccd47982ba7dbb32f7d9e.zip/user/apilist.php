<?php
$mod = 'user';
$title = '接口列表';
require_once '../includes/common.php';
require_once './user.class.php';
$apiData = userClass::getUserApiUserName($DB, $_SESSION['userName']);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/apilist.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    function del(id){
        layer.confirm('确定要删除吗？删除后不可使用且不退款', function (){
            delApi(id)
        });
    }
    function delApi(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'delUserApi',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/apilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>