<?php
$mod = 'user';
$title = '对接教程';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
include './user.class.php';
$userData = userClass::getUser($DB, $_SESSION['userName']);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/accessCourse.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>