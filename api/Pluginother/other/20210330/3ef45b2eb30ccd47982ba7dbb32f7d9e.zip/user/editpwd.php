<?php
$mod = 'user';
$title = '修改密码';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
include './user.class.php';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/editpwd.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var userPwd = $("input[name='userPwd']").val();
        var newUserPwd = $("input[name='newUserPwd']").val();

        if(userPwd.length < 1 || newUserPwd.length < 1){
            layer.msg('不可为空');
            return false;
        }

        if(userPwd == newUserPwd){
            layer.msg('不可一致');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'editpwd',
                userPwd:userPwd,
                newUserPwd:newUserPwd
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/login.php'
                    },1000);
                    layer.msg({icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg({icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>