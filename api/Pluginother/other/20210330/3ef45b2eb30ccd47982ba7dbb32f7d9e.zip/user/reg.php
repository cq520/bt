<?php
$mod = 'user';
$title = '用户注册';
$notLogin = true;
include '../includes/common.php';
include './user.class.php';

if(isset($_GET['logout'])){
    unset($_SESSION['userName']);
    header('Location:/user/login.php');
}

if($isUserLogin)header('Location:/user');
if(!$conf['isUserReg'])Tips::error('管理员未开启此功能', '/');
include '../template/'. $conf['usermub'].'/user/reg.html';
?>
<script>
    $("form").submit(function (){
		var login = $("button[type='submit']");
        var userName = $("input[name='userName']").val();
        var userPwd = $("input[name='userPwd']").val();
        var upUserId = $("input[name='upUserId']").val();
        var userMail = $("input[name='userMail']").val();
		
		var isMailReg = <?=$conf['isMailReg']?>;
		var isImgCode = <?=$conf['isImgCode']?>;

        if(userName.length < 1 || userPwd.length < 1){
		    layer.msg('请输入图片验证码');
            return false;
        }
		if(isMailReg){
			var yzm = $("input[name='yzm']").val();
			if(userMail.length < 1 || yzm.length < 1){
		    layer.msg('请输入邮箱验证码');
				return false;
			}
		}
		
		if(isImgCode){
		    var imgCode = $("input[name='imgCode']").val();
		    if(imgCode.length < 1){
		    layer.msg('请输入图片验证码');
				return false;
			}
		}
		
		if( !is_check_name(userName) ){
		    layer.msg('用户名长度最少为3位字符且为英文') ;
            return false;
        }
        
        if(!is_check_mail(userMail) ){
		    layer.msg('邮箱账号格式错误', {icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }

		login.attr('disabled', 'true');

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'reg',
                userName:userName,
                userPwd:userPwd,
                upUserId:upUserId,
                userMail:userMail,
                yzm:yzm,
                imgCode:imgCode
            },
            dataType:'json',
            success:function (data){
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user'
                    },1000);
                    alert(data.msg)
                }else{
					login.removeAttr('disabled');
					alert(data.msg)
                }
            }
        });
        return false;
    });

    $('#mail').click(function (){
		var login = $("button[type='submit']");
        var userMail = $("input[name='userMail']").val();

        if(userMail.length < 1){
		    layer.msg('请输入邮箱地址');
            return false;
        }

		login.attr('disabled', 'true');

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'sendMail',
                userMail:userMail
            },
            dataType:'json',
            success:function (data){
				login.removeAttr('disabled');
                if(data.code == 1){
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    });
    function is_check_name(str) {    
        return /^[\w]{3,16}$/.test(str) 
    }
    function is_check_mail(str) {
        return /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(str)
    }
    $("#imageCode").click(function(){
       
       $(this).attr("src", '../includes/imageCode.php?tmp=' + Math.random()); 
    });
</script>