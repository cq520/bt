<?php
$mod = 'user';
$title = '下级用户列表';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
include './user.class.php';
$lowerUserData = userClass::getLowerUser($DB,$_SESSION['userId']);
$levelData = userClass::getLevel($DB);
$levelArray = array();
foreach ($levelData as $value){ 
    $levelArray[$value['id']] = $value['levelName'];
}
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/loweruserlist.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    function edit(id){
        layer.open({
            type: 2,
            title: '更改等级USER(ID:'+id+')',
            shadeClose: true,
            shade: 0.8,
            area: ['90%', '90%'],
            content: '/user/loweruserinfo.php?id='+id
        }); 
    }
</script>