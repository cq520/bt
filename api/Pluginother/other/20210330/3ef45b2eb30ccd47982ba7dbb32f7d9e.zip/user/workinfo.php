<?php
$mod = 'user';
$title = '查看工单';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
include './user.class.php';

if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.alert("参数错误",{icon:2,shade:0.8});parent.layer.close(index);</script>');

$workData = userClass::getUserWorkid($DB, $_GET['id'], $_SESSION['userName']);

if(empty($workData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.alert("工单不存在",{icon:2,shade:0.8});parent.layer.close(index);</script>');
include '../template/'. $conf['usermub'].'/user/workinfo.html';
?>