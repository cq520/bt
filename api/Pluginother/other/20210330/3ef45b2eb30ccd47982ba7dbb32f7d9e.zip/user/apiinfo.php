<?php
$mod = 'user';
$title = '修改接口';
include '../includes/common.php';
include './user.class.php';

if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("参数错误",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');

$apiData = userClass::getApiId($DB, $_GET['id'], $_SESSION['userName']);

if(empty($apiData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.alert("接口不存在",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
include '../template/'. $conf['usermub'].'/user/apiinfo.html';
?>
<script>
    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var id = $("input[name='id']").val();
        var apiIp = $("input[name='apiIp']").val();
        var apiKey = $("input[name='apiKey']").val();
        var apiMoney = $("input[name='apiMoney']").val();
        var apiName = $("input[name='apiName']").val();
        var apiMixWeb = $("input[name='apiMixWeb']").val();
        var apiMixDb = $("input[name='apiMixDb']").val();
        var apiMixFlow = $("input[name='apiMixFlow']").val();
        var apiUseMoney = $("input[name='apiUseMoney']").val();
        var dj = $("select[name='dj']").val();
        var djurl = $("input[name='djurl']").val();
        var djuser = $("input[name='djuser']").val();
        var apiTxt = $("textarea[name='apiTxt']").val();

        if(apiIp.length < 1 || apiKey.length < 1 || apiMoney.length < 1 || apiName.length < 1 || apiMixWeb.length < 1 || apiMixDb.length < 1 || apiMixFlow.length < 1 || apiUseMoney.length < 1){
            layer.msg('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'apiinfo',
                apiIp:apiIp,
                apiKey:apiKey,
                apiMoney:apiMoney,
                id:id,
                apiName:apiName,
                apiMixWeb:apiMixWeb,
                apiMixDb:apiMixDb,
                apiMixFlow:apiMixFlow,
                dj:dj,
                djurl:djurl,
                djuser:djuser,
                apiUseMoney:apiUseMoney,
                apiTxt:apiTxt
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
</script>