<?php
$mod = 'user';
$title = '自助升级';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userUpLevel'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
$userData = userClass::getUserId($DB,$_SESSION['userId']);
$levelData = userClass::getLevel($DB);
$userLevelArray = array();
$userUpLevel = 0;
foreach ($levelData as $v){
    if($userData['levelId'] == $v['id']) {
        $userLevelArray[$userData['levelId']] = $v['levelMoney'];
        $userUpLevel = $v['upLevel'];
    }
}
$upLevelData = array();
if(empty($userData['levelId']) || $userData['levelId'] == -1){
    $upLevelData = $levelData;
}else{
    $levelNotThisIdData = userClass::getLevelNotId($DB, $userData['levelId']);
    userClass::getUpLevel($levelNotThisIdData, $upLevelData, $userUpLevel);
}
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/upLevel.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var load = layer.msg('升级中，请稍后...',{icon:16,shade:0.8,time:false});
        var levelId = $("select[name='levelId']").val();
        
        if(levelId <= 0) {
            layer.close(load);
            layer.msg('无可升级等级');
            return false;
        }
        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'upLevel',
                levelId:levelId
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                    location.reload();
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>