<?php
$mod = 'user';
$title = '对接配置';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
include './user.class.php';
$userData = userClass::getUser($DB, $_SESSION['userName']);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/accessSet.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var userKey = $("input[name='userKey']").val();
		var userDomain = <?=$conf['userDomain']?>;
        
		if(userDomain){
        var domain = $("input[name='domain']").val();
		    if(!domain){
		    layer.msg('请填写白名单');
            return false;
        }
		}
        if(userKey != '请生成对接密匙'){
            layer.confirm(
                '确定要重新生成吗？',
                function (){
                    makeKey(domain);
                }
            );
        }else{
            makeKey(domain);
        }
        return false;
    });
    function makeKey(domain){
        var load = layer.msg('生成中，请稍后...',{icon:16,shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'makeKey',
                domain:domain
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/accessSet.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>