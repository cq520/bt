<?php
$mod = 'user';
$title = '卡密列表';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userAddCarmi'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
$carmiData = userClass::getCarmiByUserId($DB,$_SESSION['userId']);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/carmilist.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    function del(id){
        layer.confirm('确定要删除吗？删除后不退款', function (){
            delCarmi(id)
        });
    }
    function delCarmi(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'delCarmi',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/carmilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>