        <!-- footer -->
            <footer id="footer" class="app-footer" role="footer">
                <div class="wrapper b-t bg-light">
                  <span class="pull-right"><a href="http://bbs.98ka.ren" >GEP <?=VERSION?></a><a href ui-scroll="app" class="m-l-sm text-muted"><i class="fa fa-long-arrow-up"></i></a></span>
                  &copy; 2020 Copyright.<a href="#" ><?=$conf['webName']?></a>
                </div>
            </footer>
        </div>
        <!-- / footer -->
        <script src="//lib.baomitu.com/jquery/3.3.1/jquery.min.js"></script>
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/oneui.core.min.js"></script>
        <script src="../assets/js/oneui.app.min.js"></script>
        <script src="../assets/vendor/layer/layer.js"></script>
        <script src="../assets/js/bootstrap.js"></script>
        <script src="../assets/js/ui-load.js"></script>
        <script src="../assets/js/ui-jp.config.js"></script>
        <script src="../assets/js/ui-jp.js"></script>
        <script src="../assets/js/ui-nav.js"></script>
        <script src="../assets/js/ui-toggle.js"></script>
    </body>
</html>
