<?php
$mod = 'user';
$title = '卡密兑换';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userExchangeCarmi'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/carmiexchange.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var load = layer.msg('兑换中，请稍后...',{icon:16,shade:0.8,time:false});
        var carmiNo = $("input[name='carmiNo']").val();
        
        if(!carmiNo) {
            
            layer.msg('请输入卡密内容');
            return false;
            
        }
        
        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'carmiExchange',
                carmiNo:carmiNo
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.reload();
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>