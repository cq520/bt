<?php
$mod = 'user';
$title = '接口购买';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userBuyApi'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
$apiData = userClass::getShowApi($DB);
$userData = userClass::getUserId($DB,$_SESSION['userId']);
$userLevelData = userClass::getLevel($DB,$userData['levelId']);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/apibuy.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $('.buy-btn').click(function (){
        var load = layer.load('1',{shade:0.8,time:false});
        var id = $(this).attr('buy');
        var num = $(this).parent().children('input').val();
        if (isNaN(num) || num < 1) {
            layer.close(load);
            layer.msg('数量有误',{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'buy',
                id:id,
                num:num
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/apicron.php?key=' + <?=$conf['cronKey']?>;
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    });
</script>