<?php
$mod = 'user';
$title = '卡密添加';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userAddCarmi'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
$levelData = userClass::getLevel($DB);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/carmiadd.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var load = layer.msg('生成中，请稍后...',{icon:16,shade:0.8,time:false});
        var carType = $("select[name='carType']").val();
        var levelId = $("select[name='levelId']").val();
        var money = $("input[name='money']").val();
        var number = $("input[name='number']").val();
        
        if(!number || number <= 0){
            layer.msg('生成数量为空或小于1');
            return false;
        }
        
        if(carType == 0 && (!money || money <= 0)){
            layer.msg('卡密金额为空或小于1');
            return false;
        }else if(carType == 1 && (!levelId || levelId <= 0)){
            layer.msg('请选择等级');
            return false;
        }else if(carType != 0 && carType != 1){
            layer.msg('卡密类型错误',{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'carmiAdd',
                carType:carType,
                levelId:levelId,
                money:money,
                number:number
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/carmilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>