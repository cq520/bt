<?php
$mod = 'user';
include '../includes/common.php';
include './user.class.php';

$userData = userClass::getUser($DB, $_SESSION['userName']);
$gonggao = userclass::gonggao($DB);
$title = '用户公告';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/noticelist.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>