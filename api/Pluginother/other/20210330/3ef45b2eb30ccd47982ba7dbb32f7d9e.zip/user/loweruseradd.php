<?php
$mod = 'user';
$title = '下级添加';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userAddLower'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
$userData = userClass::getUserId($DB,$_SESSION['userId']);
$downLevelData = array();
if($userData['levelId'] != -1){
    $levelData = userClass::getLevelNotId($DB, $userData['levelId']);
    userClass::getDownLevel($levelData, $downLevelData, $userData['levelId']);
}
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/loweruseradd.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("form").submit(function (){
        var load = layer.msg('添加中，请稍后...',{icon:16,shade:0.8,time:false});

        var userName = $("input[name='userName']").val();
        var userPwd = $("input[name='userPwd']").val();
        var userMail = $("input[name='userMail']").val();
        var levelId = $("select[name='levelId']").val();
        
        var isImgCode = <?=$conf['isImgCode']?>;

        if(userName.length < 1 || userPwd.length < 1){
            layer.msg('用户名和密码不可为空');
            return false;
        }
        
        if( !is_check_name(userName) ){
            layer.msg('用户名长度最少为3位字符且为英文');
            return false;
        }
        
        if(!is_check_mail(userMail) ){
            layer.msg('邮箱账号格式错误',{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }
        
        if(isImgCode){
		    var imgCode = $("input[name='imgCode']").val();
		    if(imgCode.length < 1){
				layer.msg('请输入图片验证码');
				return false;
			}
		}

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'userAdd',
                userName:userName,
                userPwd:userPwd,
                userMail:userMail,
                levelId:levelId,
                imgCode:imgCode
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/loweruserlist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
    function is_check_name(str) {    
        return /^[\w]{3,16}$/.test(str) 
    }
    function is_check_mail(str) {
        return /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(str)
    }
    $("#imageCode").click(function(){
       
       $(this).attr("src", '../includes/imageCode.php?tmp=' + Math.random()); 
    });
</script>