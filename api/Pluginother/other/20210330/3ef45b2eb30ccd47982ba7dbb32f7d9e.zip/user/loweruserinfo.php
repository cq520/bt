<?php
$mod = 'user';
$title = '更改下级等级';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userUpdLowerLevel'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("参数错误",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
$userData = userClass::getUserId($DB, $_GET['id']);
$loginUserData = userClass::getUserId($DB,$_SESSION['userId']);
if(empty($userData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("用户不存在",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
$downLevelData = array();
if($loginUserData['levelId'] != -1){
    $levelData = userClass::getLevel($DB);
    $userLevelArray = array();
    foreach ($levelData as $v){
        if($userData['levelId'] == $v['id']) $userLevelArray[$userData['levelId']] = $v['levelMoney'];
    }
    $levelNotThisIdData = userClass::getLevelNotId($DB, $loginUserData['levelId']);
    userClass::getDownLevel($levelNotThisIdData, $downLevelData, $loginUserData['levelId']);
}
include '../template/'. $conf['usermub'].'/user/loweruserinfo.html';
?>
<script>
    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var id = $("input[name='id']").val();
        var levelId = $("select[name='levelId']").val();

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'userinfo',
                id:id,
                levelId:levelId
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
</script>