<?php
$mod = 'user';
include '../includes/common.php';
include './user.class.php';

$hostData = userClass::getHost($DB, $_SESSION['userName']);
$title = '主机列表';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/hostlist.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>