<?php
$mod = 'user';
$title = '积分签到';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
if(!$conf['userSignin'])Tips::error('管理员未开启此功能', '/user');
include './user.class.php';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/signin.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $("#signinForm").submit(function (){
        var load = layer.msg('签到中，请稍后...',{icon:16,shade:0.8,time:false});
        var userId = $("input[name='userId']").val();

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'signin'
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.reload();
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
    
    $("#exchangeForm").submit(function (){
        var load = layer.msg('兑换中，请稍后...',{icon:16,shade:0.8,time:false});
        var signin = $("input[name='signin']").val();
        
        var exchangeMin = <?=$conf['signinExchangeMin']?>
        
        if(!signin) {
            
            layer.msg('请输入需要兑换的积分');
            return false;
            
        }
        if(exchangeMin > signin) {
            
            layer.msg('最低积分兑换值为：'+exchangeMin,{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }
        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'exchange',
                signin : signin
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.reload();
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>