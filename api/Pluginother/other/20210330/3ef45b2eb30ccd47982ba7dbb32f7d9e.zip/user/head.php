<!DOCTYPE html>
<html lang="zh-CN">
    <head>
      <meta charset="utf-8" />
       <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
       <title><?=$conf['webName']?> - <?=$title?></title>
       <link rel="stylesheet" href="../assets/css/animate.css" type="text/css" />
       <link rel="stylesheet" href="../assets/css/font-awesome.min.css" type="text/css" />
       <link rel="stylesheet" href="../assets/css/simple-line-icons.css" type="text/css" />
       <link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
       <link rel="stylesheet" href="../assets/css/mdui.min.css" />
       <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
       <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>