<?php
$mod = 'user';
$title = '用户工单';
include '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
include './user.class.php';
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/workadd.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    $(".add-work").click(function (){
        var load = layer.msg('添加中，请稍后...',{icon:16,shade:0.8,time:false});

        var type = $("select[name='type']").val();
        var title = $("input[name='title']").val();
        var content = $("textarea[name='content']").val();
        console.log(type);
        console.log(title);
        console.log(content);
        if(!type || !title || !content){
            layer.msg('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'workAdd',
                type:type,
                title:title,
                content:content
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                     setTimeout(function (){
                         location.href = '/user/worklist.php'
                     },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>