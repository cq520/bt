<?php
$mod = 'user';
$title = '接口仓库';
require_once '../includes/common.php';
if(empty($_SESSION['userId']))Tips::error('请先登录', '/user/login.php');
require_once './user.class.php';
$apiData = userClass::getApi($DB, $_SESSION['userName']);
include '../template/'. $conf['usermub'].'/user/header.html';
include '../template/'. $conf['usermub'].'/user/selfapi.html';
include '../template/'. $conf['usermub'].'/user/footer.html';
?>
<script>
    function isShow(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'isShow',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/selfapi.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
    function verify(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'verify',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/selfapi.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
    function edit(id){
        layer.open({
            type: 2,
            title: '修改API(ID:'+id+')',
            shadeClose: true,
            shade: 0.8,
            area: ['90%', '90%'],
            content: '/user/apiinfo.php?id='+id
        }); 
    }
    function del(id){
        layer.confirm('确定要删除吗？', function (){
            delApi(id)
        });
    }
    function delApi(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/user/ajax.php',
            data:{
                act:'delApi',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/user/selfapi.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6, time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>