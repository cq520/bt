<?php
require_once './common.class.php';
Tips::error('系统检测到此次请求含有IP注入风险，本次请求已被拦截','/');
?>