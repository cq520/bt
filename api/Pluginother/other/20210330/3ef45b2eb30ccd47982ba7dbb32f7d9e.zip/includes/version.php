<?php
define('VERSION', '免费版');
?>