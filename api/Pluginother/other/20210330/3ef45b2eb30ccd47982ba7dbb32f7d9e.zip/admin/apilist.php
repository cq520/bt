<?php
$mod = 'admin';
$title = '接口列表';
include '../includes/common.php';
include './admin.class.php';
$page = isset($_GET["page"])?$_GET["page"]:1;
$limit = isset($_GET["limit"])?$_GET["limit"]:10;
if(empty($_GET['keywords'])) $apiData = adminClass::getApi($DB,false,null,$page,$limit);
else $apiData = adminClass::getApi($DB,false,$_GET['keywords'],$page,$limit);
$counts = adminClass::getApiCount($DB,false,$_GET['keywords'],$page,$limit);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">

                    <div class="panel panel-info ng-scope">
                        <form>
                            <div class="input-group">
                                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-vcenter table-hover table-sm">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>接口IP</th>
                                                <th>接口价格</th>
                                                <th>调用价格</th>
                                                <th>接口名称</th>
                                                <th>最大空间</th>
                                                <th>最大数据库</th>
                                                <th>最大流量</th>
                                                <th>使用次数</th>
                                                <th>接口所有者</th>
                                                <th>是否启用</th>
                                                <th>接口状态</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($apiData as $value){ ?>
                                            <tr>
                                                <td><?=$value['id']?></td>
                                                <td><?=$value['apiIp']?></td>
                                                <td><?=$value['apiMoney']?></td>
                                                <td><?=$value['apiUseMoney']?></td>
                                                <td><?=$value['apiName']?></td>
                                                <td><?=$value['apiMixWeb']?> MB</td>
                                                <td><?=$value['apiMixDb']?> MB</td>
                                                <td><?=$value['apiMixFlow']?> GB</td>
                                                <td><?=$value['apiUse']?></td>
                                                <td><?=$value['userName']?$value['userName']:'管理员';?></td>
                                                <td>
                                                    <?php
                                                        if($value['isShow']){
                                                            echo '<a href="javascript:;" onclick="isShow(\''.$value['id'].'\')" class="btn btn-success btn-xs">启用中</a>';
                                                        }else{
                                                            echo '<a href="javascript:;" onclick="isShow(\''.$value['id'].'\')" class="badge badge-warning btn-xs">未启用</a>';
                                                        } 
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                        if(!$value['apiState']){
                                                            echo '<a href="javascript:;" onclick="verify(\''.$value['id'].'\')" class="badge badge-warning btn-xs">未知</a>';
                                                        }elseif($value['apiState'] == 1){
                                                            echo '<a href="javascript:;" onclick="verify(\''.$value['id'].'\')" class="btn btn-success btn-xs">正常</a>';
                                                        }else{
                                                            echo '<a href="javascript:;" onclick="verify(\''.$value['id'].'\')" class="btn btn-danger btn-xs">异常</a>';
                                                        }
                                                    ?>
                                                </td>
                                                <td>
                                                    <a href="javascript:;" onclick="edit('<?=$value['id']?>')" class="btn btn-primary btn-xs">修改</a>
                                                    <a href="javascript:;" onclick="del('<?=$value['id']?>')" class="btn btn-danger btn-xs">删除</a>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center m-t-lg m-b-lg">
                        <ul class="pagination pagination-md">
                            <li class="<?php if($page-1<=0)echo 'disabled';?>"><a <?php if($page-1>0){echo 'href="?page='.($page-1)."\"";}?>><i class="fa fa-chevron-left"></i></a></li>
                            <?php for($i=1;$i<=ceil($counts/$limit);$i++){?>
                                <li class="<?php if($page==$i)echo'active';?>"><a href="?page=<?=$i?>"><?=$i?></a></li>
                            <?php }?>
                            <li class="<?php if($page>=ceil($counts/$limit))echo 'disabled';?>"><a <?php if($page<ceil($counts/$limit)){echo 'href="?page='.($page+1)."\"";}?>><i class="fa fa-chevron-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
     <?php include 'foot.php';?>
<script>
    function isShow(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'isShow',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/apilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
    function verify(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'verify',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/apilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
    function edit(id){
        layer.open({
            type: 2,
            title: '修改API(ID:'+id+')',
            shadeClose: true,
            shade: 0.8,
            area: ['90%', '90%'],
            content: '/admin/apiinfo.php?id='+id
        }); 
    }
    function del(id){
        layer.confirm('确定要删除吗？', function (){
            delApi(id)
        });
    }
    function delApi(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'delApi',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/apilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>