<?php
$mod = 'admin';
$title = '用户列表';
require_once '../includes/common.php';
require_once './admin.class.php';
$page = isset($_GET["page"])?$_GET["page"]:1;
$limit = isset($_GET["limit"])?$_GET["limit"]:15;
if(empty($_GET['keywords'])) $userData = adminClass::getUser($DB,false,null,$page,$limit);
else $userData = adminClass::getUser($DB,false,$_GET['keywords'],$page,$limit);
$levelData = adminClass::getLevel($DB);
$counts = adminClass::getUserCount($DB,false,$_GET['keywords'],$page,$limit);
$levelArray = array();
foreach ($levelData as $value){ 
    $levelArray[$value['id']] = $value['levelName'];
}
require_once './header.php';
?>
        <div id="content" class="app-content" role="main">
            <div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <form>
                            <div class="input-group">
                                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-vcenter table-hover table-sm">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>用户名</th>
                                                <th>用户邮箱</th>
                                                <th>用户余额</th>
                                                <th>用户积分</th>
                                                <th>上级用户</th>
                                                <th>用户等级</th>
                                                <th>IP白名单</th>
                                                <th>用户状态</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($userData as $value){ ?>
                                        <tr>
                                            <td><?=$value['id']?></td>
                                            <td><?=$value['userName']?></td>
                                            <td><?=$value['userMail']?></td>
                                            <td><?=$value['userMoney']?></td>
                                            <td><?=$value['signin']?></td>
                                            <td><?=$value['upUserName']?$value['upUserName']:'无上级';?></td>
                                            <td><?=$levelArray[$value['levelId']] ? $levelArray[$value['levelId']] : '普通代理' ?></td>
                                            <td><a href="//m.ip138.com/iplookup.asp?ip=<?=$value['domain']?>"><?=$value['domain']?></a></td>
                                            <td>
                                                <?php
                                                    if($value['userState']){
                                                        echo '<a href="javascript:;" onclick="userState(\''.$value['id'].'\')" class="btn btn-success btn-xs">正常</a>';
                                                    }else{
                                                        echo '<a href="javascript:;" onclick="userState(\''.$value['id'].'\')"  class="btn btn-danger btn-xs">封禁</a>';
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <a href="javascript:;" onclick="edit('<?=$value['id']?>')" class="btn btn-primary btn-xs">修改</a>
                                                <a href="javascript:;" onclick="del('<?=$value['id']?>')" class="btn btn-danger btn-xs">删除</a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center m-t-lg m-b-lg">
                        <ul class="pagination pagination-md">
                            <li class="<?php if($page-1<=0)echo 'disabled';?>"><a <?php if($page-1>0){echo 'href="?page='.($page-1)."\"";}?>><i class="fa fa-chevron-left"></i></a></li>
                            <?php for($i=1;$i<=ceil($counts/$limit);$i++){?>
                                <li class="<?php if($page==$i)echo'active';?>"><a href="?page=<?=$i?>"><?=$i?></a></li>
                            <?php }?>
                            <li class="<?php if($page>=ceil($counts/$limit))echo 'disabled';?>"><a <?php if($page<ceil($counts/$limit)){echo 'href="?page='.($page+1)."\"";}?>><i class="fa fa-chevron-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    function userState(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'userState',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/userlist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
    function edit(id){
        layer.open({
            type: 2,
            title: '修改USER(ID:'+id+')',
            shadeClose: true,
            shade: 0.8,
            area: ['90%', '90%'],
            content: '/admin/userinfo.php?id='+id
        }); 
    }
    function del(id){
        layer.confirm('确定要删除吗？', function (){
            delUser(id)
        });
    }
    function delUser(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'delUser',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/userlist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>