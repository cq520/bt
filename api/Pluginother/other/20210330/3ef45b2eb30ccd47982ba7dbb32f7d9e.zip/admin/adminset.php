<?php
$mod = 'admin';
$title = '个人设置';
include '../includes/common.php';
include './admin.class.php';
$adminData = adminClass::getAdmin($DB,$_SESSION['adminUser']);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope" hidden>
                                            <div class="col-12">
                                                <input type="text" value="<?=$adminData['id']?>" name="id" class="form-control text-primary font-size-sm" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">管理员账号</label>
                                            <div class="col-12">
                                                <input type="text" value="<?=$adminData['adminUser']?>" name="adminUser" placeholder="请输入管理员账号" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">管理员密码</label>
                                            <div class="col-12">
                                                <input type="text" name="adminPwd" placeholder="请输入管理员密码(不修改请留空)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">管理员ＱＱ</label>
                                            <div class="col-12">
                                                <input type="text" value="<?=$adminData['adminQq']?>" name="adminQq" placeholder="请输入管理员ＱＱ" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    <?php include 'foot.php';?>
    </body>
</html>
<script>
    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var adminUser = $("input[name='adminUser']").val();
        var adminPwd = $("input[name='adminPwd']").val();
        var adminQq = $("input[name='adminQq']").val();
        var id = $("input[name='id']").val();

        if(adminUser.length < 1 || adminQq.length < 1){
            layer.msg('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'admininfo',
                adminUser:adminUser,
                adminPwd:adminPwd,
                adminQq:adminQq,
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/login.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>