<?php
$mod = 'admin';
$title = '修改用户';
include '../includes/common.php';
include './admin.class.php';

if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("参数错误",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');

$userData = adminClass::getUser($DB, $_GET['id']);

if(empty($userData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("用户不存在",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');

$levelData = adminClass::getLevel($DB);

?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title><?=$conf['webName']?> - <?=$title?></title>
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>
        <div id="page-container" class="sidebar-dark enable-page-overlay side-scroll">
             <div id="main-container" class="content" role="main">
                 <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope" hidden>
                                            <div class="col-12">
                                                <input type="text" name="id" class="form-control text-primary font-size-sm" value="<?=$_GET['id']?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户名</label>
                                            <div class="col-12">
                                                <input type="text" name="userName" value="<?=$userData['userName']?>" placeholder="请输入用户名" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户密码</label>
                                            <div class="col-12">
                                                <input type="text" name="userPwd" placeholder="请输入用户密码(不修改留空)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户余额</label>
                                            <div class="col-12">
                                                <input type="text" name="userMoney" value="<?=$userData['userMoney']?>" placeholder="请输入用户余额" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户邮箱</label>
                                            <div class="col-12">
                                                <input type="text" name="userMail" value="<?=$userData['userMail']?>" placeholder="请输入用户余额" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">对接域名</label>
                                            <div class="col-12">
                                                <input type="text" name="domain" value="<?=$userData['domain']?>" placeholder="请输入对接域名" class="form-control text-primary font-size-sm" autocomplete="off">
                                                </div>
                                         </div>
                                                <div class="form-group ng-scope">
                                            <label class="col-12">用户等级</label>
                                            <div class="col-12">
                                                <select class="form-control text-primary font-size-sm" name="levelId" value="<?=$userData['levelId']?>">
                                                    <option value="-1">普通代理</option>
                                                  <?php foreach ($levelData as $value){ ?>
                                                    <option value="<?=$value['id']?>" <?php if($value['id'] == $userData['levelId']) echo 'selected';?>><?=$value['levelName']?></option>
                                                  <?php } ?>
                                                </select>
                                            </div>
                                         </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <footer id="footer" class="footer bgw" role="footer">
            <div class="wrapper b-t bg-light">
              <span class="pull-right"><a href="https://jq.qq.com/?_wv=1027&k=ZvDTSB1h" >GEP</a><a href ui-scroll="app" class="m-l-sm text-muted"></a></span>
              &copy; 2020-2021 Copyright.<a href="http://bbs.98ka.ren" >GEP  <?=VERSION?> </a>
            </div>
        </footer>
    <script src="../assets/jquery/jquery/dist/jquery.js"></script>
    <script src="../assets/jquery/bootstrap/dist/js/bootstrap.js"></script>
    <script src="../assets/vendor/layer/layer.js"></script>
    <script src="../assets/js/ui-load.js"></script>
    <script src="../assets/js/ui-jp.config.js"></script>
    <script src="../assets/js/ui-jp.js"></script>
    <script src="../assets/js/ui-nav.js"></script>
    <script src="../assets/js/ui-toggle.js"></script>
    <script src="../assets/js/ui-client.js"></script>
    </body>
</html>
<script>
    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var id = $("input[name='id']").val();
        var userName = $("input[name='userName']").val();
        var userPwd = $("input[name='userPwd']").val();
        var userMoney = $("input[name='userMoney']").val();
        var userMail = $("input[name='userMail']").val();
        var domain = $("input[name='domain']").val();
        var levelId = $("select[name='levelId']").val();
        
        if( !is_check_name(userName) ){
            layer.alert('用户名长度最少为3位字符且为英文');
            return false;
        }
        
        if(!is_check_mail(userMail) ){
            layer.alert('邮箱账号格式错误',{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'userinfo',
                userName:userName,
                userPwd:userPwd,
                userMoney:userMoney,
                userMail:userMail,
                domain:domain,
                levelId:levelId,
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
    function is_check_name(str) {    
        return /^[\w]{3,16}$/.test(str) 
    }
    function is_check_mail(str) {
        return /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(str)
    }
</script>