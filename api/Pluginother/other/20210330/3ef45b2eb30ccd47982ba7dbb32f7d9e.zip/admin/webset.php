<?php
$mod = 'admin';
$title = '网站设置';
include '../includes/common.php';

if(!empty($_POST)){
    $number = '0';
    foreach ($_POST as $k => $v){
        $kData = $DB->query("SELECT * FROM `impgep_config` WHERE `k` = '$k'")->fetch(PDO::FETCH_ASSOC);
        if(empty($kData)){
            $DB->exec("INSERT INTO `impgep_config`(`k`,`v`)VALUES('$k','$v')");
        }else{
            $DB->exec("UPDATE `impgep_config` SET `v` = '$v' WHERE `k` = '$k'");
        }
    }
    Tips::success('修改成功','/admin/index.php');
}

include './header.php';
?>
        <div id="content" class="app-content" role="main">
            <div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                    	    <label class="col-12">网站监控KEY（仅限阿拉伯数字）</label>
                                    	    <div class="col-12">
                                                <input type="text" name="cronKey" placeholder="请输入监控KEY" value="<?=$conf['cronKey']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                    		<div>
                                    		    接口状态监控地址建议一天一次：
                                    		    <a href="/user/cron.php?key=<?=$conf['cronKey']?>" target="_blank" style="color:blue;"><?=($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']. '/user/cron.php?key='.$conf['cronKey']?></a>
                                    		</div>
                                    		<div>
                                    		    用户接口时长监控地址建议1-60秒一次：
                                    		    <a href="/user/apicron.php?key=<?=$conf['cronKey']?>" target="_blank" style="color:blue;"><?=($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST']. '/user/apicron.php?key='.$conf['cronKey']?></a>
                                    		</div>
                                    	</div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">网站名称</label>
                                            <div class="col-12">
                                                <input type="text" name="webName" placeholder="请输入网站名称" value="<?=$conf['webName']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">客服QQ</label>
                                            <div class="col-12">
                                                <input type="text" name="webQq" placeholder="请输入客服QQ" value="<?=$conf['webQq']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户注册</label>
                                            <div class="col-12">
                                                <select name="isUserReg" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['isUserReg'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">邮箱注册</label>
                                            <div class="col-12">
                                                <select name="isMailReg" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['isMailReg'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">图片验证</label>
                                            <div class="col-12">
                                                <select name="isImgCode" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['isImgCode'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">网站描述</label>
                                            <div class="col-12">
                                                <input type="text" name="webDescription" placeholder="请输入网站描述" value="<?=$conf['webDescription']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">网站关键字</label>
                                            <div class="col-12">
                                                <input type="text" name="webKeyword" placeholder="请输入网站关键字" value="<?=$conf['webKeyword']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口超开</label>
                                            <div class="col-12">
                                                <select name="isApiSuper" class="form-control text-primary font-size-sm">
                                                    <option value="1">允许</option>
                                                    <option value="0" <?php if($conf['isApiSuper'] == 0)echo 'selected' ?>>不允许</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易欢乐客服系统</label>
                                            <div class="form-group ng-scope">
                                                <input type="text" name="id" placeholder="请输入易欢乐id" value="<?=$conf['id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                                <input type="text" name="key" placeholder="请输入易欢乐key" value="<?=$conf['key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                             </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">首页公告</label>
                                            <div class="col-12">
                                                   <textarea name="indexText" placeholder="请输入首页公告" class="form-control text-primary font-size-sm" rows="5"><?=$conf['indexText']?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">首页底部代码</label>
                                            <div class="col-12">
                                                   <textarea name="footCode" placeholder="请输入首页底部代码" class="form-control text-primary font-size-sm" rows="5"><?=$conf['footCode']?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>