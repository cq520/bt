<?php
$mod = 'admin';
$title = '卡密添加';
include '../includes/common.php';
include './admin.class.php';
$levelData = adminClass::getLevel($DB);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">卡密类型</label>
                                            <div class="col-12">
                                                <select class="form-control text-primary font-size-sm" name="carType">
                                                    <option value="0">余额</option>
                                                    <option value="1">等级</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">等级列表</label>
                                            <div class="col-12">
                                                <select class="form-control text-primary font-size-sm" name="levelId">
                                                    <option>余额类型</option>
                                                   <?php foreach ($levelData as $value){ ?>
                                                    <option value="<?=$value['id']?>"><?=$value['levelName'].'(价格：'.$value['levelMoney'].'元)'?></option>
                                                   <?php }?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">卡密金额</label>
                                            <div class="col-12">
                                                <input type="number" step="0.01" name="money" placeholder="请输入卡密金额(等级类型不要填写)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">生成数量</label>
                                            <div class="col-12">
                                                <input type="number" name="number" value="1" placeholder="请输入生成数量" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">生成卡密</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                   </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    $("form").submit(function (){
        var load = layer.msg('生成中，请稍后...',{icon:16,shade:0.8,time:false});
        var carType = $("select[name='carType']").val();
        var levelId = $("select[name='levelId']").val();
        var money = $("input[name='money']").val();
        var number = $("input[name='number']").val();
        
        if(!number || number <= 0){
            layer.msg('生成数量为空或小于1');
            return false;
        }
        
        if(carType == 0 && (!money || money <= 0)){
            layer.msg('卡密金额为空或小于1');
            return false;
        }else if(carType == 1 && (!levelId || levelId <= 0)){
            layer.msg('请选择等级');
            return false;
        }else if(carType != 0 && carType != 1){
            layer.msg('卡密类型错误',{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'carmiAdd',
                carType:carType,
                levelId:levelId,
                money:money,
                number:number
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/carmilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>