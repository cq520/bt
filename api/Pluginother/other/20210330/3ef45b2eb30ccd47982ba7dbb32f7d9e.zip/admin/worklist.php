<?php
$mod = 'admin';
$title = '工单列表';
include '../includes/common.php';
include './admin.class.php';
$page = isset($_GET["page"])?$_GET["page"]:1;
$limit = isset($_GET["limit"])?$_GET["limit"]:15;
if(empty($_GET['keywords'])) $userworkData = adminClass::getWork($DB,false,null,$page,$limit);
else $userworkData = adminClass::getWork($DB,false,$_GET['keywords'],$page,$limit);
$counts = adminClass::getWorkCount($DB,false,$_GET['keywords'],$page,$limit);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
            <div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <form>
                            <div class="input-group">
                                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-vcenter table-hover table-sm">
                                        <thead>
                                        <tr>
                                                <th>ID</th>
                                                <th>用户名</th>
                                                <th>工单类型</th>
                                                <th>工单标题</th>
                                                <th>提交时间</th>
                                                <th>工单状态</th>
                                                <th>操作</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($userworkData as $value){ ?>
                                            <tr>
                                                <td><?=$value['id']?></td>
                                                <td><?=$value['userName']?></td>
                                                <td><?php 
                                                    switch ($value['type']) {
                                                        case '1':
                                                            // code...
                                                            echo "订单问题";
                                                            break;
                                                        case '2':
                                                            // code...
                                                            echo "账号问题";
                                                            break;
                                                        
                                                        case '3':
                                                            // code...
                                                            echo "网站问题";
                                                            break;
                                                        
                                                        case '4':
                                                            // code...
                                                            echo "其他问题";
                                                            break;
                                                        
                                                    }
                                                    
                                                ?></td>
                                            <td><?=$value['title']?></td>
                                            <td><?=$value['time']?></td>
                                            <td>
                                                <?php
                                                    if(!$value['state']){
                                                        echo '<a href="javascript:;" onclick="verify(\''.$value['id'].'\')" class="btn btn-warning btn-xs">待处理</a>';
                                                    }elseif($value['state'] == 1){
                                                        echo '<a href="javascript:;" onclick="verify(\''.$value['id'].'\')" class="btn btn-success btn-xs">已处理</a>';
                                                    }
                                                ?>
                                            </td>
                                                <td>
                                                    <a href="javascript:;" onclick="edit('<?=$value['id']?>')" class="btn btn-primary btn-xs">回复</a>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center m-t-lg m-b-lg">
                        <ul class="pagination pagination-md">
                            <li class="<?php if($page-1<=0)echo 'disabled';?>"><a <?php if($page-1>0){echo 'href="?page='.($page-1)."\"";}?>><i class="fa fa-chevron-left"></i></a></li>
                            <?php for($i=1;$i<=ceil($counts/$limit);$i++){?>
                                <li class="<?php if($page==$i)echo'active';?>"><a href="?page=<?=$i?>"><?=$i?></a></li>
                            <?php }?>
                            <li class="<?php if($page>=ceil($counts/$limit))echo 'disabled';?>"><a <?php if($page<ceil($counts/$limit)){echo 'href="?page='.($page+1)."\"";}?>><i class="fa fa-chevron-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    function edit(id){
        layer.open({
            type: 2,
            title: '回复工单(ID:'+id+')',
            shadeClose: true,
            shade: 0.8,
            area: ['90%', '90%'],
            content: '/admin/workinfo.php?id='+id
        });
    }
</script>