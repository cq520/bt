<?php
$mod = 'admin';
$title = '修改接口';
include '../includes/common.php';

if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("参数错误",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');

include './admin.class.php';

$apiData = adminClass::getApi($DB, $_GET['id']);
if(empty($apiData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("接口不存在",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title><?=$conf['webName']?> - <?=$title?></title>
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>
        <div id="main-container" class="content" role="main">
            <div class="wrapper-md">
                <div class="panel panel-info ng-scope">
                    <div class="panel-heading"><?=$title?></div>
                    <div class="block-content block-content-full">
                        <form>
                            <div class="panel-body">
                                <div class="col-lg-12">
                                    <div class="form-group ng-scope" hidden>
                                        <div class="col-12">
                                            <input type="text" name="id" class="form-control text-primary font-size-sm" value="<?=$_GET['id']?>" disabled>
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">对接类型</label>
                                        <div class="col-12">
                                           <select class="form-control text-orange" name="dj" onchange="showepayurlinput(this.value)">
                                               <option value="1">同系统对接(GEP/EPD)</option>
                                               <option value="2"<?php if($apiData['dj'] == 2)echo 'selected' ?>>安全码对接</option>
                                               <option value="3"<?php if($apiData['dj'] == 3)echo 'selected' ?>>LEP分销对接</option>
                                               </select>
                                        </div>
                                    </div>
                                    <div id="dj" style="<?php if($apiData['dj'] == 2) echo "display: none;" ?>">
                                    <div class="form-group ng-scope">
                                        <label class="col-12">对接地址（系统对接）</label>
                                        <div class="col-12">
                                            <input type="text" name="djurl" value="<?=$apiData['djurl']?>" placeholder="如：http://ep.98ka.ren/api" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">用户名（系统对接）</label>
                                        <div class="col-12">
                                            <input type="text" name="djuser"value="<?=$apiData['djuser']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                               </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">接口IP</label>
                                        <div class="col-12">
                                            <input type="text" name="apiIp" value="<?=$apiData['apiIp']?>" placeholder="请输入接口IP" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">接口KEY</label>
                                        <div class="col-12">
                                            <input type="password" name="apiKey" value="<?=$apiData['apiKey']?>" placeholder="请输入Kangle安全码或用户对接密匙" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">接口价格</label>
                                        <div class="col-12">
                                            <input type="text" name="apiMoney" value="<?=$apiData['apiMoney']?>" placeholder="请输入接口价格" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">调用价格</label>
                                        <div class="col-12">
                                            <input type="text" name="apiUseMoney" value="<?=$apiData['apiUseMoney']?>" placeholder="请输入调用价格" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">接口名称</label>
                                        <div class="col-12">
                                            <input type="text" name="apiName" value="<?=$apiData['apiName']?>" placeholder="请输入接口名称" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">最大空间限制</label>
                                        <div class="col-12">
                                             <input type="text" name="apiMixWeb" value="<?=$apiData['apiMixWeb']?>" placeholder="请输入最大空间限制" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">最大数据库限制</label>
                                        <div class="col-12">
                                            <input type="text" name="apiMixDb" value="<?=$apiData['apiMixDb']?>" placeholder="请输入最大数据库限制" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">最大流量限制</label>
                                        <div class="col-12">
                                            <input type="text" name="apiMixFlow" value="<?=$apiData['apiMixFlow']?>" placeholder="请输入最大数据库限制" class="form-control text-primary font-size-sm" autocomplete="off">
                                        </div>
                                    </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口介绍</label>
                                            <div class="col-12">
                                                   <textarea name="apiTxt" class="form-control text-primary font-size-sm" rows="5"><?=$apiData['apiTxt']?></textarea>
                                            </div>
                                        </div>
                                    <div class="form-group ng-scope">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary btn-block">修改</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>     
           <footer id="footer" class="footer bgw" role="footer">
            <div class="wrapper b-t bg-light">
              <span class="pull-right"><a href="https://jq.qq.com/?_wv=1027&k=ZvDTSB1h" >GEP</a><a href ui-scroll="app" class="m-l-sm text-muted"></a></span>
              &copy; 2020-2021 Copyright.<a href="http://bbs.98ka.ren" >GEP  <?=VERSION?> </a>
            </div>
        </footer>
        <script src="../assets/js/oneui.core.min.js"></script>
        <script src="../assets/js/oneui.app.min.js"></script>
        <script src="../assets/vendor/layer/layer.js"></script>
    </body>
</html>
<script>
	var items = $("select[default]");
	for (i = 0; i < items.length; i++) {
		$(items[i]).val($(items[i]).attr("default"));
	}
	function showepayurlinput(v){
	
		if(v == 2){

			$("#dj").hide(500);
		}else{
		    $("#dj").show(500);
		}
	}

    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var id = $("input[name='id']").val();
        var apiIp = $("input[name='apiIp']").val();
        var apiKey = $("input[name='apiKey']").val();
        var apiMoney = $("input[name='apiMoney']").val();
        var apiName = $("input[name='apiName']").val();
        var apiMixWeb = $("input[name='apiMixWeb']").val();
        var apiMixDb = $("input[name='apiMixDb']").val();
        var apiMixFlow = $("input[name='apiMixFlow']").val();
        var apiUseMoney = $("input[name='apiUseMoney']").val();
        var dj = $("select[name='dj']").val();
        var djurl = $("input[name='djurl']").val();
        var djuser = $("input[name='djuser']").val();
        var apiTxt = $("textarea[name='apiTxt']").val();

        if(apiIp.length < 1 || apiKey.length < 1 || apiMoney.length < 1 || apiName.length < 1 || apiMixWeb.length < 1 || apiMixDb.length < 1 || apiMixFlow.length < 1 || apiUseMoney.length < 1){
            layer.alert('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'apiinfo',
                apiIp:apiIp,
                apiKey:apiKey,
                apiMoney:apiMoney,
                id:id,
                apiName:apiName,
                apiTxt:apiTxt,
                apiMixWeb:apiMixWeb,
                apiMixDb:apiMixDb,
                apiMixFlow:apiMixFlow,
                dj:dj,
                djurl:djurl,
                djuser:djuser,
                apiUseMoney:apiUseMoney
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
</script>