<?php
$mod = 'admin';
$title = '用户设置';
include '../includes/common.php';

if($_REQUEST['isIpInjection']) Tips::error('系统检测本次请求含有IP注入风险，已拦截本次请求。',$_SERVER['REQUEST_URI']);
if($_REQUEST['isParameInjection']) Tips::error('系统检测本次请求含有参数注入风险，已拦截本次请求。',$_SERVER['REQUEST_URI']);

if(!empty($_POST)){
    $number = '0';
    foreach ($_POST as $k => $v){
        $kData = $DB->query("SELECT * FROM `impgep_config` WHERE `k` = '$k'")->fetch(PDO::FETCH_ASSOC);
        if(empty($kData)){
            $DB->exec("INSERT INTO `impgep_config`(`k`,`v`)VALUES('$k','$v')");
        }else{
            $DB->exec("UPDATE `impgep_config` SET `v` = '$v' WHERE `k` = '$k'");
        }
    }
    Tips::success('修改成功','/admin/index.php');
}
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">上级提成比率</label>
                                            <div class="col-12">
                                                <input type="number" step="0.01" name="upTicheng" placeholder="请输入上级提成比率" value="<?=$conf['upTicheng']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">注册获得余额</label>
                                            <div class="col-12">
                                                <input type="number" step="0.01" name="regMoney" placeholder="请输入注册获得余额" value="<?=$conf['regMoney']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许发布接口</label>
                                            <div class="col-12">
                                                <select name="userAddApi" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userAddApi'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许购买接口</label>
                                            <div class="col-12">
                                                <select name="userBuyApi" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userBuyApi'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许在线充值</label>
                                            <div class="col-12">
                                                <select name="userPayMoney" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userPayMoney'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">开启用户域名授权</label>
                                            <div class="col-12">
                                                <select name="userDomain" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userDomain'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许提交工单</label>
                                            <div class="col-12">
                                                <select name="userAddWork" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userAddWork'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许用户添加下级</label>
                                            <div class="col-12">
                                                <select name="userAddLower" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userAddLower'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许更改下级等级</label>
                                            <div class="col-12">
                                                <select name="userUpdLowerLevel" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userUpdLowerLevel'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许自助升级</label>
                                            <div class="col-12">
                                                <select name="userUpLevel" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userUpLevel'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许添加卡密</label>
                                            <div class="col-12">
                                                <select name="userAddCarmi" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userAddCarmi'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">允许后台开通主机</label>
                                            <div class="col-12">
                                                <select name="userhostadd" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userhostadd'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">开启卡密兑换</label>
                                            <div class="col-12">
                                                <select name="userExchangeCarmi" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userExchangeCarmi'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">是否开启签到系统</label>
                                            <div class="col-12">
                                                <select name="userSignin" class="form-control text-primary font-size-sm">
                                                    <option value="1">开启</option>
                                                    <option value="0" <?php if($conf['userSignin'] == 0)echo 'selected' ?>>关闭</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">签到积分最小值</label>
                                            <div class="col-12">
                                                <input type="number" name="userSigninMin" placeholder="请输入签到积分最小值" value="<?=$conf['userSigninMin']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">签到积分最大值</label>
                                            <div class="col-12">
                                                <input type="number" name="userSigninMax" placeholder="请输入签到积分最大值" value="<?=$conf['userSigninMax']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">签到积分兑换比(1余额 = 多少积分)</label>
                                            <div class="col-12">
                                                <input type="number" name="signinExchangeRatio" placeholder="请输入签到积分兑换比" value="<?=$conf['signinExchangeRatio']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">积分兑换最小值</label>
                                            <div class="col-12">
                                                <input type="number" name="signinExchangeMin" placeholder="请输入积分兑换最小值" value="<?=$conf['signinExchangeMin']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>