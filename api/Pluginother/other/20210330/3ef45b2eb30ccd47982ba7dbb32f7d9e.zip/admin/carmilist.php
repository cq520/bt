<?php
$mod = 'admin';
$title = '卡密列表';
include '../includes/common.php';
include './admin.class.php';
$page = isset($_GET["page"])?$_GET["page"]:1;
$limit = isset($_GET["limit"])?$_GET["limit"]:10;
if(empty($_GET['keywords'])) $carmiData = adminClass::getCarmi($DB,false,null,$page,$limit);
else $carmiData = adminClass::getCarmi($DB,false,$_GET['keywords'],$page,$limit);
$counts = adminClass::getCarmiCount($DB,false,$_GET['keywords'],$page,$limit);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
            <div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <form>
                            <div class="input-group">
                                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-vcenter table-hover table-sm">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>卡号</th>
                                                <th>卡号名称</th>
                                                <th>卡号金额</th>
                                                <th>创建时间</th>
                                                <th>使用时间</th>
                                                <th>使用状态</th>
                                                <th>生成用户(ID)</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($carmiData as $value){ ?>
                                            <tr>
                                                <td><?=$value['id']?></td>
                                                <td><?=$value['carmiNo']?></td>
                                                <td><?=$value['carName']?></td>
                                                <td><?=$value['money']?></td>
                                                <td><?=$value['addtime']?></td>
                                                <td><?=$value['usetime']?></td>
                                                <td>
                                                    <?php
                                                        if($value['carState'] == 1){
                                                            echo '<button class="btn btn-success btn-xs">未使用</button>';
                                                        }elseif($value['carState'] == 2){
                                                            echo '<button class="btn btn-danger btn-xs">已使用</button>';
                                                        }
                                                    ?>
                                                </td>
                                                <td><?=$value['userId'] > 0 ? $value['userId'] : '管理员'?></td>
                                                <td>
                                                    <?php if($value['carState'] == 1){ ?>
                                                        <button onclick="del('<?=$value['id']?>')" class="btn btn-danger btn-xs">删除</button>
                                                    <?php }?>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center m-t-lg m-b-lg">
                        <ul class="pagination pagination-md">
                            <li class="<?php if($page-1<=0)echo 'disabled';?>"><a <?php if($page-1>0){echo 'href="?page='.($page-1)."\"";}?>><i class="fa fa-chevron-left"></i></a></li>
                            <?php for($i=1;$i<=ceil($counts/$limit);$i++){?>
                                <li class="<?php if($page==$i)echo'active';?>"><a href="?page=<?=$i?>"><?=$i?></a></li>
                            <?php }?>
                            <li class="<?php if($page>=ceil($counts/$limit))echo 'disabled';?>"><a <?php if($page<ceil($counts/$limit)){echo 'href="?page='.($page+1)."\"";}?>><i class="fa fa-chevron-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    function del(id){
        layer.confirm('确定要删除吗？删除后不退款', function (){
            delCarmi(id)
        });
    }
    function delCarmi(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'delCarmi',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/carmilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>