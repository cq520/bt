<?php
$mod = 'admin';
$title = '接口分配';
include '../includes/common.php';
include './admin.class.php';
$apiData = adminClass::getApi($DB);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口列表</label>
                                            <div class="col-12">
                                                <select name="ip" class="form-control text-primary font-size-sm">
													<?php foreach ($apiData as $value) { ?>
                                                    <option value="<?=$value['apiIp']?>"><?=$value['apiIp']?> - <?=$value['apiName']?></option>
													<?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户名</label>
                                            <div class="col-12">
                                                <input type="text" name="userName" placeholder="请输入用户名" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">使用时长（/天）</label>
                                            <div class="col-12">
                                                <input type="text" name="useLength" placeholder="请输入使用时长" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">划拨</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    $("form").submit(function (){
        var ip = $("select[name='ip']").val();
        var userName = $("input[name='userName']").val();
        var useLength = $("input[name='useLength']").val();

        if(ip.length < 1 || userName.length < 1){
            layer.msg('不可为空');
            return false;
        }
        var load = layer.msg('分配中，请稍后...',{icon:16,shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'./ajax.php',
            data:{
                act:'apidis',
				userName:userName,
				ip:ip,
				useLength:useLength
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = './apilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>