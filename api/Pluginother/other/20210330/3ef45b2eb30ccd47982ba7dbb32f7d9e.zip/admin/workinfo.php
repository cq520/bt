<?php
$mod = 'admin';
$title = '回复工单';
include '../includes/common.php';
include './admin.class.php';
$workData = adminClass::getWork($DB, $_GET['id']);
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title><?=$conf['webName']?> - <?=$title?></title>
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>
        <div id="main-container" class="content" role="main">
            <div class="wrapper-md">
                <div class="panel panel-info ng-scope">
                    <div class="panel-heading"><?=$title?></div>
                    <div class="block-content block-content-full">
                        <form>
                            <div class="panel-body">
                                <div class="col-lg-12">
                                    <div class="form-group ng-scope" hidden>
                                        <div class="col-12">
                                            <input type="text" name="id" class="form-control text-primary font-size-sm" value="<?=$_GET['id']?>" disabled>
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">工单类型</label>
                                        <div class="col-12">
                                            <input type="text" value="<?php 
                                            switch ($workData['type']) {
                                                case '1':
                                                    // code...
                                                    echo "订单问题";
                                                    break;
                                                case '2':
                                                    // code...
                                                    echo "账号问题";
                                                    break;
                                                
                                                case '3':
                                                    // code...
                                                    echo "网站问题";
                                                    break;
                                                
                                                case '4':
                                                    // code...
                                                    echo "其他问题";
                                                    break;
                                                
                                            }
                                            
                                        ?>" name="type" class="form-control text-primary font-size-sm" autocomplete="off" disabled>
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">工单标题</label>
                                        <div class="col-12">
                                            <input type="text" value="<?=$workData['title']?>" name="title" class="form-control text-primary font-size-sm" autocomplete="off" disabled>
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">用户工单内容</label>
                                        <div class="col-12">
                                            <input type="text" value="<?=$workData['content']?>" name="content" class="form-control text-primary font-size-sm" autocomplete="off" disabled>
                                    </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                        <label class="col-12">工单回复内容</label>
                                        <div class="col-12">
                                         <textarea name="reply" class="form-control text-primary font-size-sm" placeholder="请填入回复内容，优秀的老板是从对待每一个用户开始..." rows="5"><?=$workData['reply']?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group ng-scope">
                                         <div class="col-12">
                                            <button type="submit" class="btn btn-primary btn-block">回复工单</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
            <footer id="footer" class="footer bgw" role="footer">
            <div class="wrapper b-t bg-light">
              <span class="pull-right"><a href="https://jq.qq.com/?_wv=1027&k=ZvDTSB1h" >GEP</a><a href ui-scroll="app" class="m-l-sm text-muted"></a></span>
              &copy; 2020-2021 Copyright.<a href="http://bbs.98ka.ren" >GEP  <?=VERSION?> </a>
            </div>
        </footer>
        <script src="../assets/js/oneui.core.min.js"></script>
        <script src="../assets/js/oneui.app.min.js"></script>
        <script src="../assets/vendor/layer/layer.js"></script>
    </body>
</html>
<script>
    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('回复中，请稍后...',{icon:16,shade:0.8,time:false});
        
        var id = $("input[name='id']").val();
        var title = $("input[name='title']").val();
        var content = $("input[name='content']").val();
        var reply = $("textarea[name='reply']").val();
        var state = $("1").val();
        
        if(reply.length < 1){
            layer.msg('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'workinfo',
                title:title,
                content:content,
                id:id,
                reply:reply,
                state:1
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
</script>