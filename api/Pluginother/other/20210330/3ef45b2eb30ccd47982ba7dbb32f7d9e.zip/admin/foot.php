      <!-- footer -->
      <footer id="footer" class="app-footer" role="footer">
                <div class="wrapper b-t bg-light">
                  <span class="pull-right"><a href="https://jq.qq.com/?_wv=1027&k=ZvDTSB1h" >GEP</a><a href ui-scroll="app" class="m-l-sm text-muted"><i class="fa fa-long-arrow-up"></i></a></span>
                  &copy; 2020-2021 Copyright.<a href="http://bbs.98ka.ren" >GEP  <?=VERSION?> </a>
                </div>
            </footer>
        </div>
  <!-- / footer -->
    <script src="../assets/jquery/jquery/dist/jquery.js"></script>
    <script src="../assets/jquery/bootstrap/dist/js/bootstrap.js"></script>
    <script src="../assets/vendor/layer/layer.js"></script>
    <script src="../assets/js/ui-load.js"></script>
    <script src="../assets/js/ui-jp.config.js"></script>
    <script src="../assets/js/ui-jp.js"></script>
    <script src="../assets/js/ui-nav.js"></script>
    <script src="../assets/js/ui-toggle.js"></script>
    <script src="../assets/js/ui-client.js"></script>
    </body>
</html>