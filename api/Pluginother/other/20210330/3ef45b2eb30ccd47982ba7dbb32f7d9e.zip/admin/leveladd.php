<?php
$mod = 'admin';
$title = '等级添加';
include '../includes/common.php';
include './admin.class.php';
$upLevelData = adminClass::getLevel($DB);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                         <div class="form-group ng-scope">
                                            <label class="col-12">等级名称</label>
                                            <div class="col-12">
                                                <input type="text" name="levelName" placeholder="请输入等级名称" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">优惠折数</label>
                                            <div class="col-12">
                                                <input type="number" step="0.01" name="levelFolds" placeholder="请输入优惠折数(0.1代表1折)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">购买金额</label>
                                            <div class="col-12">
                                                <input type="number" step="0.01" name="levelMoney" placeholder="请输入等级购买金额" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">上级等级</label>
                                            <div class="col-12">
                                                <select class="form-control text-primary font-size-sm" name="upLevel">
                                                    <option value="-1">无上级</option>
                                                  <?php foreach ($upLevelData as $value){ ?>
                                                     <option value="<?=$value['id']?>"><?=$value['levelName']?></option>
                                                  <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">添加</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    $("form").submit(function (){
        var load = layer.msg('添加中，请稍后...',{icon:16,shade:0.8,time:false});

        var levelName = $("input[name='levelName']").val();
        var levelFolds = $("input[name='levelFolds']").val();
        var levelMoney = $("input[name='levelMoney']").val();
        var upLevel = $("select[name='upLevel']").val();

        if(levelName.length < 1 || levelFolds.length < 1){
            layer.msg('所有项不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'levelAdd',
                levelName:levelName,
                levelFolds:levelFolds,
                levelMoney:levelMoney,
                upLevel:upLevel
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/levellist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>