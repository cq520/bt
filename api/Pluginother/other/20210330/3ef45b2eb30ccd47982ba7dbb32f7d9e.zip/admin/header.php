<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title><?=$conf['webName']?> - <?=$title?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
</head>
<body>
<div class="app app-header-fixed ">
    <!-- header -->
  <header id="header" class="app-header navbar" role="menu">
      <!-- navbar header -->
      <div class="navbar-header bg-dark">
        <button class="pull-right visible-xs dk" ui-toggle-class="show" target=".navbar-collapse">
          <i class="glyphicon glyphicon-cog"></i>
        </button>
        <button class="pull-right visible-xs" ui-toggle-class="off-screen" target=".app-aside" ui-scroll="app">
          <i class="glyphicon glyphicon-align-justify"></i>
        </button>
        <!-- brand -->
        <a href="#" class="navbar-brand text-lt">
          <i class="fa fa-btc"></i>
          <img src="logo.png" alt="." class="hide">
              <span class="hidden-folded m-l-xs">GEP</span>
        </a>
        <!-- / brand -->
      </div>
      <!-- / navbar header -->
      <!-- navbar collapse -->
      <div class="collapse pos-rlt navbar-collapse box-shadow bg-white-only">
       <!-- buttons -->
        <div class="nav navbar-nav hidden-xs">
          <a href="#" class="btn no-shadow navbar-btn" ui-toggle="app-aside-folded" target=".app">
            <i class="fa fa-dedent fa-fw text"></i>
            <i class="fa fa-indent fa-fw text-active"></i>
          </a>
          <a href="#" class="btn no-shadow navbar-btn" ui-toggle-class="show" target="#aside-user">
            <i class="icon-user fa-fw"></i>
          </a>
        </div>
        <!-- / buttons -->
        <!-- search form -->
        <form class="navbar-form navbar-form-sm navbar-left shift" ui-shift="prependTo" data-target=".navbar-collapse" role="search" ng-controller="TypeaheadDemoCtrl">
          <div class="form-group">
            <div class="input-group">
                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
              <span class="input-group-btn">
                <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </div>
        </form>
        <!-- / search form -->
        <!-- nabar right -->
        <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">
              <i class="icon-bell fa-fw"></i>
              <span class="visible-xs-inline">Notifications</span>
              <span class="badge badge-sm up bg-danger pull-right-xs">2</span>
            </a>
          </li>
          <li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle clear" data-toggle="dropdown">
              <span class="thumb-sm avatar pull-right m-t-n-sm m-b-n-sm m-l-sm">
                <img src="//q1.qlogo.cn/g?b=qq&nk=<?=$_SESSION['adminQq']?>&s=100" alt="gep">
                <i class="on md b-white bottom"></i>
              </span>
              <span class="hidden-sm hidden-md"><?=$_SESSION['adminUser']?></span> <b class="caret"></b>
            </a>
            <!-- dropdown -->
            <ul class="dropdown-menu animated fadeInRight w">
              <li>
                <a href>
                  <a href="/admin/webset.php">
                  <span>网站设置</span>
                </a>
                </a>
              </li>
              <li>
                <a href>
                  <a href="/admin/adminset.php">
                  <span>个人设置</span>
                </a>
                </a>
              </li>
              <li class="divider"></li>
              <li>
                <a href>
                  <a href="/admin/login.php?logout">
                  <span>注销登录</span>
                  </a>
                </a>
              </li>
            </ul>
            </li>
            </ul>
        <!-- / navbar right -->
      </div>
      <!-- / navbar collapse -->
  </header>
  <!-- / header -->
  
    <!-- aside -->
  <aside id="aside" class="app-aside hidden-xs bg-dark">
      <div class="aside-wrap">
        <div class="navi-wrap">
          <!-- user -->
          <div class="clearfix hidden-xs text-center hide" id="aside-user">
            <div class="dropdown wrapper">
              <a href="/admin">
                <span class="thumb-lg w-auto-folded avatar m-t-sm">
                  <img src="//q1.qlogo.cn/g?b=qq&nk=<?=$_SESSION['adminQq']?>&s=100" class="img-full" alt="...">
                </span>
              </a>
              <a href="#" data-toggle="dropdown" class="dropdown-toggle hidden-folded">
                <span class="clear">
                  <span class="block m-t-sm">
                    <strong class="font-bold text-lt"><?=$_SESSION['adminUser']?></strong> 
                    <b class="caret"></b>
                  </span>
                  <span class="text-muted text-xs block">小弟数量：<?=Counts::table($DB,'impgep_user')?></span>
                </span>
              </a>
              <!-- dropdown -->
              <ul class="dropdown-menu animated fadeInRight w hidden-folded">
                <li class="wrapper b-b m-b-sm bg-info m-t-n-xs">
                  <span class="arrow top hidden-folded arrow-info"></span>
                  <div>
                    <p>看一下你打下的江山吧！</p>
                  </div>
                  <div class="progress progress-xs m-b-none dker">
                    <div class="progress-bar bg-white" data-toggle="tooltip" data-original-title="50%" style="width: 50%"></div>
                  </div>
                </li>
                <li>
                  <a href="/admin/userlist.php">用户列表
                  <span class="badge bg-danger pull-right"><?=Counts::table($DB,'impgep_user')?></span>
                  </a>
                </li>
                <li>
                  <li>
                  <a href="/admin/apilist.php">接口列表
                  <span class="badge bg-danger pull-right"><?=Counts::table($DB,'impgep_api')?></span>
                  </a>
                </li>
                <li class="divider"></li>
                <li>
                  <a href="/admin/orderlist.php">今日订单
                  <span class="badge bg-danger pull-right"><?=Counts::sumDay($DB,'impgep_pay','money',date('Y-m-d'))?Counts::sumDay($DB,'impgep_pay','money',date('Y-m-d')):'0.00';?></span>
                  </a>
                </li>
                <li>
                  <li>
                  <a href="/admin/hostlist.php">主机列表
                  <span class="badge bg-danger pull-right"><?=Counts::sum($DB,'impgep_api','apiUse')?Counts::sum($DB,'impgep_api','apiUse'):'0';?></span>
                  </a>
                </li>
              </ul>
              <!-- / dropdown -->
            </div>
            <div class="line dk hidden-folded"></div>
          </div>
          <!-- / user -->

           <!-- nav -->
          <nav ui-nav class="navi clearfix">
            <ul class="nav">
              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>导航</span>
              </li>
              <li>
                <a href="/admin">
                  <i class="glyphicon glyphicon-home icon text-primary-dker"></i>
				  <b class="label bg-info pull-right">N</b>
                  <span class="font-bold">仪表盘</span>
                </a>
              </li>
              <li>
                <a href="/admin/myversion.php">
                  <i class="glyphicon glyphicon-credit-card icon text-cloud-download"></i>
                  <span class="font-bold">版本信息</span>
                </a>
              </li>
              <li>
                <a href class="auto">      
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-leaf icon text-success-lter"></i>
                  <span>基础设置</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>基础设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/adminset.php">
                      <span>个人设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/webset.php">
                      <span>网站设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/templatelist.php">
                      <span>模板设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/userset.php">
                      <span>用户设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/mailset.php">
                      <span>邮箱设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/payset.php">
                      <span>支付设置</span>
                    </a>
                  </li>
                  </ul>
                  </li>
              <li>
              <a href class="auto">      
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-shopping-cart icon text-success-lter"></i>
                  <span>资源下载</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>资源下载</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/buystore.php">
                      <span>购买资源</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/installstore.php">
                      <span>安装资源</span>
                    </a>
                  </li>
                  </ul>
                  </li>
                  <li>
                <a href class="auto">      
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-send icon text-success-lter"></i>
                  <span>模板设置</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>模板设置</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/index-template.php">
                      <span>首页模板</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/user-template.php">
                      <span>登入注册模板</span>
                    </a>
                  </li>
                  </ul>
                  </li>
              <li class="line dk"></li>

              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>用户</span>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-bookmark"></i>
                  <span>卡密管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>卡密管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/carmilist.php">
                      <span>卡密列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/carmiadd.php">
                      <span>卡密添加</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-user"></i>
                  <span>用户管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>用户管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/userlist.php">
                  <b class="badge bg-info pull-right"><?=Counts::table($DB,'impgep_user')?></b>
                      <span>用户列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/useradd.php">
                      <span>用户添加</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/orderlist.php">
                      <b class="badge bg-success pull-right"><?=Counts::table($DB,'impgep_pay')?></b>
                      <span>用户订单</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/worklist.php">
                      <b class="badge bg-success pull-right"><?=Counts::table($DB,'impgep_work')?></b>
                      <span>用户工单</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
              <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-tower"></i>
                  <span>用户等级</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>用户等级</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/levellist.php">
                  <b class="badge bg-info pull-right"><?=Counts::table($DB,'impgep_level')?></b>
                      <span>等级列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/leveladd.php">
                      <span>等级添加</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-bullhorn"></i>
                  <span>公告管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>公告管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/noticelist.php">
                      <span>公告列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/noticeadd.php">
                      <span>公告添加</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="line dk"></li>
              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">
                <span>产品</span>
              </li>
              <li>
               <a href="/admin/forapi.php">
                  <i class="glyphicon glyphicon-thumbs-up"></i>
                  <span class="font-bold">推荐货源</span>
                </a>
                </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-edit"></i>
                  <span>接口管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>接口管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/apilist.php">
                <b class="badge bg-info pull-right"><?=Counts::table($DB,'impgep_api')?></b>
                      <span>接口列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/apiadd.php">
                      <span>接口添加</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/apidis.php">
                      <span>接口分配</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
                <a href class="auto">
                  <span class="pull-right text-muted">
                    <i class="fa fa-fw fa-angle-right text"></i>
                    <i class="fa fa-fw fa-angle-down text-active"></i>
                  </span>
                  <i class="glyphicon glyphicon-hdd"></i>
                  <span>主机管理</span>
                </a>
                <ul class="nav nav-sub dk">
                  <li class="nav-sub-header">
                    <a href>
                      <span>主机管理</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/hostlist.php">
                <b class="badge bg-info pull-right"><?=Counts::table($DB,'impgep_host')?></b>
                      <span>主机列表</span>
                    </a>
                  </li>
                  <li>
                    <a href="/admin/hostadd.php">
                      <span>主机添加</span>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="line dk hidden-folded"></li>

              <li class="hidden-folded padder m-t m-b-sm text-muted text-xs">          
                <span>交流</span>
              </li>  
              <li>
                <a href="//wpa.qq.com/msgrd?v=3&uin=2477581302&site=qq&menu=yes">
                  <i class="icon-user icon text-success-lter"></i>
                  <b class="badge bg-success pull-right">反馈</b>
                  <span>联系作者</span>
                </a>
              </li>
              <li>
                <a href="//bbs.98ka.ren">
                  <i class="icon-question icon"></i>
                  <span>Documents</span>
                </a>
              </li>
            </ul>
          </nav>
          <!-- nav -->

          <!-- aside footer -->
          <div class="wrapper m-t">
            <div class="text-center-folded">
              <span class="pull-right pull-none-folded">60%</span>
              <span class="hidden-folded">Milestone</span>
            </div>
            <div class="progress progress-xxs m-t-sm dk">
              <div class="progress-bar progress-bar-info" style="width: 60%;">
              </div>
            </div>
            <div class="text-center-folded">
              <span class="pull-right pull-none-folded">35%</span>
              <span class="hidden-folded">Release</span>
            </div>
            <div class="progress progress-xxs m-t-sm dk">
              <div class="progress-bar progress-bar-primary" style="width: 35%;">
              </div>
            </div>
          </div>
          <!-- / aside footer -->
        </div>
      </div>
  </aside>
  <!-- / aside -->