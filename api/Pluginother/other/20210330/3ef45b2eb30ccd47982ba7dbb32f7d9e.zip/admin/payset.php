<?php
$mod = 'admin';
$title = '支付配置';
include '../includes/common.php';

if(!empty($_POST)){
    $number = '0';
    foreach ($_POST as $k => $v){
        $kData = $DB->query("SELECT * FROM `impgep_config` WHERE `k` = '$k'")->fetch(PDO::FETCH_ASSOC);
        if(empty($kData)){
            $DB->exec("INSERT INTO `impgep_config`(`k`,`v`)VALUES('$k','$v')");
        }else{
            $DB->exec("UPDATE `impgep_config` SET `v` = '$v' WHERE `k` = '$k'");
        }
    }
    Tips::success('修改成功','/admin/index.php');
}
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading">支付设置</div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">QQ</label>
                                            <div class="col-12">
                                                <select name="qqpay" class="form-control text-primary font-size-sm" >  
                                                    <option value="0" >关闭</option>
                                                    <option value="1"<?php if($conf['qqpay'] == '1')echo 'selected' ?>>官方支付</option>
                                                    <option value="2" <?php if($conf['qqpay'] == '2')echo 'selected' ?>>易支付</option>
                                                    <option value="3" <?php if($conf['qqpay'] == '3')echo 'selected' ?>>码支付</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">微信</label>
                                            <div class="col-12">
                                                <select name="wxpay" class="form-control text-primary font-size-sm">
                                                    <option value="0" >关闭</option>
                                                    <option value="1"<?php if($conf['wxpay'] == '1')echo 'selected' ?>>官方支付</option>
                                                    <option value="2" <?php if($conf['wxpay'] == '2')echo 'selected' ?>>易支付</option>
                                                    <option value="3" <?php if($conf['wxpay'] == '3')echo 'selected' ?>>码支付</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">支付宝</label>
                                            <div class="col-12">
                                                <select name="alipay" class="form-control text-primary font-size-sm">
                                                    <option value="0" >关闭</option>
                                                    <option value="1"<?php if($conf['alipay'] == '1')echo 'selected' ?>>官方支付</option>
                                                    <option value="2" <?php if($conf['alipay'] == '2')echo 'selected' ?>>易支付</option>
                                                    <option value="3" <?php if($conf['alipay'] == '3')echo 'selected' ?>>码支付</option>
                                                    <option value="4" <?php if($conf['alipay'] == '4')echo 'selected' ?>>当面付</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                 <div id="qqpay" style="<?php if($conf['qqpay'] == 0) echo "display: none;" ?>">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading">QQ支付设置</div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                  <div id="qqpay" style="<?php if($conf['qqpay'] != 1) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">QQ钱包MCHID</label>
                                            <div class="col-12">
                                                <input type="text" name="qqpay1id" placeholder="请输入您的QQ钱包MCHID" value="<?=$conf['qqpay1id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">QQ钱包MCHKEY</label>
                                            <div class="col-12">
                                                <input type="text" name="" placeholder="请输入您的QQ钱包MCHKEY" value="<?=$conf['qqpay1key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                         </div>
                                       <div id="qqpay" style="<?php if($conf['qqpay'] != 2) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                       	<label class="col-12">易支付接口</label>
                                            <div class="col-12">
                                                <input type="text" name="qqpayurl" placeholder="请输入您的易支付接口(前有http 后有 /)" value="<?=$conf['qqpayurl']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
    				                  	</div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易支付商户ID</label>
                                            <div class="col-12">
                                                <input type="text" name="qqpay2id" placeholder="请输入您的易支付商户ID" value="<?=$conf['qqpay2id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易支付商户KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="qqpay2key" placeholder="请输入您的易支付商户KEY" value="<?=$conf['qqpay2key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        </div>
                                      <div id="qqpay" style="<?php if($conf['qqpay'] != 3) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">码支付ID</label>
                                            <div class="col-12">
                                                <input type="text" name="qqpay3id" placeholder="请输入您的码支付ID" value="<?=$conf['qqpay3id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">码支付KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="qqpay3key" placeholder="请输入您的码支付KEY" value="<?=$conf['qqpay3key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                            </div>
                                          <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    </div>
                 <div id="wxpay" style="<?php if($conf['wxpay'] == 0) echo "display: none;" ?>">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading">微信支付设置</div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                     <div id="wxpay" style="<?php if($conf['wxpay'] != 1) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">微信支付APPID</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay1appid" placeholder="请输入您的微信支付APPID" value="<?=$conf['wxpay1appid']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">微信支付MCHID</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay1id" placeholder="请输入您的微信支付MCHID" value="<?=$conf['wxpay1id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">微信支付KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay1key" placeholder="请输入您的微信支付KEY" value="<?=$conf['wxpay1key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">微信支付APPSECRET</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay1cret" placeholder="请输入您的微信支付APPSECRET" value="<?=$conf['wxpay1cret']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                            </div>
                                     <div id="wxpay" style="<?php if($conf['wxpay'] != 2) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                                	<label class="col-12">易支付接口</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpayurl" placeholder="请输入您的易支付接口(前有http 后有 /)" value="<?=$conf['wxpayurl']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
    				                  	</div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易支付商户ID</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay2id" placeholder="请输入您的易支付商户ID" value="<?=$conf['wxpay2id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易支付商户KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay2key" placeholder="请输入您的易支付商户KEY" value="<?=$conf['wxpay2key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        </div>
                                     <div id="wxpay" style="<?php if($conf['wxpay'] != 3) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">码支付ID</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay3id" placeholder="请输入您的码支付ID" value="<?=$conf['wxpay3id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">码支付KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="wxpay3key" placeholder="请输入您的码支付KEY" value="<?=$conf['wxpay3key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                            </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                 </div>
                 <div id="alipay" style="<?php if($conf['alipay'] == 0) echo "display: none;" ?>">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading">支付宝支付设置</div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                 <div id="alipay" style="<?php if($conf['alipay'] != 1) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">支付宝合作身份者ID</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay1id" placeholder="请输入您的支付宝合作身份者ID" value="<?=$conf['alipay1id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">支付宝收款账号</label>
                                            <div class="col-12">
                                                <input type="text" name="alipayuser" placeholder="请输入您的支付宝收款账号" value="<?=$conf['alipayuser']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">支付宝安全校验码</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay1key" placeholder="请输入您的支付宝安全校验码" value="<?=$conf['alipay1key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                            </div>
                 <div id="alipay" style="<?php if($conf['alipay'] != 2) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                                	<label class="col-12">易支付接口</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay2url" placeholder="请输入您的易支付接口(前有http 后有 /)" value="<?=$conf['alipay2url']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
    				                  	</div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易支付商户ID</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay2id" placeholder="请输入您的易支付商户ID" value="<?=$conf['alilayurl']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">易支付商户KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay2key" placeholder="请输入您的易支付商户KEY" value="<?=$conf['alipay2key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        </div>
                 <div id="alipay" style="<?php if($conf['alipay'] != 3) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">码支付ID</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay3id" placeholder="请输入您的码支付ID" value="<?=$conf['alipay3id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">码支付KEY</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay3key" placeholder="请输入您的码支付KEY" value="<?=$conf['alipay3key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                            </div>
                 <div id="alipay" style="<?php if($conf['alipay'] != 4) echo "display: none;" ?>">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">APPID</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay4id" placeholder="请输入您的APPID" value="<?=$conf['alipay4id']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">支付宝公钥</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay3key" placeholder="请输入您的支付宝公钥" value="<?=$conf['alipay3key']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">商户私钥</label>
                                            <div class="col-12">
                                                <input type="text" name="alipay3keys" placeholder="请输入您的商户私钥" value="<?=$conf['alipay3keys']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                            </div>
                                            
                                        </div>
                                            <div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            
                                        </div>
                                    </div>
                                </div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
    <?php include 'foot.php';?>