<?php
$mod = 'admin';
$title = '主机列表';
include '../includes/common.php';
include './admin.class.php';
$page = isset($_GET["page"])?$_GET["page"]:1;
$limit = isset($_GET["limit"])?$_GET["limit"]:10;
if(empty($_GET['keywords'])) $hostData = adminClass::getHost($DB,false,null,$page,$limit);
else $hostData = adminClass::getHost($DB,false,$_GET['keywords'],$page,$limit);
$counts = adminClass::getHostCount($DB,false,$_GET['keywords'],$page,$limit);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <form>
                            <div class="input-group">
                                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-vcenter table-hover table-sm">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>主机IP</th>
                                                <th>主机名称</th>
                                                <th>主机密码</th>
                                                <th>空间大小</th>
                                                <th>数据库大小</th>
                                                <th>开通用户</th>
                                                <th>主机状态</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($hostData as $value){ ?>
                                        <tr>
                                            <td><?=$value['id']?></td>
                                            <td><?=$value['hostIp']?></td>
                                            <td><?=$value['hostName']?></td>
                                            <td><?=$value['hostPwd']?></td>
                                            <td><?=$value['hostWebSize']?> MB</td>
                                            <td><?=$value['hostDbSize']?> MB</td>
                                            <td><?=$value['userName']?$value['userName']:'管理员';?></td>
                                            <td>
                                                <?php
                                                    if(!$value['hostState']){
                                                        echo '<a href="javascript:;" onclick="hostState(\''.$value['hostName'].'\',\''.$value['hostIp'].'\',\'1\')" class="btn btn-success btn-xs">正常</a>';
                                                    }else{
                                                        echo '<a href="javascript:;" onclick="hostState(\''.$value['hostName'].'\',\''.$value['hostIp'].'\',\'0\')" class="btn btn-danger btn-xs">非正常</a>';
                                                    } 
                                                ?>
                                            </td>
                                            <td>
                                                <form style="display:inline;" action="http://<?=$value['hostIp']?>:3312/vhost/index.php?c=session&a=login" method="post" target="_blank"><input type="hidden" name="username" value="<?=$value['hostName']?>" /><input type="hidden" name="passwd" value="<?=$value['hostPwd']?>" /><button type="submit" class="btn btn-primary btn-xs">登录</button></form>
                                                <a href="javascript:;" onclick="del('<?=$value['hostName']?>','<?=$value['hostIp']?>')" class="btn btn-danger btn-xs">删除</a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="text-center m-t-lg m-b-lg">
                            <ul class="pagination pagination-md">
                                <li class="<?php if($page-1<=0)echo 'disabled';?>"><a <?php if($page-1>0){echo 'href="?page='.($page-1)."\"";}?>><i class="fa fa-chevron-left"></i></a></li>
                                <?php for($i=1;$i<=ceil($counts/$limit);$i++){?>
                                    <li class="<?php if($page==$i)echo'active';?>"><a href="?page=<?=$i?>"><?=$i?></a></li>
                                <?php }?>
                                <li class="<?php if($page>=ceil($counts/$limit))echo 'disabled';?>"><a <?php if($page<ceil($counts/$limit)){echo 'href="?page='.($page+1)."\"";}?>><i class="fa fa-chevron-right"></i></a></li>
                            </ul>
                        </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    function hostState(hostName,hostIp,hostState){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/api/index.php',
            data:{
                act:'SuspendAccount',
                hostName:hostName,
                hostIp:hostIp,
                hostState:hostState,
                admin:'1'
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/hostlist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
    function del(hostName,hostIp){
        layer.confirm('确定要删除吗？', function (){
            delApi(hostName,hostIp)
        });
    }
    function delApi(hostName,hostIp){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/api/index.php',
            data:{
                act:'TerminateAccount',
                hostName:hostName,
                hostIp:hostIp,
                admin:'1'
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/hostlist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
    }
</script>