<?php
$mod = 'admin';
$title = '接口添加';
include '../includes/common.php';
include './admin.class.php';
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                         <div class="form-group ng-scope">
                                            <label class="col-12">对接类型</label>
                                            <div class="col-12">
                                                <select class="form-control text-primary font-size-sm" name="dj" onchange="showepayurlinput(this.value)">
                                                    <option value="2">安全码对接</option>
                                                    <option value="1">同系统对接(GEP/EPD)</option>
                                                    <option value="3">LEP分销对接</option>
                                                </select>
                                            </div>
                                        </div>
                                       <div  id="ydj" style="display: none;">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">对接地址</label>
                                            <div class="col-12">
                                                <input type="text" name="djurl" placeholder="如：http://ep.98ka.ren/api" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户名</label>
                                            <div class="col-12">
                                                <input type="text" name="djuser" placeholder="请输入用户名" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口KEY</label>
                                            <div class="col-12">
                                                <input type="password" name="apiKey" placeholder="请输入Kangle安全码或用户对接密匙" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口IP</label>
                                            <div class="col-12">
                                                <input type="text" name="apiIp" placeholder="请输入接口IP" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口价格</label>
                                            <div class="col-12">
                                                <input type="number" step="0.01" name="apiMoney" placeholder="请输入接口价格" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">接口介绍</label>
                                            <div class="col-12">
                                                   <textarea name="apiTxt" placeholder="请输入接口介绍" class="form-control text-primary font-size-sm" rows="5"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">添加</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
	var items = $("select[default]");
	for (i = 0; i < items.length; i++) {
		$(items[i]).val($(items[i]).attr("default"));
	}
	function showepayurlinput(v){
	
		if(v == 2){

			$("#ydj").hide(500);
		}else{
			$("#ydj").show(500);
			
		}
	}
</script>
<script>
    $("form").submit(function (){
        var load = layer.msg('添加中，请稍后...',{icon:16,shade:0.8,time:false});

        var apiIp = $("input[name='apiIp']").val();
        var apiKey = $("input[name='apiKey']").val();
        var dj = $("select[name='dj']").val();
        var djurl = $("input[name='djurl']").val();
        var djuser = $("input[name='djuser']").val();
        var apiMoney = $("input[name='apiMoney']").val();
        var apiTxt = $("textarea[name='apiTxt']").val();

        if(apiIp.length < 1 || apiKey.length < 1 || apiMoney.length < 1){
            layer.msg('不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'apiAdd',
                apiIp:apiIp,
                apiKey:apiKey,
                dj:dj,
                djurl:djurl,
                djuser:djuser,
                apiMoney:apiMoney,
                apiTxt:apiTxt
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/apilist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
</script>