<?php
$mod = 'admin';
$title = '邮箱设置';
include '../includes/common.php';

if(!empty($_POST)){
    $number = '0';
    foreach ($_POST as $k => $v){
        $kData = $DB->query("SELECT * FROM `impgep_config` WHERE `k` = '$k'")->fetch(PDO::FETCH_ASSOC);
        if(empty($kData)){
            $DB->exec("INSERT INTO `impgep_config`(`k`,`v`)VALUES('$k','$v')");
        }else{
            $DB->exec("UPDATE `impgep_config` SET `v` = '$v' WHERE `k` = '$k'");
        }
    }
    Tips::success('修改成功','/admin/index.php');
}

include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">发信邮箱地址</label>
                                            <div class="col-12">
                                                <input type="text" name="mailHost" placeholder="请输入发信邮箱地址" value="<?=$conf['mailHost']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">发信邮箱SLL端口</label>
                                            <div class="col-12">
                                                <input type="text" name="mailPort" placeholder="请输入发信邮箱SLL端口" value="<?=$conf['mailPort']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">发信邮箱编码</label>
                                            <div class="col-12">
                                                <input type="text" name="mailCharSet" placeholder="请输入发信邮箱编码" value="<?=$conf['mailCharSet']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">发信邮箱名称</label>
                                            <div class="col-12">
                                                <input type="text" name="mailFromName" placeholder="请输入发信邮箱名称" value="<?=$conf['mailFromName']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">发信邮箱账号</label>
                                            <div class="col-12">
                                                <input type="text" name="mailUserName" placeholder="请输入发信邮箱账号" value="<?=$conf['mailUserName']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">发信邮箱密码</label>
                                            <div class="col-12">
                                                <input type="text" name="mailPassWord" placeholder="请输入发信邮箱密码" value="<?=$conf['mailPassWord']?>" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    <?php include 'foot.php';?>