<?php
$mod = 'admin';
$title = '主机添加';
include '../includes/common.php';
include './admin.class.php';

if(!empty($_POST)){
    list($result,$msg) = adminClass::createHost($DB, $_POST);
    if(!$result)Tips::error($msg,'/admin/hostadd.php');
    Tips::success('开通成功','/admin/hostlist.php');
}

$apiData = adminClass::getApi($DB);

include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form method="POST">
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">选择接口</label>
                                            <div class="col-12">
                                                <select name="apiIp" class="form-control text-primary font-size-sm">
                                                    <?php foreach ($apiData as $v) { ?>
                                                    <option value="<?=$v['apiIp']?>">名称：<?=$v['apiName']?>；IP：<?=$v['apiIp']?>；状态：<?php if($v['apiState'] == 1){echo '正常';}else{echo '异常';} ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">虚拟主机用户名</label>
                                            <div class="col-12">
                                                <input type="text" name="name" placeholder="请输入虚拟主机用户名" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">虚拟主机密码</label>
                                            <div class="col-12">
                                                <input type="text" name="passwd" placeholder="请输入虚拟主机密码" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">虚拟主机类型</label>
                                            <div class="col-12">
                                                <select name="cdn" class="form-control text-primary font-size-sm" onchange="showepayurlinput(this.value)">
                                                    <option value="0">虚拟主机</option>
                                                    <option value="1">CDN 主机</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">虚拟主机语言</label>
                                            <div class="col-12">
                                                <select name="module" class="form-control text-primary font-size-sm">
                                                    <option value="php">PHP</option>
                                                    <option value="html">HTML</option>
                                                    <option value="iis">ASP(需服务器支持)</option>
                                                </select>
                                            </div>
                                        </div>
                                       <div  id="host">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">虚拟主机大小</label>
                                            <div class="col-12">
                                                <input type="text" name="web_quota" placeholder="请输入虚拟主机大小" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">数据库大小(M)</label>
                                            <div class="col-12">
                                                <input type="text" name="db_quota" placeholder="请输入数据库大小(填0不开通)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">数据库类型</label>
                                            <div class="col-12">
                                                <select name="db_type" class="form-control text-primary font-size-sm">
                                                    <option value="mysql">MYSQL</option>
                                                    <option value="sqlsrv">SQL SERVER</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">绑定额外子目录</label>
                                            <div class="col-12">
                                                <select name="subdir_flag" class="form-control text-primary font-size-sm">
                                                    <option value="1">允许</option>
                                                    <option value="">不允许</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">子目录数</label>
                                            <div class="col-12">
                                                <input type="text" name="max_subdir" placeholder="请输入绑定子目录数(0为不限)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                       </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">流量限制(G)</label>
                                            <div class="col-12">
                                                <input type="text" name="flow_limit" placeholder="请输入虚拟主机大小" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">域名数</label>
                                            <div class="col-12">
                                                <input type="text" name="domain" placeholder="请输入绑定域名数(-1为不限)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">端口</label>
                                            <div class="col-12">
                                                <input type="text" name="port" placeholder="多个端口由,分开,ssl端口请加s，如80,443s" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">添加</button>
                                             </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    <?php include 'foot.php';?>
<script>
	var items = $("select[default]");
	for (i = 0; i < items.length; i++) {
		$(items[i]).val($(items[i]).attr("default"));
	}
	function showepayurlinput(v){
	
		if(v == 1){

			$("#host").hide(500);
		}else{
			$("#host").show(500);
			
		}
	}
</script>