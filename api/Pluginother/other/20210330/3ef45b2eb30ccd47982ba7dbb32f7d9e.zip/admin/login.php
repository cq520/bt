<?php
$mod = 'admin';
$notLogin = true;
include '../includes/common.php';
include './admin.class.php';

if(isset($_GET['logout'])){
    unset($_SESSION['adminUser']);
    header('Location:/admin/login.php');
}

if($isLogin)header('Location:/admin');

$title = '后台登录';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
      <title><?=$conf['webName']?> - <?=$title?></title>
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>
<div class="app app-header-fixed ">
<div class="container w-xxl w-auto-xs" ng-controller="SigninFormController" ng-init="app.settings.container = false;">
  <a href class="navbar-brand block m-t">后台登录</a>
  <div class="m-b-lg">
    <div class="wrapper text-center">
      <strong>您将在这里登陆,请认真帐号信息！</strong>
    </div>
    <form action="login.php" method="post" class="form-horizontal" class="form-validation">
      <div class="text-danger wrapper text-center" ng-show="authError">
          
      </div>
      <div class="list-group list-group-sm">
        <div class="list-group-item">
          <input type="text" name="adminUser" placeholder="用户名" class="form-control no-border">
        </div>
        <div class="list-group-item">
           <input type="password" name="adminPwd" placeholder="密码" class="form-control no-border">
        </div>
        
        <?php if($conf['isImgCode']){ ?>
        <div class="list-group-item" style="display: flex;">
           <input type="text" name="imgCode" placeholder="请输入图片验证码"  class="form-control no-border" >
           <img src="../includes/imageCode.php" id="imageCode" title="看不清，点击换一张" align="absmiddle" />
        </div>
	  <?php } ?>
      </div>
      <button class="btn btn-lg btn-primary btn-block" type="submit">登录</button>
    </form>
  </div>
  <div class="text-center">
    <p>
  <small class="text-muted"><a href="//wpa.qq.com/msgrd?v=3&uin=2477581302&site=qq&menu=yes" target="_blank">GEP</a> &copy; <span data-toggle="year-copy">2020</span>
                    </small>
</p>
  </div>
</div>


</div>
    <script src="../assets/jquery/jquery/dist/jquery.js"></script>
    <script src="../assets/jquery/bootstrap/dist/js/bootstrap.js"></script>
    <script src="../assets/vendor/layer/layer.js"></script>
    <script src="../assets/js/ui-load.js"></script>
    <script src="../assets/js/ui-jp.config.js"></script>
    <script src="../assets/js/ui-jp.js"></script>
    <script src="../assets/js/ui-nav.js"></script>
    <script src="../assets/js/ui-toggle.js"></script>
    <script src="../assets/js/ui-client.js"></script>
<script>
   $("form").submit(function (){
		var login = $("button[type='submit']");
        var adminUser = $("input[name='adminUser']").val();
        var adminPwd = $("input[name='adminPwd']").val();
        
        var isImgCode = <?=$conf['isImgCode']?>;

        if(adminUser.length < 1 || adminPwd.length < 1){
            layer.msg('请确保必填项不为空');
            return false;
        }
        
        if(isImgCode){
		    var imgCode = $("input[name='imgCode']").val();
		    if(imgCode.length < 1){
				layer.msg('请输入图片验证码')
				return false;
			}
		}
		login.attr('disabled', 'true');
        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'login',
                adminUser:adminUser,
                adminPwd:adminPwd,
                imgCode:imgCode
            },
            dataType:'json',
            success:function (data){
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
					login.removeAttr('disabled');
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
        $("#imageCode").click(function(){
       
       $(this).attr("src", '../includes/imageCode.php?tmp=' + Math.random()); 
    });
</script>
</body>
</html>