<?php
$mod = 'admin';
$title = '用户添加';
include '../includes/common.php';
include './admin.class.php';
$levelData = adminClass::getLevel($DB);
include './header.php';
?>
        <div id="content" class="app-content" role="main">
        	<div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户名</label>
                                            <div class="col-12">
                                                <input type="text" name="userName" placeholder="请输入用户名" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户密码</label>
                                            <div class="col-12">
                                                <input type="text" name="userPwd" placeholder="请输入用户密码" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户邮箱</label>
                                            <div class="col-12">
                                                <input type="text" name="userMail" placeholder="请输入用户邮箱" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">用户等级</label>
                                            <div class="col-12">
                                                <select class="form-control" name="levelId">
                                                    <option value="-1">普通代理</option>
                                                  <?php foreach ($levelData as $value){ ?>
                                                    <option value="<?=$value['id']?>"><?=$value['levelName']?></option>
                                                  <?php } ?>
                                                </select>
                                            </div>
                                         </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">添加</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    $("form").submit(function (){
        var load = layer.msg('添加中，请稍后...',{icon:16,shade:0.8,time:false});

        var userName = $("input[name='userName']").val();
        var userPwd = $("input[name='userPwd']").val();
        var userMail = $("input[name='userMail']").val();
        var levelId = $("select[name='levelId']").val();

        if(userName.length < 1 || userPwd.length < 1){
            layer.alert('用户名和密码不可为空');
            return false;
        }
        
        if( !is_check_name(userName) ){
            layer.alert('用户名长度最少为3位字符且为英文');
            return false;
        }
        
        if(!is_check_mail(userMail) ){
            layer.alert('邮箱账号格式错误',{icon: 5,time: 2000, shade: [0.3, '#000']});
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'userAdd',
                userName:userName,
                userPwd:userPwd,
                userMail:userMail,
                levelId:levelId
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/userlist.php'
                    },1000);
                    layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                }else{
                    layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                }
            }
        });
        return false;
    });
    function is_check_name(str) {    
        return /^[\w]{3,16}$/.test(str) 
    }
    function is_check_mail(str) {
        return /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/.test(str)
    }
</script>