<?php
$mod = 'admin';
$title = '修改等级';
include '../includes/common.php';
include './admin.class.php';
if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("参数错误",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
$levelData = adminClass::getLevel($DB, $_GET['id']);
if(empty($levelData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("等级不存在",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
$upLevelData = adminClass::getLevel($DB);
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title><?=$conf['webName']?> - <?=$title?></title>
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>
        <div id="page-container" class="sidebar-dark enable-page-overlay side-scroll">
            <div id="main-container" class="content" role="main">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">等级名称</label>
                                            <div class="col-12">
                                                <input value="<?=$_GET['id']?>" type="hidden" name="id" class="form-control text-primary font-size-sm" autocomplete="off">
                                                <input value="<?=$levelData['levelName']?>" type="text" name="levelName" placeholder="请输入等级名称" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">优惠折数</label>
                                            <div class="col-12">
                                                <input value="<?=$levelData['levelFolds']?>" type="number" step="0.01" name="levelFolds" placeholder="请输入优惠折数(0.1代表1折)" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">购买金额</label>
                                            <div class="col-12">
                                                <input value="<?=$levelData['levelMoney']?>" type="number" step="0.01" name="levelMoney" placeholder="请输入等级购买金额" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">上级等级</label>
                                            <div class="col-12">
                                                <select class="form-control text-primary font-size-sm" name="upLevel" value="<?=$levelData['upLevel']?>">
                                                    <option value="-1">无上级</option>
                                                  <?php foreach ($upLevelData as $value){ ?>
                                                    <?php if($value['id'] != $levelData['id']){ ?>
                                                        <option value="<?=$value['id']?>" <?php if($value['id'] == $levelData['upLevel']) echo 'selected';?>><?=$value['levelName']?></option>
                                                  <?php }} ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <footer id="footer" class="footer bgw" role="footer">
            <div class="wrapper b-t bg-light">
              <span class="pull-right"><a href="https://jq.qq.com/?_wv=1027&k=ZvDTSB1h" >GEP</a><a href ui-scroll="app" class="m-l-sm text-muted"></a></span>
              &copy; 2020-2021 Copyright.<a href="http://bbs.98ka.ren" >GEP  <?=VERSION?> </a>
            </div>
        </footer>
        <script src="../assets/js/oneui.core.min.js"></script>
        <script src="../assets/js/oneui.app.min.js"></script>
        <script src="../assets/vendor/layer/layer.js"></script>
    </body>
</html>
<script>
    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});

        var id = $("input[name='id']").val();
        var levelName = $("input[name='levelName']").val();
        var levelFolds = $("input[name='levelFolds']").val();
        var levelMoney = $("input[name='levelMoney']").val();
        var upLevel = $("select[name='upLevel']").val();

        if(levelName.length < 1 || levelFolds.length < 1){
            layer.msg('所有项不可为空');
            return false;
        }

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'levelinfo',
                id:id,
                levelName:levelName,
                levelFolds:levelFolds,
                levelMoney:levelMoney,
                upLevel:upLevel
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
</script>