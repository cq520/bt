<?php
$mod = 'admin';
$title = '订单列表';
require_once '../includes/common.php';
require_once './admin.class.php';
$page = isset($_GET["page"])?$_GET["page"]:1;
$limit = isset($_GET["limit"])?$_GET["limit"]:15;
if(empty($_GET['keywords'])) $orderData = adminClass::getOrder($DB,false,null,$page,$limit);
else $orderData = adminClass::getOrder($DB,false,$_GET['keywords'],$page,$limit);
$counts = adminClass::getOrderCount($DB,false,$_GET['keywords'],$page,$limit);
require_once './header.php';
?>
        <div id="content" class="app-content" role="main">
            <div class="app-content-body ">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <form>
                            <div class="input-group">
                                <input class="form-control input-sm bg-light no-border rounded padder" type="text" id="base-material-text" name="keywords" placeholder="关键词搜索" value="<?php echo empty($_GET['keywords'])?'':$_GET['keywords'];?>">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-sm bg-light rounded"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-vcenter table-hover table-sm">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>订单号</th>
                                                <th>用户名</th>
                                                <th>金额</th>
                                                <th>状态</th>
                                                <th>时间</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($orderData as $value){ ?>
                                        <tr>
                                            <td><?=$value['id']?></td>
                                            <td><?=$value['out_trade_no']?></td>
                                            <td><?=$value['userName']?></td>
                                            <td><?=$value['money']?></td>
    
                                            <td>
                                                <?php
                                                    if($value['state']){
                                                        echo '已支付';
                                                    }else{
                                                        echo '未支付';
                                                    }
                                                ?>
                                            </td>
                                            <td><?=$value['date']?></td>
                                                                               <td>
                                            <a href="javascript:;" onclick="del('<?=$value['id']?>')" class="badge btn-danger">删除</a>
                                        </td>
                                        </tr>
     
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center m-t-lg m-b-lg">
                        <ul class="pagination pagination-md">
                            <li class="<?php if($page-1<=0)echo 'disabled';?>"><a <?php if($page-1>0){echo 'href="?page='.($page-1)."\"";}?>><i class="fa fa-chevron-left"></i></a></li>
                            <?php for($i=1;$i<=ceil($counts/$limit);$i++){?>
                                <li class="<?php if($page==$i)echo'active';?>"><a href="?page=<?=$i?>"><?=$i?></a></li>
                            <?php }?>
                            <li class="<?php if($page>=ceil($counts/$limit))echo 'disabled';?>"><a <?php if($page<ceil($counts/$limit)){echo 'href="?page='.($page+1)."\"";}?>><i class="fa fa-chevron-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php include 'foot.php';?>
<script>
    function userState(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'userState',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/userlist.php'
                    },1000);
                    layer.alert(data.msg,{icon:1,shade:0.8});
                }else{
                    layer.alert(data.msg,{icon:2,shade:0.8});
                }
            }
        });
    }
    function edit(id){
        layer.open({
            type: 2,
            title: '修改USER(ID:'+id+')',
            shadeClose: true,
            shade: 0.8,
            area: ['90%', '90%'],
            content: '/admin/userinfo.php?id='+id
        }); 
    }
    function del(id){
        layer.confirm('确定要删除吗？', function (){
            delOrder(id)
        });
    }
    function delOrder(id){
        var load = layer.load('1',{shade:0.8,time:false});

        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                act:'delOrder',
                id:id
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    setTimeout(function (){
                        location.href = '/admin/order.php'
                    },1000);
                    layer.alert(data.msg,{icon:1,shade:0.8});
                }else{
                    layer.alert(data.msg,{icon:2,shade:0.8});
                }
            }
        });
    }
</script>