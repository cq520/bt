<?php
$mod = 'admin';
$title = '修改本站公告';
include '../includes/common.php';
include './admin.class.php';

if(!$_GET['id'])exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("参数错误",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
$noticeData = adminClass::getNotice($DB, $_GET['id']);
if(empty($noticeData))exit('<script src="../asstes/vendor/layer/layer.js"></script><script>var index = parent.layer.getFrameIndex(window.name);parent.layer.msg("公告不存在",{icon: 5,time: 2000, shade: [0.3, "#000"]});parent.layer.close(index);</script>');
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title><?=$conf['webName']?> - <?=$title?></title>
  <link rel="stylesheet" href="../assets/css/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/font.css" type="text/css" />
  <link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
    </head>
    <body>
        <div id="page-container" class="sidebar-dark enable-page-overlay side-scroll">
            <div id="main-container" class="content" role="main">
                <div class="wrapper-md">
                    <div class="panel panel-info ng-scope">
                        <div class="panel-heading"><?=$title?></div>
                        <div class="block-content block-content-full">
                            <form>
                                <div class="panel-body">
                                    <div class="col-lg-12">
                                        <div class="form-group ng-scope">
                                            <label class="col-12">本站公告标题</label>
                                            <div class="col-12">
                                                <input value="<?=$noticeData['id']?>" type="hidden" name="id" class="form-control text-primary font-size-sm" autocomplete="off">
                                                <input value="<?=$noticeData['title']?>" type="text" name="title" class="form-control text-primary font-size-sm" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <label class="col-12">本站公告内容</label>
                                            <div class="col-12">
                                                 <textarea name="content" class="form-control text-primary font-size-sm" rows="5"><?=$noticeData['content']?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group ng-scope">
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-primary btn-block">修改</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <footer id="footer" class="footer bgw" role="footer">
            <div class="wrapper b-t bg-light">
              <span class="pull-right"><a href="https://jq.qq.com/?_wv=1027&k=ZvDTSB1h" >GEP</a><a href ui-scroll="app" class="m-l-sm text-muted"></a></span>
              &copy; 2020-2021 Copyright.<a href="http://bbs.98ka.ren" >GEP  <?=VERSION?> </a>
            </div>
        </footer>
        <script src="../assets/js/oneui.core.min.js"></script>
        <script src="../assets/js/oneui.app.min.js"></script>
        <script src="../assets/vendor/layer/layer.js"></script>
    </body>
</html>
<script>
    var index = parent.layer.getFrameIndex(window.name);

    $("form").submit(function (){
        var load = layer.msg('修改中，请稍后...',{icon:16,shade:0.8,time:false});
        
        var id = $("input[name = 'id']").val();
        var title = $("input[name = 'title']").val();
        var content = $("textarea[name = 'content']").val();
        
        $.ajax({
            type:'POST',
            url:'/admin/ajax.php',
            data:{
                'act':'noticeinfo',
                'id':id,
                'title':title,
                'content':content
            },
            dataType:'json',
            success:function (data){
                layer.close(load);
                if(data.code == 1){
                    parent.layer.msg(data.msg,{icon: 6,time: 2000, shade: [0.3, '#000']});
                    parent.location.reload();
                    parent.layer.close(index);
                }else{
                    parent.layer.msg(data.msg,{icon: 5,time: 2000, shade: [0.3, '#000']});
                    parent.layer.close(index);
                }
            }
        });
        return false;
    });
</script>