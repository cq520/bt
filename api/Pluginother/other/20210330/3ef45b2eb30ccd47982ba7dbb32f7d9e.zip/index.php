<?php
include './includes/common.php';
include 'template/'. $conf['mub'].'/user/index.html';
?>