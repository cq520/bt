--
-- 表的结构 `impgep_admin`
--

CREATE TABLE IF NOT EXISTS `impgep_admin` (
  `id` int(11) unsigned NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminPwd` char(32) NOT NULL,
  `adminQq` bigint(20) DEFAULT '2477581302',
  `adminLoginIp` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `impgep_admin`
--

INSERT INTO `impgep_admin` (`id`, `adminUser`, `adminPwd`, `adminQq`, `adminLoginIp`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 2477581302, '156.18.02.11');

-- --------------------------------------------------------

--
-- 表的结构 `impgep_api`
--

CREATE TABLE IF NOT EXISTS `impgep_api` (
  `id` int(11) unsigned NOT NULL,
  `apiIp` varchar(55) NOT NULL,
  `apiKey` varchar(255) NOT NULL,
  `apiMoney` decimal(10,2) DEFAULT '0.00',
  `apiName` varchar(255) DEFAULT '未命名',
  `apiMixWeb` int(11) unsigned DEFAULT '1000',
  `apiMixDb` int(11) unsigned DEFAULT '1000',
  `apiMixFlow` int(11) DEFAULT '20',
  `apiUse` int(11) unsigned DEFAULT '0',
  `apiUseMoney` decimal(10,2) DEFAULT '0.00',
  `apiState` char(1) DEFAULT '0',
  `userName` varchar(255) DEFAULT NULL,
  `isShow` char(1) DEFAULT '0',
  `dj` int(1) DEFAULT NULL,
  `djurl` varchar(255) DEFAULT NULL,
  `djuser` varchar(25) NOT NULL,
  `apiTxt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_apib`
--

CREATE TABLE IF NOT EXISTS `impgep_apib` (
  `id` int(11) unsigned NOT NULL,
  `userName` varchar(255) NOT NULL,
  `apiIp` varchar(15) NOT NULL,
  `apiName` varchar(255) NOT NULL,
  `apiMoney` decimal(10,2) NOT NULL,
  `apiUseMoney` decimal(10,2) NOT NULL,
  `useLength` int(10) unsigned NOT NULL,
  `useLengthCd` varchar(11) DEFAULT NULL,
  `useTime` date NOT NULL,
  `isShow` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_carmi`
--

CREATE TABLE IF NOT EXISTS `impgep_carmi` (
  `id` int(11) unsigned NOT NULL,
  `userId` int(11) NOT NULL DEFAULT '-1',
  `carmiNo` varchar(255) NOT NULL,
  `carType` int(11) NOT NULL,
  `carState` int(11) NOT NULL DEFAULT '1',
  `carName` varchar(255) NOT NULL,
  `levelId` int(11) DEFAULT '-1',
  `money` decimal(10,2) DEFAULT '0.00',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usetime` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_config`
--

CREATE TABLE IF NOT EXISTS `impgep_config` (
  `id` int(11) unsigned NOT NULL,
  `k` varchar(255) NOT NULL,
  `v` text
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `impgep_config`
--

INSERT INTO `impgep_config` (`id`, `k`, `v`) VALUES
(1, 'webName', 'GEP'),
(2, 'isMailReg', '0'),
(3, 'mailHost', 'smtp.qq.com'),
(4, 'mailPort', '465'),
(5, 'mailCharSet', 'UTF-8'),
(6, 'mailFromName', 'GEP'),
(7, 'mailUserName', '2477581302@qq.com'),
(8, 'mailPassWord', 'kadsqiqxijawbdcd'),
(9, 'epayLink', 'https://pay.laosan6.com/'),
(10, 'epayPid', '10002'),
(11, 'epayKey', 'GEPKEY'),
(12, 'upTicheng', '5'),
(13, 'regMoney', '1'),
(14, 'webDescription', 'GEP分销系统 优质EP分销系统，杜绝服务器安秘钥泄露，集成化管理，通过简单的配置后即可开始你的分销之旅！'),
(15, 'webKeyword', 'GEP,GEP分销,小鬼分销系统,小鬼EP分销,EP分销系统,easypanel分销系统,小鬼GEP分销系统,GEP官网,全新的EP分销系统'),
(16, 'userAddApi', '1'),
(17, 'userBuyApi', '1'),
(18, 'isUserReg', '0'),
(19, 'userPayMoney', '1'),
(20, 'payType', 'epay'),
(21, 'codePayId', '111879'),
(22, 'codePayKey', 'bNTE6iMy06IF695mo06DG230f9D0i8E'),
(23, 'footCode', ''),
(24, 'isApiSuper', '0'),
(25, 'indexText', ''),
(26, 'webQq', '2477581302'),
(27, 'mub', 'IMGEP'),
(29, 'cronKey', '123456'),
(30, 'isImgCode', '0'),
(31, 'id', ''),
(32, 'key', ''),
(33, 'userAddLower', '1'),
(34, 'userUpdLowerLevel', '1'),
(35, 'userUpLevel', '1'),
(36, 'userAddCarmi', '1'),
(37, 'userExchangeCarmi', '1'),
(38, 'userSignin', '1'),
(39, 'userSigninMin', '20'),
(40, 'userSigninMax', '100'),
(41, 'signinExchangeRatio', '1000'),
(42, 'signinExchangeMin', '500'),
(43, 'usermub', 'IMGEP'),
(44, 'qqpay', '0'),
(45, 'wxpay', '0'),
(46, 'alipay', '0'),
(47, 'qqpay1id', '111879'),
(48, 'qqpay1key', 'bNTE6iMy06IF695mo06DG230f9D0i8E'),
(49, 'qqpayurl', 'https://pay.laosan6.com/'),
(50, 'qqpay2id', '10003'),
(51, 'qqpay2key', 'msvxOEETToN5iNR0VXv7H09y9TO95HsM'),
(52, 'qqpay3id', '447023'),
(53, 'qqpay3key', 'Kiwkk9rMK8aa4IDCWWgvuAKyF3iEQGx8'),
(54, 'alipay1id', '88'),
(55, 'alipayuser', '888'),
(56, 'alipay1key', '888'),
(57, 'alipay2url', 'https://pay.aosan6.com/'),
(58, 'alipay2id', ''),
(59, 'alipay2key', 'msvxOEETToN5iNR0VXv7H09y9TO95HsM'),
(60, 'alipay3id', '447023'),
(61, 'alipay3key', ''),
(62, 'alipay4id', ''),
(63, 'alipay3keys', ''),
(64, 'wxpay1appid', '88'),
(65, 'wxpay1id', '8888'),
(66, 'wxpay1key', '888'),
(67, 'wxpay1cret', '888'),
(68, 'wxpayurl', 'https://py.laosan6.com/'),
(69, 'wxpay2id', '10003'),
(70, 'wxpay2key', 'msvxOEETToN5iNR0VXv7H09y9TO95HsM'),
(71, 'wxpay3id', '447023'),
(72, 'wxpay3key', 'Kiwkk9rMK8aa4IDCWWgvuAKyF3iEQGx8'),
(73, 'userAddWork', '1'),
(74, 'userhostadd', '1'),
(75, 'userDomain', '0');

-- --------------------------------------------------------

--
-- 表的结构 `impgep_gonggao`
--

CREATE TABLE IF NOT EXISTS `impgep_gonggao` (
  `id` int(11) unsigned NOT NULL,
  `title` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `time` date NOT NULL,
  `adminUser` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_host`
--

CREATE TABLE IF NOT EXISTS `impgep_host` (
  `id` int(11) unsigned NOT NULL,
  `hostIp` varchar(15) NOT NULL,
  `hostName` varchar(255) NOT NULL,
  `hostPwd` varchar(255) NOT NULL,
  `hostWebSize` int(11) unsigned NOT NULL,
  `hostDbSize` int(11) unsigned NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `hostState` varchar(255) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_level`
--

CREATE TABLE IF NOT EXISTS `impgep_level` (
  `id` int(11) unsigned NOT NULL,
  `levelName` varchar(255) NOT NULL,
  `levelFolds` decimal(10,2) NOT NULL DEFAULT '0.00',
  `levelMoney` decimal(10,2) NOT NULL DEFAULT '0.00',
  `upLevel` int(11) DEFAULT NULL,
  `upLevelName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `impgep_level`
--

INSERT INTO `impgep_level` (`id`, `levelName`, `levelFolds`, `levelMoney`, `upLevel`, `upLevelName`) VALUES
(1, '合作伙伴', '0.70', '50.00', -1, '无上级'),
(2, '高级代理', '0.80', '40.00', 1, '合作伙伴'),
(3, '中级代理', '0.85', '30.00', 2, '高级代理'),
(4, '初级代理', '0.90', '20.00', 3, '中级代理');

-- --------------------------------------------------------

--
-- 表的结构 `impgep_pay`
--

CREATE TABLE IF NOT EXISTS `impgep_pay` (
  `id` int(11) unsigned NOT NULL,
  `out_trade_no` char(17) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `state` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_token`
--

CREATE TABLE IF NOT EXISTS `impgep_token` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `token` varchar(200) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL COMMENT '签名时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_user`
--

CREATE TABLE IF NOT EXISTS `impgep_user` (
  `id` int(11) unsigned NOT NULL,
  `userName` varchar(255) NOT NULL,
  `userPwd` char(32) NOT NULL,
  `userMail` varchar(255) NOT NULL,
  `userMoney` decimal(10,2) DEFAULT NULL,
  `userKey` char(32) DEFAULT NULL,
  `userQq` char(32) DEFAULT NULL,
  `userIp` varchar(15) DEFAULT NULL,
  `upUserName` varchar(255) DEFAULT NULL,
  `userState` char(1) DEFAULT '1',
  `domain` varchar(55) DEFAULT NULL,
  `levelId` int(11) DEFAULT '-1',
  `signin` int(11) DEFAULT '0',
  `signinDate` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `impgep_user`
--

INSERT INTO `impgep_user` (`id`, `userName`, `userPwd`, `userMail`, `userMoney`, `userKey`, `userQq`, `userIp`, `upUserName`, `userState`, `domain`, `levelId`, `signin`, `signinDate`) VALUES
(1, 'GEP', '88552db1fe5f3108760392e177f8a64b', '请勿删除', '999.00', NULL, NULL, NULL, NULL, '1', '', 1, 0, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `impgep_userb`
--

CREATE TABLE IF NOT EXISTS `impgep_userb` (
  `id` int(11) unsigned NOT NULL,
  `upUserId` int(11) unsigned NOT NULL,
  `downUserId` int(11) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- 表的结构 `impgep_work`
--

CREATE TABLE IF NOT EXISTS `impgep_work` (
  `id` int(11) unsigned NOT NULL,
  `userName` varchar(255) NOT NULL,
  `type` int(1) NOT NULL,
  `title` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `time` date NOT NULL,
  `state` int(1) DEFAULT '0',
  `reply` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `impgep_admin`
--
ALTER TABLE `impgep_admin`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_api`
--
ALTER TABLE `impgep_api`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `apiIp` (`apiIp`,`apiName`) USING BTREE,
  ADD KEY `isShow` (`isShow`) USING BTREE,
  ADD KEY `apiIp_2` (`apiIp`,`apiName`,`isShow`) USING BTREE,
  ADD KEY `apiIp_3` (`apiIp`,`apiName`,`isShow`,`apiMoney`,`apiUseMoney`) USING BTREE;

--
-- Indexes for table `impgep_apib`
--
ALTER TABLE `impgep_apib`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `apiIp` (`apiIp`,`apiName`,`isShow`) USING BTREE,
  ADD KEY `impgep_apib_ibfk_1` (`apiIp`,`apiName`,`isShow`,`apiMoney`,`apiUseMoney`) USING BTREE;

--
-- Indexes for table `impgep_carmi`
--
ALTER TABLE `impgep_carmi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `impgep_config`
--
ALTER TABLE `impgep_config`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_gonggao`
--
ALTER TABLE `impgep_gonggao`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_host`
--
ALTER TABLE `impgep_host`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_level`
--
ALTER TABLE `impgep_level`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_pay`
--
ALTER TABLE `impgep_pay`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_token`
--
ALTER TABLE `impgep_token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `impgep_user`
--
ALTER TABLE `impgep_user`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_userb`
--
ALTER TABLE `impgep_userb`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `impgep_work`
--
ALTER TABLE `impgep_work`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `impgep_admin`
--
ALTER TABLE `impgep_admin`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `impgep_api`
--
ALTER TABLE `impgep_api`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_apib`
--
ALTER TABLE `impgep_apib`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_carmi`
--
ALTER TABLE `impgep_carmi`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_config`
--
ALTER TABLE `impgep_config`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `impgep_gonggao`
--
ALTER TABLE `impgep_gonggao`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_host`
--
ALTER TABLE `impgep_host`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_level`
--
ALTER TABLE `impgep_level`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `impgep_pay`
--
ALTER TABLE `impgep_pay`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_token`
--
ALTER TABLE `impgep_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_user`
--
ALTER TABLE `impgep_user`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `impgep_userb`
--
ALTER TABLE `impgep_userb`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `impgep_work`
--
ALTER TABLE `impgep_work`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;