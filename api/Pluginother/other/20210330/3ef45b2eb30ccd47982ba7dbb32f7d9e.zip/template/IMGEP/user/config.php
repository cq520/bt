<?php
$mb = array(
    'Name' => 'GEP',//作者名
    'img1' => 'http://www.98ka.ren/static/image/bg-3.jpg',//首页模板成品图
    'userimg' => 'http://auth.6web.cn/static/image/bg-2.jpg',//用户模板成品图
    'Read' =>'GEP官方模板',//模板介绍
    'QQ' =>'2477581302',//作者QQ
);