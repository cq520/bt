<?php
$db = array(
    'dbHost' => 'localhost',
    'dbPort' => '3306',
    'dbName' => 'BT_DB_NAME',
    'dbUser' => 'BT_DB_USERNAME',
    'dbPwd' => 'BT_DB_PASSWORD'
);