    //定义窗口尺寸
    $('.layui-layer-page').css({ 'width': '1080px'});

    //左测菜单切换效果
    $(".bt-w-menu p").click(function () {
        $(this).addClass('bgw').siblings().removeClass('bgw')
    });

    var layer_wait = 0;
    var layer_iframe = null;
    var request_timeout=3600;

    var Lpage,Ldata;
    var pnum = 10;

    Lpage = 1;

