
    /**
     * 发送请求到插件
     * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
     * @param function_name  要访问的方法名，如：get_logs
     * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"demo.get_logs"}
     * @param callback       请传入处理函数，响应内容将传入到第一个参数中(false 时通过layer.msg 回显消息)
     * @param timeout        插件的超时处理时间 默认 3600s
     * @param plugin_name    插件的名称 默认为 bt_cls
     */
    function request_plugin(function_name, args, callback, timeout,plugin_name,layerclose=true) {
        if(!plugin_name) plugin_name = "swn";
        if(!timeout) timeout =request_timeout;
        $.ajax({
            type:'POST',
            url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
            data: args,
            timeout:timeout,
            success: function(rdata) {
                if(layer_wait!=0 && layerclose) { parent.layer.close(layer_wait);layer_wait=0;}
                if (!callback) {
                    layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                    return;
                }
                else if(callback=="rdata") return rdata;
                else return callback(rdata);
            },
            error: function(ex) {
                if (!callback) {
                    layer.msg('请求过程发现错误!', { icon: 2 });
                    return;
                }
                return callback(ex);
            }
        });
    }


    function in_list(list,value)
    {
        var len = list.length;
        for(var p=0;p<len;p++) if(value == list[p]) return true;
        return false
    }



    function input_switch(domid,callback=false)
    {
        var domhtml = "";var domlabel="";
        if (callback) domlabel = '<label class="btswitch-btn" for="input_'+domid+'" onclick="input_switch(\''+domid+'\','+domid+'_callback)"></label>';
        else domlabel =  '<label class="btswitch-btn" for="input_'+domid+'" onclick="input_switch(\''+domid+'\')"></label>';
        if($("#input_"+domid).val()=="off")
           domhtml = ' <input class="btswitch btswitch-ios" id="input_'+domid+'" value="on" type="checkbox" checked="checked">' + domlabel;
        else domhtml = ' <input class="btswitch btswitch-ios" id="input_'+domid+'" value="off" type="checkbox" >' +domlabel;
        $("#"+domid).html(domhtml);
        if(callback)callback($("#input_"+domid).val());
    }



    function randomString(len) {
　　      len = len || 32;
　　      /*var chars = 'ABCDEFGHIJKMLNOPQRSTUVWXYZabcdefghijkmlnopqrstuvwxyz0123456789~!@#$%^&*()_+/-|\\}]{[;:"\',<>.?/';*/
          var chars = 'ABCDEFGHIJKMLNOPQRSTUVWXYZabcdefghijkmlnopqrstuvwxyz0123456789'
　　      var maxPos = chars.length;
　　      var pwd = '';for (i = 0; i < len; i++) pwd +=chars.charAt(Math.floor(Math.random() * maxPos));
　　      return pwd;
   }

    function global_vpnproxy_callback(){
        var vpnproxy = $("#input_global_vpnproxy").val();
        request_plugin("SetGlobalConfProxy","vpnproxy="+$("#input_global_vpnproxy").val(),function(rdata){
            if(rdata["serverres"]=="error"){
               if(vpnproxy=="on"){
                   cls.PageLoad("global");
                   layer.msg("开启全局路由功能失败...服务器所在地区["+rdata["IpInfo"]["local"]+"]不支持开启全局路由转发功能",{time:3600});
               }
            }
            else{
                if(vpnproxy=="on"){ cls.PageLoad("global");layer.msg("开启全局路由功能成功",{time:3600});}
                else { cls.PageLoad("global");layer.msg("关闭全局路由功能成功",{time:3600});}
            }
        })

    }
