#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem mail@szhcloud.cn
# |
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
#  ██╗██╗    ██╗██████╗  ██████╗
#  ██║██║    ██║╚════██╗██╔════╝
#  ██║██║ █╗ ██║ █████╔╝██║
#  ██║██║███╗██║ ╚═══██╗██║
#  ██║╚███╔███╔╝██████╔╝╚██████╗
#  ╚═╝ ╚══╝╚══╝ ╚═════╝  ╚═════╝
#
# Version: 1.0
# +--------------------------------------------------------------------

import sys,os,json,requests

# 设置运行目录
os.chdir("/www/server/panel")
import public

# 添加包引用位置并引用公共包
sys.path.append("class/")

class swn_auth:

    _plugin_publickey = "n5cGxJxg6UvAmKwhzdDt72BSvBYljcnn"
    _plugin_privatekey = "i57enGI4QReMT7TfrA4S2tZHIBzAnA4ZPSNcXleQLF5yJjVTEzuPmuQfzcG9yPmB"
    IW3C_Auth  = {"Plugin":{},"Device":{},"Data":""}

    __mail_config = '/www/server/panel/data/stmp_mail.json'

    # 查询插件的拓展信息 /
    def GetExtandInfo_IW3C(self):
        data ={"extand":"swn"}
        url = "https://api.iw3c.com.cn/auth/Pluginextand"
        self.IW3C_Auth_Public()
        self.IW3C_Auth_SetData(data)
        Res = self.IW3C_Auth_Request(url)
        if Res["status"] == "black":
            public.WriteFile(self._plugin_path + "BlackDeny.json", json.dumps(Res["Black"]))
            return Res
        elif Res["status"] != "success":
            return Res
        else:
            return Res["Data"]["extand"]

    # 通过 IW3C 邮件接口发送邮件
    def SendMail_IW3C(self, receive, title, content):
        data = {"receive":receive,"title":title,"content":content}
        url = "https://api.iw3c.com.cn/auth/Pluginmail"
        self.IW3C_Auth_Public()
        self.IW3C_Auth_SetData(data)
        Res = self.IW3C_Auth_Request(url)
        if Res["status"] == "black":
            public.WriteFile(self._plugin_path + "BlackDeny.json", json.dumps(Res["Black"]))
            return Res
        elif Res["status"] != "success":
            return Res
        else:
            return  {"status": "success", "msg": "发送邮件成功，您的邮件已经被正常投递"}

    # 通过宝塔的邮件消息队列来发送信息
    def SendMail_Panel(self, res, title, content):
        Mconf = self.MailPanelGetSmtpConf()
        if not Mconf:
            return {"status": "Error", "msg": "请先在面板设置->消息通道设置中设置您发送邮件的配置信息"}
        else:
            try:
                msg = MIMEText(content, 'html', 'utf-8')
                msg['From'] = formataddr([Mconf['User'], Mconf['User']])
                msg['To'] = ",".join(res)
                msg['Subject'] = title
                if int(Mconf['Port']) == 465:
                    server = smtplib.SMTP_SSL(Mconf['Host'], Mconf['Port'])
                else:
                    server = smtplib.SMTP(Mconf['Host'], Mconf['Port'])
                server.login(Mconf['User'], Mconf['Pwd'])
                server.sendmail(Mconf['User'], res, msg.as_string())
                server.quit()
            except Exception:
                return {"status": "Error", "msg": "发送邮件失败，使用SMTP 协议发送邮件时发生未知错误"}
            return {"status": "success", "msg": "发送邮件成功，您的邮件已经被正常投递"}







    #================================================================================================================
    #                               以 下 为 内 部 调 用 方 法 ，如 非 必 要 请 勿 更 改
    #================================================================================================================

    def IW3C_Auth_Public(self):
        self.IW3C_Auth["Device"]["UUID"] = public.get_uuid()
        self.IW3C_Auth["Device"]["ClientIP"] = self.GetClientIP()
        self.IW3C_Auth["Device"]["BTUID"] = self.GetBTUID()
        self.IW3C_Auth["Device"]["OSVer"] = self.GetSystemVersion()
        self.IW3C_Auth["Device"]["BTVer"] = public.version()
        self.IW3C_Auth["Plugin"]["PublicKey"] = self._plugin_publickey
        self.IW3C_Auth["Plugin"]["PluginVer"] = self.GetPluginVer()

    def IW3C_Auth_SetData(self,data):
        self.IW3C_Auth["Data"] = self.PublicDataEncode(data,False)
        self.IW3C_Auth["Plugin"]["Token"] = self.GetIW3CToken()



    def IW3C_Auth_Request(self,url):
        post = json.dumps(self.IW3C_Auth)
        header = {'Content-Type': 'application/json'}
        log = requests.post(url, data=post, headers=header).text
        public.WriteFile("/www/server/panel/plugin/swn/static/log.html",log)
        Auth_Res = json.loads(log)["Data"]
        if Auth_Res["status"] == "BlackAuth":
            return {"status": "black","msg": "请求Auth接口失败!安全系统检测到您的设备存在威胁行为,您已被纳入黑名单[EventID:" + Auth_Res["BlackEvent"]["BlackEventId"] + "]","Black":Auth_Res["BlackEvent"]}
        else:
            if Auth_Res["status"] != "success":
                return {"status": "error", "msg": "请求Auth接口失败!,未知错误...请加产品开发群 427901182 处理"}
            else:
                return {"status":"success","Data":Auth_Res}



    def base64_encode(self, data):
        import base64
        try:
            rdata = base64.b64encode(data)
        except:
            rdata = base64.b64encode(data.encode()).decode()
        return rdata

    def hash_sha256(self, str):
        import hashlib
        rdata = hashlib.sha256(str.encode()).hexdigest()
        return rdata

    def GetClientIP(self):
        ClientIP = json.loads(requests.get("https://api.iw3c.com.cn/api/Ip/GetClientIp", verify=False).text)
        return ClientIP["Data"]["clientip"]

    def PublicDataEncode(self, data, re=True):
        _data = json.dumps(self.DiskSort(data), sort_keys=True)
        if re:
            try:
                import urllib.parse
                _str = urllib.parse.unquote("%20")
            except:
                import urllib
                _str = urllib.unquote("%20")
            _data = _data.replace(_str, "")
        return self.base64_encode(_data)

    def DiskSort(self, data):
        _data = data
        _keylist = sorted(data)
        ndata = {}
        for key in _keylist:
            ndata[key] = data[key]
        data = _data
        return ndata

    def GetSystemVersion(self):
        # 取操作系统版本
        import public
        version = public.readFile('/etc/redhat-release')
        if not version:
            version = public.readFile('/etc/issue').strip().split("\n")[0].replace('\\n', '').replace('\l', '').strip()
        else:
            version = version.replace('release ', '').replace('Linux', '').replace('(Core)', '').strip()
        v_info = sys.version_info
        v_info = version + '(Py' + str(v_info.major) + '.' + str(v_info.minor) + '.' + str(v_info.micro) + ')'
        try:
            import urllib.parse
            _str = urllib.parse.unquote("%20")
        except:
            import urllib
            _str = urllib.unquote("%20")
        v_info = v_info.replace(_str, "")
        return v_info

    def GetBTUID(self):
        if os.path.exists("/www/server/panel/data/userInfo.json"):
            user = json.loads(public.ReadFile("/www/server/panel/data/userInfo.json"))
            BTUID = public.md5(user["username"])[9:24].upper()
        else:
            USTR = public.get_uuid() + self.GetSystemVersion()
            BTUID = "BT" + public.md5(USTR)[11:21].upper() + "BT"
        return BTUID

    def GetIW3CToken(self):
        device = self.PublicDataEncode(self.IW3C_Auth["Device"])
        _token = self.IW3C_Auth["Plugin"]["PublicKey"] + self.IW3C_Auth["Plugin"]["PluginVer"] + device + \
                 self.IW3C_Auth["Data"] + self._plugin_privatekey
        return self.hash_sha256(_token)

    def GetPluginVer(self):
        info = json.loads(public.ReadFile("/www/server/panel/plugin/swn/info.json"))
        return info["versions"]
    #=======================================================================================================