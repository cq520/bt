#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem mail@szhcloud.cn
# |         six   1535832938@qq.com
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
#  ██╗██╗    ██╗██████╗  ██████╗
#  ██║██║    ██║╚════██╗██╔════╝
#  ██║██║ █╗ ██║ █████╔╝██║
#  ██║██║███╗██║ ╚═══██╗██║
#  ██║╚███╔███╔╝██████╔╝╚██████╗
#  ╚═╝ ╚══╝╚══╝ ╚═════╝  ╚═════╝
#
# Version: 2.0
# Date: 2020-03-30
# Des: 1.全面更新升级, 适配 宝塔 7.1 全新架构
#      2.前端界面升级，适配IW3C 第三代 插件前端标准
#      3.邮件推送系统升级, 提供多种邮件推送方法
#      4.数据结构升级, 独立数据文件
# +--------------------------------------------------------------------
import sys, os, json, base64, re, time,math,requests,smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
from bs4 import BeautifulSoup
import sqlite3

requests.packages.urllib3.disable_warnings()

# 设置运行目录
os.chdir("/www/server/panel/")

# 添加包引用位置并引用公共包
sys.path.append("class/")
import public
from swn_auth import swn_auth

py_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36' }


# 取通用对象
class dict_obj:
    def __contains__(self, key):
        return getattr(self, key, None)
    def __setitem__(self, key, value): setattr(self, key, value)
    def __getitem__(self, key): return getattr(self, key, None)
    def __delitem__(self, key): delattr(self, key)
    def __delattr__(self, key): delattr(self, key)
    def get_items(self): return self

class swn_main:
    __plugin_path = "/www/server/panel/plugin/swn/"
    __config = None
    _python = "python"

    # 构造方法
    def __init__(self):
        # 检查插件目录下不存在配置目录
        if not os.path.exists(self.__plugin_path + "conf/"):
            os.mkdir(self.__plugin_path + "conf")
        if not os.path.exists(self.__plugin_path + "conf/mailconfig.json"):
            MailConfig = {"MailReceive": [],"MailSendType":"iw3c","MailTime_Hour":"9","MailTime_Minute":"0","MailService":"Stop"}
            public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
        if os.path.exists("/www/server/panel/pyenv/bin/python"):
            self._python = "/www/server/panel/pyenv/bin/python"

    # 加载静态页面
    def PageLoad(self, args):
        page = args.page
        if os.path.exists(self.__plugin_path + "templates/" + page + ".html"):
            html = public.ReadFile(self.__plugin_path + "templates/" + page + ".html")
            if page == "about":
                PluginVersion = self.GetPluginVersion()
                html = html.replace("BTPLUGINVERSION", PluginVersion)
            return {"status": "Success", "msg": "Load Static Page Success", "html": html}
        else:
            return {"status": "Error", "msg": "Request Page [" + page + "] Not Exist!"}

    # 添加收件人信息
    def AddMailReceive(self,args):
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        if len(MailConfig["MailReceive"]) >5:
            return {"status":"Error","msg":"试图添加的收件人信息超过上限!"}
        else:
            for mail in MailConfig["MailReceive"]:
                if mail["MailAddress"] == args.MailAddress:
                    return {"status": "Error", "msg": "试图添加的收件人 [" + mail["MailAddress"] + "] 已经存在！"}
            mail = {}
            mail["MailAddress"] = args.MailAddress
            mail["MailPs"] = args.MailPs
            MailConfig["MailReceive"].append(mail)
            public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
            return {"status": "Success", "msg": "添加收件人 [" + mail["MailAddress"] + "] 成功！"}

    # 删除收件人信息
    def DelMailReceive(self,args):
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        if len(MailConfig["MailReceive"]) != 0:
            i = 0
            for mail in MailConfig["MailReceive"]:
                if mail["MailAddress"] == args.MailAddress:
                    del MailConfig["MailReceive"][i]
                    public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
                    return {"status": "Success", "msg": "删除收件人 [" + mail["MailAddress"] + "] 成功！"}
                i = i + 1
            else:
                return {"status": "Error", "msg": "删除收件人 [" + mail["MailAddress"] + "] 失败！指定的收件人不存在！"}

    # 获取收件人和 收件类型 ，服务状态 ， 监控时间信息
    def GetMailConfig(self,args):
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        return {"status":"Success","Config":MailConfig}

    # 保存监控时间，通知通道信息
    def SetMailConfig(self,args):
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        MailConfig["MailTime_Hour"] = args.MailTime_Hour
        MailConfig["MailTime_Minute"] = args.MailTime_Minute
        MailConfig["MailSendType"] = args.MailSendType
        public.WriteFile(self.__plugin_path + "conf/mailconfig.json",json.dumps(MailConfig))
        return {"status": "Success", "Config": MailConfig}

    # 启动 监控服务
    def Service_StartCrontab(self,args):
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        # 检查计划任务是否已经存在
        if not self.FindCrontabExist():
            self.AddCrontab(MailConfig["MailTime_Hour"],MailConfig["MailTime_Minute"])
            MailConfig["MailService"] = "Run"
            public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
        else:
            if MailConfig["MailService"]!="Stop":
                return {"status": "Success", "Config": MailConfig}
            else:
                import crontab
                cron = crontab.crontab()
                list = cron.GetCrontab("")
                for tab in list:
                    if tab["name"] == "SWN 社区安全预警":
                        ntab = {}
                        ntab["minute"] = MailConfig["MailTime_Minute"]
                        ntab["hour"] = MailConfig["MailTime_Hour"]
                        ntab["urladdress"] = ""
                        ntab["id"] = tab["id"]
                        ntab["name"] = tab["name"]
                        ntab["type"] = "day"
                        ntab["where1"] = ""
                        ntab["week"] = ""
                        ntab["sType"] = "toSheel"
                        ntab["sBody"] = "cd /www/server/panel/plugin/swn/ && "+self._python+" swn_main.py"
                        ntab["sName"] = ""
                        ntab["backupTo"] = "localhost"
                        ntab["save"] = ""
                        cron.modify_crond(ntab)
                        cron.set_cron_status(tab)
                        MailConfig["MailService"] = "Run"
                        public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
        return {"status": "Success", "Config": MailConfig}

    # 停止 监控服务
    def Service_StopCrontab(self,args):
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        # 检查计划任务是否已经存在
        if not self.FindCrontabExist():
            self.AddCrontab(MailConfig["MailTime_Hour"], MailConfig["MailTime_Minute"])
            MailConfig["MailService"] = "Stop"
            public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
            import crontab
            cron = crontab.crontab()
            list = cron.GetCrontab("")
            for tab in list:
                if tab["name"] == "SWN 社区安全预警":
                    cron.set_cron_status(tab)
        else:
            if MailConfig["MailService"] != "Run":
                return {"status": "Success", "Config": MailConfig}
            else:
                import crontab
                cron = crontab.crontab()
                list = cron.GetCrontab("")
                for tab in list:
                    if tab["name"] == "SWN 社区安全预警":
                        cron.set_cron_status(tab)
                        MailConfig["MailService"] = "Stop"
                        public.WriteFile(self.__plugin_path + "conf/mailconfig.json", json.dumps(MailConfig))
        return {"status": "Success", "Config": MailConfig}


    # 获取推荐的安全社区信息 、
    def GetSafeClubRe(self,args):
        sauth = swn_auth()
        ClubRe= sauth.GetExtandInfo_IW3C()
        return {"status":"success","SafeClub":ClubRe}

    # 获取安全事件详情
    def GetSafeEvent(self,args):
        SafeEvent = []
        conn = sqlite3.connect('data/swn.db')
        c = conn.cursor()
        c.execute("SELECT * from swn order by id desc")
        list_data = c.fetchall()
        for i in list_data:
            _SafeEvent = {}
            _SafeEvent["EventTitle"] = i[1]
            _SafeEvent["EventURL"] = i[2]
            _SafeEvent["EventTime"] = i[-2]
            _SafeEvent["EventStatus"] = i[-1]
            SafeEvent.append(_SafeEvent)
        conn.close()
        return {"status": "success", "SafeEvent": SafeEvent}


    # 发送测试邮件
    def SendTestMail(self, args):
        # 读取收件人配置文件
        MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
        if len(MailConfig["MailReceive"]) == 0:
            return {"status": "Failed", "msg": "笨蛋，你还没有告诉人家要给谁发邮件呢..."}
        else:
            MAIL_title = "欢迎加入宝塔面板 swn家族(插件)"
            MAIL_body = '''
    		<img src="https://api.iw3c.com.cn/api/Wallpaper" width="50%">
            <p>
                亲,您好!欢迎您加入(使用)宝塔面板 swn家族(安全社区预警工具插件)，在接下来的日子里，我将时刻伴随您左右，告知您云社区中最新的风险信息<br/>
                您可以 E-mail:mail@szhcloud.cn 或者 加入QQ群：427901182 和我们共同建设美好家园(宝塔)<br/>
                IW3C 项目产品发布页 地址 <a href="https://www.iw3c.top/index/">https://www.iw3c.top/index/</a><br/>
                <span style="color:red">温馨提示：请将我加入邮箱白名单，以免被当作广告邮件</span>
            </p>            
            '''
            sauth =  swn_auth()
            if MailConfig["MailSendType"]=="iw3c":
                return sauth.SendMail_IW3C(self.GetMailConfAdd(MailConfig["MailReceive"]),MAIL_title,MAIL_body)
            elif MailConfig["MailSendType"]=="panel":
                return sauth.SendMail_Panel(self.GetMailConfAdd(MailConfig["MailReceive"]),MAIL_title,MAIL_body)



    # ============================================================================================================
    # 检查计划任务是否已经存在
    def FindCrontabExist(self):
        import crontab
        cron = crontab.crontab()
        list = cron.GetCrontab("")
        for tab in list:
            if tab["name"] == "SWN 社区安全预警":
                return True
        return False

    # 添加计划任务
    def AddCrontab(self,hour,minute):
        import crontab
        cron = crontab.crontab()
        task = dict_obj()
        task.name = "SWN 社区安全预警"
        task.type = "day"
        task.where1 = ""
        task.hour = "10"
        if int(minute) < 10:
            minute = "0"+str(minute)
        task.minute = minute
        task.week = ""
        task.sType = "toShell"
        task.sName = ""
        task.sBody = "cd /www/server/panel/plugin/swn/ && "+self._python+" swn_main.py"
        task.backupTo = "localhost"
        task.save = ""
        task.urladdress = ""
        cron.AddCrontab(task)

    def GetPluginVersion(self):
        info = json.loads(public.ReadFile(self.__plugin_path+"info.json"))
        return info["versions"]

    # ============================================================================================================
    # 爬虫逻辑控制
    def StartCrontab(self):
        # 检查是否存在爬虫数据库
        print("IW3C SWN安全报警工具 Version:1.0")
        self.InitCrontabData()
        self.SaveAliRecord(self.SearchAliRecord())
        self.SendAliWarning()

    def FindPageNum(self):
        url = "https://help.aliyun.com/noticelist/9213612.html"
        py_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
        jdata = json.loads(requests.get(url=url, headers=py_headers, verify=False).text.split("window.pagination=")[1].split("}")[0] + "}")
        pnum = math.ceil(float(jdata["totalCount"]) / float(jdata["pageSize"]))
        return pnum

    def SearchAliRecord(self):
        AliRecord = []
        pnum = self.FindPageNum()
        p = 1
        while p <= pnum:
            url = "https://help.aliyun.com/notice_list_page/9213612/"+str(p)+".html"
            data = requests.get(url=url, headers=py_headers, verify=False)
            public.WriteFile(self.__plugin_path + "/Temp.html", data.text)
            soup = BeautifulSoup(open(self.__plugin_path + "/Temp.html"), features="html.parser")
            list = soup.find_all('li')
            for notice in list:
                link = notice.a
                uptime = notice.find_all('span')
                notice_data = {}
                notice_data["title"] = link.contents[0]
                notice_data["url"] = "https://help.aliyun.com" + link["href"]
                notice_data["uptime"] = uptime[0].contents[0] + " " + uptime[1].contents[0]
                notice_data["cattime"] = public.format_date()
                AliRecord.append(notice_data)
            print('安全事件页面 [9213612-%s] 爬取成功' % str(p))
            p = p + 1
        os.remove(self.__plugin_path + "/Temp.html")
        return AliRecord

    def SendAliWarning(self):
        conn = sqlite3.connect('data/swn.db')
        c = conn.cursor()
        c.execute("SELECT * from swn")
        list_data = c.fetchall()
        for i in list_data:
            if not 'help.aliyun.com' in i[2]: continue
            if i[5] == 'wait':
                send_html = '<div id="About_logo" align="center"><img src="https://www.iw3c.top/logo/iw3c/iw3c.png" width="300px"></div><div>据阿里云漏洞预警平台 %s 消息：</br>请注意防范 <a href=%s>%s</a></div><div align="right">安全社区报警工具<br>Version:1.0<br/></div>' % (
                    i[-3], i[2], i[1])

                MAIL_title = 'SWN 安全社区预警插件:'
                MAIL_body = send_html
                MailConfig = json.loads(public.ReadFile(self.__plugin_path + "conf/mailconfig.json"))
                sauth = swn_auth()
                if MailConfig["MailSendType"] == "iw3c":
                    if sauth.SendMail_IW3C(self.GetMailConfAdd(MailConfig["MailReceive"]), MAIL_title, MAIL_body)['status'] == 'success':
                        c.execute("UPDATE swn set sendstatus = 'success' where ID=%d" % i[0])
                    else:
                        c.execute("UPDATE swn set sendstatus = 'error' where ID=%d" % i[0])
                    conn.commit()
                elif MailConfig["MailSendType"] == "panel":
                    if sauth.SendMail_Panel(self.GetMailConfAdd(MailConfig["MailReceive"]), MAIL_title, MAIL_body)['status'] == 'success':
                        c.execute("UPDATE swn set sendstatus = 'success' where ID=%d" % i[0])
                    else:
                        c.execute("UPDATE swn set sendstatus = 'error' where ID=%d" % i[0])
                    conn.commit()
                print ("[%s]: %s 邮件发送成功" %  (public.format_date(),i[1]))
                time.sleep(10)

    def InitCrontabData(self):
        # 用这个来创建本地数据库
        conn = sqlite3.connect('data/swn.db')
        c = conn.cursor()
        try:
            c.execute(
                "CREATE TABLE swn(id integer PRIMARY KEY ,title TEXT NOT NULL,url EXT  NOT NULL,uptime TEXT,recordtime TEXT , sendstatus  TEXT);")
            conn.commit()
        except:
            pass
        conn.close()
    def SaveAliRecord(self, data):
        conn = sqlite3.connect('data/swn.db')
        c = conn.cursor()
        print('向本地数据库中存入爬取到安全事件')
        if len(data) == 0: return False
        for i in data:
            c.execute("SELECT count(*) from swn where url= '%s'" % i['url'])
            number = c.fetchall()
            if number[0][0] == 0:
                c.execute( "INSERT INTO swn (url,title,uptime,recordtime,sendstatus) VALUES ('%s','%s','%s','%s','wait')" % (i['url'], i['title'], i['uptime'],i["cattime"] ))
                conn.commit()
        print('本地数据库安全事件存储成功')
        conn.close()
        return True

    def GetMailConfAdd(self, Mailconf):
        Mail = []
        for m in Mailconf:
            Mail.append(m["MailAddress"])
        return Mail

    # 在非命令行模式下引用面板缓存和session对象


if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 爬虫模式启动
else:
    swn = swn_main()
    swn.StartCrontab()

