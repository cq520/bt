#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Author: liaoqiang <1204887277@qq.com>
# +-------------------------------------------------------------------
import sys, os, json, json, public

# 设置运行目录
os.chdir("/www/server/panel")

sys.path.append("plugin/redisutil/")
import redis

# 添加包引用位置并引用公共包
sys.path.append("class/")

# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 设置缓存(超时10秒) cache.set('key',value,10)
    # 获取缓存 cache.get('key')
    # 删除缓存 cache.delete('key')

    # 设置session:  session['key'] = value
    # 获取session:  value = session['key']
    # 删除session:  del(session['key'])


class redisutil_main:
    __plugin_path = "/www/server/panel/plugin/redisutil/"
    __api_url = "http://jiokong.dayuanren.net/api/"
    __config = None
    __redis = None

    # 构造方法
    def __init__(self):
        self.load_redis([])

    # 访问/demo/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self, args):
        return ""

    def load_redis(self, args):
        try:
            import redis
            return {"errno": 0, "errmsg": "加载成功"}
        except:
            return {"errno": 1, "errmsg": "请重启宝塔面板(宝塔面板：首页->右上角重启按钮)"}

    # 保存配置
    def save_config(self, args):
        if hasattr(args, "host") & hasattr(args, "password") & hasattr(args, "port"):
            redisconfig = {
                "host": args.host,
                "password": args.password,
                "port": args.port,
                "db": args.db
            }
            public.WriteLog("redisutil保存配置参数", "保存redis连接的参数")
            public.writeFile(
                self.__plugin_path + "redisconfig.json", json.dumps(redisconfig)
            )
            redisconfig = json.loads(
                public.readFile(self.__plugin_path + "redisconfig.json")
            )
            return {"errno": 0, "errmsg": "保存成功", "data": redisconfig}
        else:
            return {"errno": 1, "errmsg": "参数错误", "data": {}}

    # 获取配置
    def get_config(self, args):
        redisconfigfile = self.__plugin_path + "redisconfig.json"
        if os.path.exists(redisconfigfile):
            redisconfig = json.loads(public.readFile(redisconfigfile))
            if ~hasattr(redisconfig, 'db'):
                redisconfig['db'] = 16
                public.writeFile(
                    self.__plugin_path + "redisconfig.json", json.dumps(redisconfig)
                )
            return {"errno": 0, "errmsg": "获取成功", "data": redisconfig}
        else:
            return {"errno": 1, "errmsg": "暂无配置"}

    # 链接redis
    def __con_redis(self, db):
        redisconfigfile = self.__plugin_path + "redisconfig.json"
        if os.path.exists(redisconfigfile):
            redisconfig = json.loads(public.readFile(redisconfigfile))
            try:
                pool = redis.ConnectionPool(
                    host=redisconfig["host"],
                    password=redisconfig["password"],
                    port=int(redisconfig["port"]),
                    db=db,
                )
                self.__redis = redis.Redis(connection_pool=pool)
            except (ConnectionError, TimeoutError) as e:
                return public.returnMsg(False, '链接失败')
        else:
            return public.returnMsg(False, "您还未配置redis链接参数")

    # 获取库的数量
    def get_dbsize(self, args):
        redisconfigfile = self.__plugin_path + "redisconfig.json"
        if os.path.exists(redisconfigfile):
            try:
                redisconfig = json.loads(public.readFile(redisconfigfile))
                self.__con_redis(0)
                keynum = self.__redis.dbsize()
            except Exception as e:
                return public.returnMsg(False, '链接失败，请修改链接配置！错误原因：' + str(e))
            if keynum == 0:
                self.__redis.set("redisutil", "您的redis中没有任何一个库，这是redisutil插入的测试数据")
            return {"errno": 0, "errmsg": "ok", "data": {'dbsize': redisconfig['db']}}
        else:
            return {"errno": 1, "errmsg": "您还未配置redis链接参数"}

    # 获取某库的所有键-分页
    def get_dbkeys(self, args):
        db = args.db if hasattr(args, "db") else 0
        key = args.key if hasattr(args, "key") and args.key else "*"
        page = int(args.page if hasattr(args, "page") else 1)
        rows = 13
        self.__con_redis(db)
        alllist = self.__redis.keys(key)
        count = len(alllist)
        page_data = public.get_page(
            count, p=page, rows=rows, callback="app.get_dbkeys", result="1,2,3,4,5,8"
        )
        start = int(page_data["shift"])
        end = int(page_data["shift"]) + int(page_data["row"])
        end = end if end < count else count
        keys = []
        for num in range(start, end):
            keys.append(alllist[num].decode('utf-8'))
        return {"errno": 0, "errmsg": "ok", "data": {
            "keys": keys,
            "db": db,
            "key": key,
            "page_data": {'count': count, 'page': page, 'rows': rows}
        }}

    # 获取数据
    def get_value(self, args):
        db = args.db if hasattr(args, "db") else 0
        if hasattr(args, "key") and args.key != "":
            self.__con_redis(db)
            typename = self.__redis.type(args.key).decode('utf-8')
            ttl = self.__redis.ttl(args.key)
            if typename == 'string':
                value = self.__redis.get(args.key)
                return {
                    "errno": 0,
                    "errmsg": "ok",
                    "data": {
                        "value": value.decode('utf-8'),
                        "db": db,
                        "key": args.key,
                        "type": typename,
                        "ttl": ttl
                    }
                }
            elif typename == 'list':
                value = self.__redis.lrange(args.key, 0, self.__redis.llen(args.key))
                return {
                    "errno": 0,
                    "errmsg": "ok",
                    "data": {
                        "value": value.decode('utf-8'),
                        "db": db,
                        "key": args.key,
                        "type": typename,
                        "ttl": ttl
                    }
                }
            elif typename == 'set':
                value = self.__redis.smembers(args.key)
                return {
                    "errno": 0,
                    "errmsg": "ok",
                    "data": {
                        "value": list(value),
                        "db": db,
                        "key": args.key,
                        "type": typename,
                        "ttl": ttl
                    }
                }
            elif typename == 'zset':
                value = self.__redis.zrevrange(args.key, 0, self.__redis.zcard(args.key))
                return {
                    "errno": 0,
                    "errmsg": "ok",
                    "data": {
                        "value": list(value),
                        "db": db,
                        "key": args.key,
                        "type": typename,
                        "ttl": ttl
                    }
                }
            elif typename == 'hash':
                value = self.__redis.hgetall(args.key)
                return {
                    "errno": 0,
                    "errmsg": "ok",
                    "data": {
                        "value": json.dumps(value),
                        "db": db,
                        "key": args.key,
                        "type": typename,
                        "ttl": ttl
                    }
                }
            else:
                return {
                    "errno": 1,
                    "errmsg": "未知类型[" + typename + "]请联系开发者",
                    "data": {"value": "", "db": db, "key": "", "type": typename},
                }
        else:
            return {
                "errno": 1,
                "errmsg": "获取失败",
                "data": {"value": "", "db": db, "key": ""},
            }

    # 保存数据
    def set_value(self, args):
        if hasattr(args, "key") and hasattr(args, "value") and hasattr(args, "db"):
            self.__con_redis(args.db)
            self.__redis.set(args.key, args.value)
            return {
                "errno": 0,
                "errmsg": "保存成功",
                "data": {"value": args.value, "db": args.db, "key": args.key},
            }
        else:
            return {
                "errno": 1,
                "errmsg": "参数错误",
                "data": {"value": "", "db": "", "key": ""},
            }

    # 删除KEY
    def del_key(self, args):
        if hasattr(args, "key") and hasattr(args, "db"):
            self.__con_redis(args.db)
            self.__redis.delete(args.key)
            return {"errno": 0, "errmsg": "删除成功", "data": {}}
        else:
            return {"errno": 1, "errmsg": "参数错误", "data": {}}

    # 删除KEY
    def del_alldbkey(self, args):
        if hasattr(args, "db"):
            self.__con_redis(args.db)
            self.__redis.flushdb()
            return {"errno": 0, "errmsg": "删除成功", "data": {}}
        else:
            return {"errno": 1, "errmsg": "参数错误", "data": {}}

    # 通用json数据返回
    def _return(self, errno, errmsg, data={}):
        return {"errno": errno, "errmsg": errmsg, "data": data}

    # 读取配置项(插件自身的配置文件)
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_config(self, key=None, force=False):
        # 判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)
        # 取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    # 设置配置项(插件自身的配置文件)
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __set_config(self, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config: self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
