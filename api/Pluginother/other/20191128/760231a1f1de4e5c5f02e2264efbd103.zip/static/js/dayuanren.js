//dayuanren.js 宝塔插件版本
//依赖jquery 1.5 以上或者zepto
var dyr = {
    debug: true,
    version: 1.0,
    plugin_name: "redisutil",//插件名
    timeout: 3600,
    /**
     * 发送请求到插件
     * @param function_name  要访问的方法名，如：get_logs
     * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"demo.get_logs"}
     * @param callback       请传入处理函数，响应内容将传入到第一个参数中
     */
    request: function (function_name, param, callback) {
        $.ajax({
            type: 'POST',
            dataType: "json",
            url: '/plugin?action=a&s=' + function_name + '&name=' + dyr.plugin_name,
            data: param,
            timeout: dyr.timeout,
            success: function (rdata) {
                if (!callback) {
                    alert(rdata.msg);
                    return;
                }
                if (rdata.status === false) {
                    alert(rdata.msg);
                    return;
                }
                return callback(rdata);
            },
            error: function (ex) {
                if (!callback) {
                    alert('请求过程发现错误!');
                    return;
                }
                return callback(ex);
            }
        });
    },
    //打印控制台
    print: function (data) {
        console.log(data);
    },
    // 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
    // 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
    //dyr.timeformat(1506051966,"yyyy-MM-dd HH:mm:ss")
    timeformat: function (timestamp, fmt) {
        var fmt = arguments[1] ? arguments[1] : "yyyy-MM-dd hh:mm:ss";
        if (!timestamp) return "";
        var cdate = new Date();
        if (timestamp.toString().length == 10) {
            cdate.setTime(timestamp * 1000);
        } else {
            cdate.setTime(timestamp);
        }
        var o = {
            "M+": cdate.getMonth() + 1, //月份
            "d+": cdate.getDate(), //日
            "h+": cdate.getHours(), //小时
            "m+": cdate.getMinutes(), //分
            "s+": cdate.getSeconds(), //秒
            "q+": Math.floor((cdate.getMonth() + 3) / 3), //季度
            "S": cdate.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (cdate.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    },
    getCookie: function (name) {
        var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
        if (arr = document.cookie.match(reg))
            return unescape(arr[2]);
        else
            return null;
    }
};