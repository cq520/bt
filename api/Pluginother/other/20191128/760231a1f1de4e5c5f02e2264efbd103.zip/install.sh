#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/redisutil

#安装
Install()
{
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
 # wget --no-check-certificate https://pypi.python.org/packages/source/r/redis/redis-2.8.0.tar.gz
  #  tar -zvxf redis-2.8.0.tar.gz
	#rm -f redis-2.8.0.tar.gz
 #   mv redis-2.8.0 $install_path/python-redis-2.8.0
  #  cd $install_path/python-redis-2.8.0
 #   python setup.py install
	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
