#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfboot
#+--------------------------------------------------------------------

from __future__ import absolute_import
from __future__ import print_function
import os
import subprocess

import sys
import time
import argparse
import logging
import signal
import json
import socket
import re
import threading

if __name__=="__main__":
    logging.basicConfig(
        filename='/www/server/panel/plugin/mfboot/mfboot.log',
        level=logging.DEBUG,
        format='%(asctime)s  %(filename)s : %(levelname)s  %(message)s',  # 定义输出log的格式
        filemode='a',
        datefmt='%Y-%m-%d %A %H:%M:%S',
    )
        



dirPath='/etc/'
listDirConfig=[
    'rc0.d',
    'rc1.d',
    'rc2.d',
    'rc3.d',
    'rc4.d',
    'rc5.d',
    'rc6.d',
    'rcS.d',
]


def get_enable_daemon():
    """Obtenir la liste des daemons actifs."""
    global dirPath
    global listDirConfig
    activeDaemon = []

    for d in listDirConfig:
        if not os.path.isdir(dirPath+d): continue
        for ad in os.listdir(dirPath+d):
            if ad[0] == 'S' and not ad in activeDaemon:
                activeDaemon.append(ad)

    return activeDaemon


def get_disable_daemon():
    """Obtenir la liste des daemons actifs."""
    global dirPath
    global listDirConfig
    activeDaemon = [x[3:] for x in get_enable_daemon()]
    inactiveDaemon = []

    for d in listDirConfig:
        if not os.path.isdir(dirPath+d): continue
        for ad in os.listdir(dirPath+d):
            if ad[0] == 'K' and not ad[3:] in activeDaemon:
                if not ad in inactiveDaemon:
                    inactiveDaemon.append(ad)

    return inactiveDaemon

    
def set_disable_daemon(daemons):
    """Désactiver les daemons passés en argument."""
    global listDirConfig
    global dirPath
    enableDaemon=get_enable_daemon()

    for nameDaemon in daemons:
        exist =False

        for ed in enableDaemon:
            if nameDaemon == ed[3:]:
                nameDaemon = ed
                exist = True
                break

        if not exist:
            continue

        for dc in listDirConfig:
            if nameDaemon in os.listdir(dirPath+dc):
                os.rename(
                    dirPath + dc + '/' + nameDaemon, 
                    dirPath + dc + '/K' + nameDaemon[1:]
                )
        cmd = 'update-rc.d {} defaults 2> /dev/null'.format(nameDaemon[3:])
        subprocess.call(cmd, shell=True)
        print('* {} [disabled]'.format(nameDaemon[3:]))
        
        subprocess.call("chkconfig %s off"%(nameDaemon[3:]), shell=True)
    

def set_enable_daemon(daemons):
    """Activer les daemons passés en argument."""
    global listDirConfig
    global dirPath
    disableDaemon=get_disable_daemon()

    for nameDaemon in daemons:
        exist=False

        for ed in disableDaemon:
            if nameDaemon == ed[3:]:
                nameDaemon, exist=ed, True
                break

        if not exist:
            continue

        for dc in listDirConfig:
            if not os.path.isdir(dirPath+dc): continue
            if nameDaemon in os.listdir(dirPath+dc):
                os.rename(
                    dirPath+dc+'/'+nameDaemon, 
                    dirPath+dc+'/S'+nameDaemon[1:]
                )
        cmd = 'update-rc.d {} defaults 2> /dev/null'.format(nameDaemon[3:])
        subprocess.call(cmd, shell=True)
        print('* {} [enabled]'.format(nameDaemon[3:]))
        subprocess.call("chkconfig %s on"%(nameDaemon[3:]), shell=True)

def display_daemon(listDaemon):
    """Afficher proprement la liste de daemons actifs."""
    print()

    for d in sorted([x[3:] for x in listDaemon]):
        print('* {}'.format(d))
 

def change_now(listDaemon, action):
    for d in listDaemon:
        cmd = subprocess.Popen(['service', d, action],
            stdout = subprocess.PIPE, 
            stderr = subprocess.PIPE
        )
        stdout, stderr = cmd.communicate()

        if stderr:
            print(stderr)


def have_right():
    """Savoir si le script est lancé avec les bons droits."""
    global listDirConfig
    global dirPath
    access = True

    for d in listDirConfig:
        if not os.path.isdir(dirPath+d): continue
        if not os.access(dirPath+d, os.W_OK):
            access = False
            break

    if not access:
        print('Permission denied (use sudo).')

    return access

def init_func(cmd):
    print(cmd)
    logging.info('(start)'+cmd)
    subprocess.call(cmd, shell=True)
    logging.info('(end)'+cmd)
    
def init_boot():
    pth = '/www/server/panel/plugin/mfboot/config.json'
    if not os.path.isfile(pth): return
    d = json.load(open(pth))
    L = []
    for k,d in d.get('list',{}).items():
        if not d.get('disabled'):
            L.append(threading.Thread(target=init_func,args=(d['daemon'],)))
    for o in L:
        o.setDaemon(False)
        o.start()


if __name__ == '__main__':
    if '--run' in sys.argv:
        init_boot()
        exit(0)

    parser=argparse.ArgumentParser(prog='dsda')
    parser.add_argument('-v', '--version', action='version', version='%(prog)s 1.0')
    parser.add_argument('-n', '--now', action='store_true',
        help='enable or disable daemon immediatly (service <daemon> start/stop)')
    parser.add_argument('-d', '--disable', nargs='*', 
        help='daemons to disable at boot (without arg, display disabled daemon)')
    parser.add_argument('-e', '--enable', nargs='*', 
        help='daemons to enable at boot (without arg, display enable daemon)')

    args = parser.parse_args()

    if args.disable != None:
        if len(args.disable) >= 1:
            if have_right():
                set_disable_daemon(args.disable)
                if args.now:
                    change_now(args.disable, 'stop')
        else:
            display_daemon(get_disable_daemon())

    elif args.enable != None:
        if len(args.enable) >= 1:
            if have_right():
                set_enable_daemon(args.enable)
                if args.now:
                    change_now(args.enable, 'start')
        else:
            display_daemon(get_enable_daemon())
    else:
        parser.print_help()






