#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os,sys,stat
def Argv(k, tp=0):
    argv2 = sys.argv[1:]
    index = None
    if k in argv2: index = argv2.index(k)+1
    return argv2[index] if index  else None



def create_bash_autostart(exefile, pidname, pyexe='python'):
    '''
    系统为了某些功能必须要提供一些服务（不论是系统本身还是网络方面），这个服务就是service.实现这个service的程序称为daemon.
  
    daemon主要分为两类
    stand alone:此daemon可以自行单独启动服务
    super daemon:一个特殊的daemon来同一管理
        这个特殊的daemon被称为super daemon ，即 xinetd.特点在于，当没有客户端的请求时，各项服务都是未启动的情况，等到有来自客户端的请求时，super daemon 才唤醒对应的服务。当客户端的请求结束后，被唤醒的这个服务也会关闭并释放系统资源。
    这两类 daemon 可以同时存在于内存中。
    文件 /etc/services 中存有端口号与服务的一一对应，不建议修改，除非要建设一个地下网站。


    daemon 的启动脚本与启动方式
    /etc/init.d/* : 启动脚本放置处
    系统上几乎所有的服务启动脚本都放在这里。
    /etc/sysconfig/* : 各服务的初始化环境配置文件
    /etc/xinetd.conf,/etc/xinetd.d/* :super daemon配置文件
    super daemon 的主要配置文件为 /etc/xinetd.conf,但它管理的其他 daemon 的设置则写在 /etc/xinetd.d/* 里面。
    /etc/* : 各服务各自的配置文件
    /var/lib/* : 各服务产生的数据库
    /var/run/* : 各服务的程序的PID记录处

    stand alone 的 /etc/init.d/* 启动
    几乎系统上面所有的启动脚本都在 /etc/init.d/ 下面，所以可以这样启动：
    #/etc/init.d/syslog {start|stop|status|condrestart}
    例如：#/etc/init.d/syslog status

    CentOS还提供另外一种启动方式，即service：
       /sbin/service
    #service [service name] (start|stop|restart|...)
    #service --status-all
     service name:就是需要启动的服务名称
     start|...:就是该服务要进行的工作
     --status-all:将系统所有的stand alone的服务状态全部列出来

    例子：#service crond restart
    #/etc/init.d/crond restart
    这两个效果一样，但是后一种一定得记住。

    # 大写的S,代表start,其后紧跟启动顺序数字,然后是service name. 大写的K,代表kill,K或S后面的数字表示执行顺序，数字小的先执行。
    但是你不想删除该脚本，仅仅是让它不要开机启动，出了上面的chkconfig off命令外，也可以直接将/etc/rc.d/rc[2-5].d/下面对应的S开头的链接改名为小写s开头即可.
    系统在进入一个运行级别时，首先将该运行级别对应的目录中以K开头的脚本按设定顺序执行，然后再将以S开头的脚本按顺序执行。

    若该脚本的软连接以S开头，则系统启动的时候执行start-thing代码段，
    若该脚本的软连接以K开头的话，则系统启动时执行stop-thing代码段
    （有一点儿例外的是运行级别0，因为0级别是关闭系统，所以/etc/rc0.d/下的以S开头的软连接也执行stop-thing段）


    linux 设置非root用户开机自启动sh脚本非常简单 
    使用root用户修改文件/etc/rc.d/rc.local，在文件最后添加命令和要执行的脚本
    su my -c "/home/my/startup.sh" #-c command：变更账号为USER的my使用者，并执行指令（command）后再变回原来使用者。
    添加完之后重启linux，发现并没有执行脚本，然后看了一下rc.local的授权是-rw-r--r--，发现并没有执行权限。使用root用户添加可执行权限，然后重启就解决了。
    chmod o+x /etc/rc.d/rc.local

    '''
    
    bash = ["#!/bin/bash -e", #有时使用#!/bin/bash -e表示脚本发生第一个错误时就中止脚本运行，对于那些不想终止的命令使用$0 stop || true
            '# chkconfig: 2345 99 90', #这行注释需要否则会报错 90代表的是在开机启动脚本中的启动顺序（第90个启动）
            '# description: %(exefile)s by moofei ', #这行注释需要否则会报错
            '# processname: %(pidname)s',
            "cd %(exedir)s; ",
            
            'RETVAL=0',
            "pidfile=%(pidfile)s",
            "exefile=%(exefile)s",
            #"pid="
            #'prog="nginx"',
            "",
            'set -e',

            #'# Source function library.',
            #'. /etc/init.d/functions', #action
            #'# Source networking configuration.',
            #'. /etc/sysconfig/network',
            #'# Check that networking is up.',
            #'[ ${NETWORKING} = "no" ] && exit 0',
            #'[ -x $nginxd ] || exit 0',
            #'# Start prog daemons functions.',


            ######ERROR: List of process IDs must follow -p.


            'killpid(){',
            #'    pid=`ps -ef | grep -v grep | grep -v "test.sh" | grep $1 | sed -n  '1P' | awk '{print $2}'`  ',
            #'    cat $pidfile',
            #'    pid=$?',
            '    pid=$(cat $pidfile)',  #????? wokao pid与=之间有空格报错
            #'    pid = `cat $pidfile`',  #row 11
            #'    if [ -n $pid ];then',
            '    if [ -s $pidfile ];then',
            '        ps -p $pid',
            '        if [ $? -eq 0 ]; then',
            '            kill -9 $pid',
            '            echo -e "\033[31mkilled %(pidname)s process ${pid} OK\033[0m"',
            '        else',
            '            echo "killed %(pidname)s process ${pid} Exit"',
            '        fi',
            '     else',
            '         echo "killed %(pidname)s Fail"',
            '    fi',
            '    rm -rf $pidfile',
            '}',

            'run(){',
            
            'if [ -f $pidfile ];then',                     # 判断pid文件，存在就不再启动
            '    echo "%(exefile)s is already running"',
            'else',
            '    echo "$@"',
            '    echo "%(pyexe)s %(exefile)s $cfg --debug -debug 1 "',
            '    %(pyexe)s %(exefile)s $cfg --debug -debug 1 ',
            'fi ',
            '}',

            'start(){',
            'if [ -f $pidfile ];then',                     # 判断pid文件，存在就不再启动
            '    echo "%(exefile)s is already running"',
            'else',
            '    nohup flock -xn %(pidfile)s -c "nohup %(pyexe)s %(exefile)s -pidfile %(pidfile)s >/dev/null 2>&1 &" ',
            #'    nohup %(pyexe)s %(exefile)s %(execfg)s -pidfile %(pidfile)s >/dev/null 2>&1 & ',
            #'    %(pyexe)s %(exefile)s %(execfg)s -pidfile %(pidfile)s ',
            '    echo -e "\033[34m%(exefile)s starts successfully\033[0m"',
            #'    action "%(exefile)s starts successfully "  /bin/true',
            'fi ',
            '}',


            'stop(){',
            'if [ -f $pidfile ];then',
            '    killpid',
            #'    kill -9 `cat $pidfile`',
            #'    rm -rf $pidfile',                            # 停止服务，就删除pid文件
            #'    action "%(exefile)s stops successfully" /bin/true',
            '    echo "%(exefile)s stops successfully"',
            'else',
            #'    action "%(exefile)s is already stopped Failed" /bin/false',
            '    echo "%(exefile)s is already stopped Failed"',
            'fi',
            '}',

            'status(){'
            '    pid=$(cat $pidfile)',  #????? wokao pid与=之间有空格报错
            '    if [ -s $pidfile ];then',
            #'        ps -f -p $pid',
            #'        ps -o pid,ppid,start,user,sid,%%cpu,%%mem,vsz,rss,stat,ni,command -p $pid',
            '        ps -o pid,ppid,start,stime,time,user,thcount,lwp,%%cpu,%%mem,stat,ni,tty,command -T $pid',
            '        if [ $? -eq 0 ]; then',
            '            echo "pid:${pid} process start ${exefile} ."',
            '        else',
            '            echo "%(pidname)s process ${pid} Exit"',
            '        fi',
            '     else',
            '         echo "pid ${pid}s Fail"',
            '    fi',
            '}',
            
            'case "$1" in',
            '    start)',
            '        start',
            '        ;;',
            '    run)',
            '        run $2',
            '        ;;',
            '    stop)',
            '        stop',
            '        rm -rf $pidfile',
            '        ;;',
            '    killpid)',
            '        killpid',
            '        ;;',
            '    status)',
            '        status',
            '        ;;',
            '    restart)',
            '        stop',
            '        sleep 1',
            '        start',
            '        ;;',
            '    *)',
            '        echo "Usage:$0 start|run|stop|status|restart|killpid"',
            '        exit 1',
            'esac',
            
            'exit $RETVAL'  # 如果脚本已经移除或者移除成功，则返回为0，否则返回为非0值。
            ]
    #chkconfig --del passport.py.sh
    
    
    exedir = os.path.dirname(exefile)
    pidfile = "/var/run/%s.pid"%pidname
    lockfile = os.path.join(exedir, '%s.lock'%pidname)
    exesh = "python %s"%(os.path.basename(exefile))
    #from funcApi import this as funcThis
    #funcThis.dos2unix(_path)
    #os.chmod(_path, stat.S_IRWXU+stat.S_IRWXG+stat.S_IRWXO)
    
    d = {
        'exedir':exedir,
        'exefile':exefile,
        'pidfile':pidfile,
        'pidname':pidname,
        'lockfile':lockfile,
        'pyexe':pyexe,
        #'execfg':execfg,
        'exesh':exesh
    }
    #print 'nohup flock -xn %(pidfile)s -c "nohup python %(exefile)s %(execfg)s -pidfile %(pidfile)s >/dev/null 2>&1 &" '%d
    R = ('\n'.join(bash))%d
    sh = pidname+'.sh'
    with open(sh, 'w') as f:
        f.write(R)
    os.chmod(sh, stat.S_IRWXU+stat.S_IRWXG+stat.S_IRWXO)
    
    
    ml = ['#!/bin/bash',
          '# chkconfig: - 99 15', #'# chkconfig: 2345 10 90',
          '# description:  by moofei ',
          'cp %s /etc/init.d/%s'%(sh, pidname),
          'chmod +x  /etc/init.d/%s'%pidname, #2、增加脚本的可执行权限
          #'mv  %s /etc/rc.d/init.d'%path, #1、将脚本移动到/etc/rc.d/init.d目录下
          #'chmod +x  /etc/rc.d/init.d/%s'%f, #2、增加脚本的可执行权限
          #'cd /etc/rc.d/init.d', #3,4,5、添加脚本到开机自动启动项目中
          'cd /etc/init.d', #3,4,5、添加脚本到开机自动启动项目中
          'chkconfig --add %s'%pidname, #3,4,5、添加脚本到开机自动启动项目中
          'chkconfig %s on'%pidname, #3,4,5、添加脚本到开机自动启动项目中
          'service %s start'%pidname #3,4,5、添加脚本到开机自动启动项目中
         ]

    auto = os.path.abspath(pidname)+'.auto'
    with open(auto, 'w') as fr:
        R = '\n'.join(ml)
        fr.write(R)
        print R
        
    output = os.popen('/bin/bash %s'%auto) 
    rtn = output.read()
    #os.remove(auto)
    print rtn
    #print output
    print "chkconfig --list"


def main():
    exefile = Argv('-exefile') or Argv('-file') or Argv('-f')
    execfg = Argv('-execfg') or Argv('-cfg') or Argv('-conf')
    pidname = Argv('-pidname') or Argv('-pid')
    if os.name=='nt':
        pyexe = 'python'
    else:
        pyexe = Argv('-pyexe') or [e for e in ('/usr/local/bin/python2.7','/usr/bin/python2.7') if os.path.isfile(e)][0]
    
    if exefile and os.path.isfile(exefile) and pidname:
        create_bash_autostart(exefile, pidname, pyexe)
    else:
        print "python autosh.py -exefile ? -execfg ? -pidname ? "
        
if __name__ == "__main__":
    #create_bash_autostart("/home/liuyouhua/mufei/passport.py", "server.cfg", 'mufeiapi')
    "python autosh.py -f /home/liuyouhua/mufei/passport.py -cfg site.cfg -pid mufeiapi"
    main()
    

