#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/mfboot



b="Darwin"
c="centos"
d="ubuntu"
l="Linux"

LinuxInstall()
{
    cp /www/server/panel/plugin/mfboot/mfboot.sh /etc/init.d/mfboot
    chmod +x  /etc/init.d/mfboot
    cd /etc/init.d
    chkconfig --add mfboot
    chkconfig mfboot on
    service mfboot start
    echo '安装mfboot开机启动完成'
}


#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    
    LinuxInstall
    
	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
    chkconfig --del mfboot
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
