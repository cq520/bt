#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfboot
#+--------------------------------------------------------------------

__all__ = ['mfboot_main']

import sys,os,json,re,time,math,copy


#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = basedir


if __name__ != '__main__':
    #添加包引用位置并引用公共包
    sys.path.append("class/")
    import public
    from BTPanel import cache,session

    


class mfboot_main:
    __plugin_path = plugin_path
    __config = None
    
    def __init__(self):
        self.__config = self.__get_config() or {}
        self.__config.setdefault('list',{})
        
    def index(self, args):
        
        return self.__config
    
    def enableboot(self, args):
        from mfboot import get_enable_daemon
        L = get_enable_daemon()
        L = [e[3:] for e in L]
        return {'list':L}
    
    def set_disable_daemon(self, args):
        daemon = args.daemon.strip()
        from mfboot import set_disable_daemon
        set_disable_daemon([daemon])
        return {}
    
    def disableboot(self, args):
        from mfboot import get_disable_daemon
        L = get_disable_daemon()
        L = [e[3:] for e in L]
        return {'list':L}

    def set_enable_daemon(self, args):
        daemon = args.daemon.strip()
        from mfboot import set_enable_daemon
        set_enable_daemon([daemon])
        return {}

        
    def add_ext_daemon(self, args):
        name = args.daemonname.strip()
        daemon = args.daemon.strip()
        self.__set_config(name, {'daemon':daemon, 'name':name})
        return {}
    
    def set_ext_daemon(self, args):
        daemon = args.daemon.strip()
        self.__set_config(daemon)
        return {}
    
    def del_ext_daemon(self, args):
        daemon = args.daemon.strip()
        self.__set_config(daemon, 'del')
        return {}  
            

    def __get_config(self,key=None,force=False):
        if not self.__config or force:
            config_file = self.__plugin_path + '/'+ 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)
            
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config


    

    def __set_config(self,key=None,value=None):
        """
        """
        if not self.__config:
            self.__config = {"list":{}}
            
        if value=="del":
            self.__config['list'].pop(key,None)
        elif value:
            self.__config['list'][key] = value
            
        else:
            self.__config['list'][key]['disabled'] = not self.__config['list'][key].get('disabled')
        
        config_file = self.__plugin_path +'/'+ 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        
        return True

    


        
        
    
    
        
    

