<?php

/*
站长好工具宝塔管理员必备站长好工具

这个功能应该很实用且和宝塔用户很对口，大部分是站长用得到
公布PHP端供参考（你们可以写python）

A记录：将域名指向一个IPv4地址（例如：10.10.10.10），需要增加A记录
CNAME记录：如果将域名指向一个域名，实现与被指向域名相同的访问效果，需要增加CNAME记录
MX记录：建立电子邮箱服务，将指向邮件服务器地址，需要设置MX记录
NS记录：域名解析服务器记录，如果要将子域名指定某个域名服务器来解析，需要设置NS记录
TXT记录：可任意填写（可为空），通常用做SPF记录（反垃圾邮件）使用
AAAA记录：将主机名（或域名）指向一个IPv6地址（例如：ff03:0:0:0:0:0:0:c1），需要添加AAAA记录
SRV记录：记录了哪台计算机提供了哪个服务。格式为：服务的名字.协议的类型（例如：_example-server._tcp）
*/

class bt_main{
 //不允许被面板访问的方法请不要设置为公有方法
//推荐linux平台php5.4-5.6 windows下ngnix apache也正常

// 获取域名默认
public function getip(){
   $domas = $_SERVER['SERVER_NAME']; //暂不知获取方式
   if($domas =='null' || $domas ==''){ $domas ="yichaxin.com"; }
   return $domas;
 }
 
 // 获取域名
public function getdoma(){
   $db = new SQLite3('/www/server/panel/data/default.db'); //要不要判断文件是否存在呢
   if(!$db){
         return "<option value =\"yichaxin.com\">读取失败</option>"; //读取不到就默认域名
   }
 $ret = $db->query("SELECT * from domain");
  $domas = ""; $ia = 0;
  $domas .= "<option value =\"0\">查所有绑定域名 【建议单选查询】</option>";
 while($row = $ret->fetchArray(SQLITE3_ASSOC)){
  $sitename =	$row['name'];  $siteid =	$row['id'];
  $domas .= "<option value =\"{$siteid}\">单查域名 $sitename </option>";  $ia++;
 }
  $db->close();
  if($ia<1)  return "<option value =\"yichaxin.com\">暂未绑定</option>";
    return $domas;
 }
 
 public function getsite(){
   $db = new SQLite3('/www/server/panel/data/default.db'); //要不要判断文件是否存在呢
   if(!$db){
         return "<option value =\"yichaxin.com\">读取失败</option>"; //读取不到就默认域名
   }
 $ret = $db->query("SELECT * from sites");
   $domas = "";  $ib = 0;    
 while($row = $ret->fetchArray(SQLITE3_ASSOC)){
  $sitename =	$row['name'];   $siteid =	$row['id'];
  $domas .= "<option value =\"{$siteid}\">查站点 $sitename 绑定的域名</option>";    $ib++;
 }
  $db->close();
 if($ib<1)  return "<option value =\"yichaxin.com\">暂无站点</option>";
    return $domas;
 }
 
public function yichaxin(){
$CACHE = "抱歉:查询不到信息"; //初始提示
$doma = _get('ip'); //获取域名
if(!$doma){ $doma = _post('ip'); }
if(!preg_match("/^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-z]{2,8})$/i", $doma)) {
    return ['state'=>'1001','table'=>$doma];
}
$tipa = _get('dk'); //获取查询类型
if($tipa =='null' || $tipa ==''){ $tipa = _post('dk'); }
$tpli = "|DNS_NS|DNS_A|DNS_AAAA|DNS_MX|DNS_CNAME|DNS_TXT|DNS_SRV|GETHOSTBYNAME|gethostbyname|";
if(!stristr($tpli,"|{$tipa}|")) {
    $tipa = "gethostbyname";
}
$doma = strtolower($doma); //类型转大写
$tipa = strtoupper($tipa); //域名转小写
    //return ['state'=>'1004','doma'=>$doma,'tapa'=>$tipa];
switch ($tipa) {
   case "DNS_A":
$CACHE = dns_get_record($doma, DNS_A);
     break;
   case "DNS_CNAME":
$CACHE = dns_get_record($doma, DNS_CNAME);
     break;
   case "DNS_MX":
$CACHE = dns_get_record($doma, DNS_MX);
     break;
   case "DNS_AAAA":
$CACHE = dns_get_record($doma, DNS_AAAA);
     break;
     case "DNS_NS":
$CACHE = dns_get_record($doma, DNS_NS);
     break;
     case "DNS_TXT":
$CACHE = dns_get_record($doma, DNS_TXT);
     break;
   case "DNS_SRV":
$CACHE = dns_get_record($doma, DNS_SRV);
     break;
   default:
$myip = "<h2>".gethostbyname($doma)."</h2>";
    return ['ip' => $doma, 'dk' => "gethostbyname", 'state'=>'1000','table'=>$myip];
     break;
}

//$CACHE = dns_get_record($doma);
if($CACHE){
//$CECHE = json_encode($CACHE);
 $ii=0; $res = "";
 $res .= "<table cellspacing=\"0\" class=\"table\" cellpadding=\"0\">\r\n";
foreach ($CACHE as $keylist){
$ii++;
if($ii==1){
	$res .= "<tr class=\"tt\">\r\n";
foreach ($keylist as $key=>$val){
$res .= "<td>$key</td>\r\n";
}
	$res .= "</tr>\r\n";
}
	$res .= "<tr>\r\n";
foreach ($keylist as $key=>$val){
$res .= "<td>$val</td>\r\n";
}
	$res .= "</tr>\r\n";
}
$res .= "</table>\r\n";
if($ii<1){
 return ['state'=>'1003'];
} else {
 return array('ip' => $doma, 'dk' => $tipa, 'state' => '1000', 'table' => $res);	
}

  } else {
$myip = "<h2>".gethostbyname($doma)."</h2>";
$tpli = "|DNS_A|DNS_AAAA|DNS_CNAME|GETHOSTBYNAME|gethostbyname|";
if(stristr($tpli,"|{$tipa}|")) {
if($CACHE==$doma){
    return ['state'=>'1003'];
}else{
    return ['ip' => $doma, 'dk' => "gethostbyname", 'state'=>'1000','table'=>$myip];
}
}else{
    return ['state'=>'1005','msg'=>'null'];
} 

 
}
}



public function yichasite(){
$CACHE = "抱歉:查询不到信息"; //初始提示
$doma = _get('ip'); //获取域名
if(!$doma){ $doma = _post('ip'); }
if(!preg_match("/^[0-9]{1,8}$/i", $doma)) {
    return ['state'=>'1001','table'=>$doma];
}
$db = new SQLite3('/www/server/panel/data/default.db'); //要不要判断文件是否存在呢
   if(!$db){
   return ['state'=>'1001','table'=>$doma];
   }
 $ret = $db->query("SELECT * from domain where pid = {$doma}");	
   $myip = "";  $ib = 0;
   $myip = "<table cellspacing=\"0\" class=\"table\" cellpadding=\"0\">\r\n";
   $myip .= "<tr class=\"tt\"><td>序号</td><td>绑定域名</td><td>查询结果(解析IP)</td></tr>";
 while($row = $ret->fetchArray(SQLITE3_ASSOC)){
  $sitename =	$row['name']; $ib++;
  $sitename = strtolower($sitename); //类型转大写
$tipa = gethostbyname($sitename); //域名转小写
if($tipa == $sitename){
$myip .= "<tr><td>{$ib}</td><td>{$sitename}</td><td>可能未作解析或未生效</td></tr>";
}else{
$myip .= "<tr><td>{$ib}</td><td>{$sitename}</td><td>".$tipa."</td></tr>";	
}

 }
  $db->close();
 if($ib<1)  return ['state'=>'1001','table'=>$doma];
return ['ip' => $doma, 'dk' => "gethostbyname", 'state'=>'1000','table'=>$myip];
}



public function yichadoma(){
$CACHE = "抱歉:查询不到信息"; //初始提示
$doma = _get('ip'); //获取域名
if(!$doma){ $doma = _post('ip'); }
if(!preg_match("/^[0-9]{1,8}$/i", $doma)) {
   return ['state'=>'1001','table'=>$doma];
}
$db = new SQLite3('/www/server/panel/data/default.db'); //要不要判断文件是否存在呢
   if(!$db){
   return ['state'=>'1001','table'=>$doma];
   }
 if($doma>0){
 $ret = $db->query("SELECT * from domain where id = {$doma}");	
 }else{
 $ret = $db->query("SELECT * from domain "); 	
 }
   $myip = "<table cellspacing=\"0\" class=\"table\" cellpadding=\"0\">\r\n";
   $myip .= "<tr class=\"tt\"><td>序号</td><td>绑定域名</td><td>查询结果(解析IP)</td></tr>";
 while($row = $ret->fetchArray(SQLITE3_ASSOC)){
  $sitename =	$row['name']; $ib++;
  $sitename = strtolower($sitename); //类型转大写
$tipa = gethostbyname($sitename); //域名转小写
if($tipa == $sitename){
$myip .= "<tr><td>{$ib}</td><td>{$sitename}</td><td>可能未作解析或未生效</td></tr>";
}else{
$myip .= "<tr><td>{$ib}</td><td>{$sitename}</td><td>".$tipa."</td></tr>";	
}
 }
  $db->close();
 if($ib<1)  return ['state'=>'1001','table'=>$doma];
return ['ip' => $doma, 'dk' => "gethostbyname", 'state'=>'1000','table'=>$myip];
}




}