#!/bin/sh
cosfs img-1303972623 /IMG -o allow_other -o uid=1000,umask=000,gid=1000 -o passwd_file=/root/.passwd-img-1303972623 -o url=http://cos.ap-beijing.myqcloud.com