#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file='/www/server/panel/install/public.sh'
download_Url='http://bt.02988.com'
pluginPath='/www/server/panel/plugin/txoss'
pluginfile='cosfs-master.tar.gz'
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    if [ -f "/usr/local/bin/cosfs" ] || [ -f "/usr/bin/cosfs" ];then
       echo '环境已经安装...' > $install_tmp
    else
       echo '正在安装脚本文件...' > $install_tmp
	   mkdir -p ${pluginPath}
	   egrep -i "debian" /etc/issue /proc/version >/dev/null && SysName='Debian';
	   egrep -i "ubuntu" /etc/issue /proc/version >/dev/null && SysName='Ubuntu';
	   whereis -b yum | grep -q '/yum' && SysName='CentOS';
	   if [ "$SysName" == 'CentOS' ]; then
          sudo yum install -y automake gcc-c++ git libcurl-devel libxml2-devel fuse-devel make openssl-devel fuse
	   else
	      sudo apt-get install -y automake autotools-dev g++ git libcurl4-gnutls-dev libfuse-dev libssl-dev libxml2-dev make pkg-config fuse
	   fi;
	   
	   wget -O ${pluginfile} ${download_Url}/download/cosfs-master.tar.gz
       tar -zxvf ${pluginfile}
       cd cosfs-master
       ./autogen.sh
       ./configure
       make && sudo make install
       echo '安装完成' > $install_tmp
       cd ..
       rm -fr ${pluginfile}
       rm -fr cosfs-master
       echo '安装完成' > $install_tmp
   fi
	#依赖安装结束
	#==================================================================
	wget -O ${pluginPath}/index.html $download_Url/txoss/index.html -T 5
	wget -O ${pluginPath}/info.json $download_Url/txoss/info.json -T 5
	wget -O ${pluginPath}/txoss_main.py $download_Url/txoss/txoss_main.py -T 5
	wget -O ${pluginPath}/icon.png $download_Url/txoss/icon.png -T 5
        wget -O ${pluginPath}/install.sh $download_Url/txoss/install.sh -T 5
	\cp -a -r ${pluginPath}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-txoss.png
	echo '================================================'
	echo '安装完成'
}

Uninstall()
{
	rm -rf $pluginPath
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
