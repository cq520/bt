#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: Sudem <mail@szhcloud.cn>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   frp 服务器 管理工具
#|   Version: 1.7
#|修复插件在授权时可能会遇到的错误
#|新增进程守护模式,当frp 主进程意外退出时，将自动重启
#|内核升级为 0.31.0
#+--------------------------------------------------------------------
import sys,os,json,base64,re,datetime
import psutil,requests

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public
import firewalls


class py_object:
    pass

class frps_simple_main:
    __plugin_path = "/www/server/panel/plugin/frps_simple/"
    __config = None

    #构造方法
    def  __init__(self):
        #检查配置文件夹是否存在
        if not os.path.exists(self.__plugin_path+"conf/"):
            #新建 配置文件存放文件夹
            os.mkdir(self.__plugin_path+"conf")
            #新建 存放服务端配置信息的json 文件夹
            os.mkdir(self.__plugin_path+"conf/json")
            #新建 存放frps配置信息的ini 文件的文件
            os.mkdir(self.__plugin_path + "conf/ini")
            #新建 存放日志文件的文件夹
            os.mkdir(self.__plugin_path+"logs")
        #检查系统全局配置文件是否存在
        if not os.path.exists(self.__plugin_path+"conf/service.json"):        
            self.Auth_Reg()
            # 放行防火墙 10000-20000 默认映射端口
            port = py_object()
            port.port = "10000-20000"
            port.ps = "FRP服务端默认映射端口"
            fire = firewalls.firewalls()
            fire.AddAcceptPort(port)
            # 放行防火墙 64000-64500 默认通讯端口
            port = py_object()
            port.port = "64000-64500"
            port.ps = "FRP服务端默认通讯端口"
            fire = firewalls.firewalls()
            fire.AddAcceptPort(port)
            # 放行防火墙的 443 端口 以免出现 HTTPS 异常
            port = py_object()
            port.port = "443"
            port.ps = "HTTPS"
            fire = firewalls.firewalls()
            fire.AddAcceptPort(port)
        else:
            # 如果插件的版本发生了变化,更新授权
            auth = json.loads(public.ReadFile(self.__plugin_path + 'auth.json'))
            info = json.loads(public.ReadFile(self.__plugin_path + 'info.json'))
            if "Plugin_Ver" in auth and info['versions'] != auth['Plugin_Ver']:
                self.Auth_Update()
            # 如果面板的版本发生了变换,更新授权
            if "BT_Ver" in auth and public.version() != auth['BT_Ver']:
                self.Auth_Update()

    #|   ===================================================
    #|   全局配置管理控制函数
    #|   Version:1.0
    #|   Author:Sudem  sang8052@qq.com
    #|   Tips:
    #|        控制frps 服务器的全局配置、状态
    #|   ===================================================

    # 获取服务器全局配置信息
    # @args 空参数
    def Service_Config(self,args):
        config = public.readFile(self.__plugin_path+"conf/service.json")
        config = json.loads(config)
        return {"status":"Success","config":config}

    # 获取当前服务器上存在的服务端的配置文件数量
    # @args 空参数
    def Service_Count(self, args):
        count = 0
        for file in os.listdir(self.__plugin_path+"conf/json/"):
            if re.match("\S{16}.json",str(file)) and os.path.isfile(self.__plugin_path+"conf/json/"+file):
                count = count + 1
        return {"status": "Success", "Count": count}

    # 设置服务器的全局配置信息
    # @args.web  on/off 是否启用HTTP/HTTPS协议的转发
    # @args.port 全局端口范围控制
    # @args.user on/off 是否启用客户端管理功能
    def Service_Set_Config(self,args):

        #从数据库中搜索 映射端口
        find = public.M('firewall').where('ps=?', ("FRP服务端默认映射端口",)).field('id,port,ps,addtime').find()
        #判断防火墙中放行的端口列表与用户传入的配置请求是否一致
        if find['port'] != args.port:
            #引入防火墙控制类
            firewalls_object=firewalls.firewalls()
            #删除旧的防火墙端口
            Old = py_object()
            Old.id=find['id']
            Old.port=find['port']
            firewalls_object.DelAcceptPort(Old)
            #开创新的防火墙端口
            New = py_object()
            New.port = args.port
            New.ps = "FRP服务端默认映射端口"
            firewalls_object.AddAcceptPort(New)
        # 写入到全局配置文件
        Server = {"Port": args.port}
        public.WriteFile(self.__plugin_path+"conf/service.json",json.dumps(Server))
        #重启全部服务端
        self.Service_Control_Reload("")
        return {"status": "Success", "msg": "修改全局配置文件成功!"}


    # 获得当前服务端的列表信息
    # @args 空参数
    def Service_List(self,args):
        List=[]
        for file in os.listdir(self.__plugin_path + "conf/json/"):
            if re.match("\S{16}.json", str(file)) and os.path.isfile(self.__plugin_path + "conf/json/" + file):
                #获得服务端ID
                ID = file.split(".")[0]
                # 读取配置文件
                config = json.loads(public.readFile(self.__plugin_path + "conf/json/" + ID + ".json"))
                object = py_object()
                object.ID = ID
                # 获取进程状态
                process = self.Server_Process(object)['Process']
                Server = {"ServerName": config['ServerName'], "Token": config['Token'], "Listen": config['Listen'], "Admin": config['Admin'], "Process": process, "SID": ID}
                List.append(Server)
        return {"status": "Success", "List": List}


    # 启动全部服务端
    # @args 空参数
    def Service_Control_Start(self, args):
        for file in os.listdir(self.__plugin_path + "conf/json/"):
            if re.match("\S{16}.json", str(file)) and os.path.isfile(self.__plugin_path + "conf/json/" + file):
                # 获得服务端ID
                ID = file.split(".")[0]
                object = py_object()
                object.ID = ID
                self.Server_Start(object)
        return {"status": "Success", "msg": "启动全部服务端成功!"}


    # 停止全部服务端
    # @args 空参数
    def Service_Control_Stop(self, args):
        id=""
        for file in os.listdir(self.__plugin_path + "conf/json/"):
            if re.match("\S{16}.json", str(file)) and os.path.isfile(self.__plugin_path + "conf/json/" + file):
                # 获得服务端ID
                ID = file.split(".")[0]
                object = py_object()
                object.ID = ID
                self.Server_Stop(object)
        return {"status": "Success", "msg": "停止全部服务端成功!"}

    # 重启全部服务端
    # @args 空参数
    def Service_Control_Reload(self,args):
        self.Service_Control_Stop("")
        self.Service_Control_Start("")
        return {"status": "Success", "msg": "重启全部服务端成功!"}




    # |   ===================================================
    # |  服务端控制管理函数
    # |   Version:1.0
    # |   Author:Sudem  sang8052@qq.com
    # |   Tips:
    # |        控制服务端的启动、停止，修改服务端的配置信息
    # |   ===================================================

    # 添加新的服务端
    # @args.ServerName 服务端的名称
    # @args.web        是否启用WEB转发功能
    # @args.http       HTTP 协议使用的默认端口
    # @args.https      HTTPS 协议使用的默认端口
    # @args.SubDomain  子域名
    # @args.Access     允许映射的端口列表
    # @args.listen     服务端的通讯端口
    # @args.admin      服务端的控制端口
    # @args.portmax    客户端最大可用端口数量
    # @args.ErrorPage  自定义404 页面路径地址
    def Server_Add(self, args):
        # 检查是否存在端口占用
        WebPort= args.WebPort.split("/")
        web = {}
        web['HttpPort'] = WebPort[0]
        web['HttpsPort'] = WebPort[1]
        port_http = self.PortStatus(web['HttpPort'])
        port_https = self.PortStatus(web['HttpsPort'])
        if port_http['status'] == "used":
            return {"status": "Failed", "msg": "[Error]:"+web['HttpPort']+"端口已经被占用,{" + port_http['pid'] + "}"}
        if port_https['status'] == "used":
            return {"status": "Failed", "msg": "[Error]:"+web['HttpsPort']+"端口已经被占用,{" + port_https['pid'] + "}"}
        # 防火墙放行指定的端口
        port = py_object()
        port.port = web['HttpPort']
        port.ps = "FRPS——HTTP"
        fire = firewalls.firewalls()
        fire.AddAcceptPort(port)
        port.port = web['HttpsPort']
        port.ps = "FRPS-HTTPS"
        fire = firewalls.firewalls()
        fire.AddAcceptPort(port)

        # 生成服务端的连接TOKEN
        TOKEN = "BTFRP_"+public.GetRandomString(16)
        # 加密服务端TOKEN数据 上传插件服务器
        ServerIP = self.Getip("add")
        Listen = args.listen
        UserToken = self.Get_UserToken()
        auth = json.loads(public.ReadFile(self.__plugin_path+"auth.json"))
        UserKey =  auth ['UserKey']
        panel = public.GetHost()+":"+public.GetHost(True)
        # 计算鉴权密钥
        key = public.md5(ServerIP+Listen+TOKEN+panel+UserKey)

        #构造POST请求数据
        post = {"port": Listen, "token": TOKEN, "key": key, "panel": panel,"UserToken": UserToken}
        url = "http://auth.iw3c.top/?api=frps_simple&fun=post"

        try:
            res = requests.post(url,post,verify=False).text
            response = json.loads(res)
        except:
            return {"status": "Failed", "msg": "在与授信服务器 auth.iw3c.top 通信时发生了错误"}
        if response['status'] !="success":
            return {"status": "Failed", "msg": "授信服务器返回了异常数据:" + res['msg']}

        # 生成服务端ID
        ID = public.GetRandomString(16).upper()
        # 生成dashboard 的用户名 密码
        dashboard_user = public.GetRandomString(8)
        dashboard_pass = public.GetRandomString(8)
        #拼接配置文件
        Config = {"ServerName": args.ServerName, "HttpPort": web['HttpPort'], "HttpsPort": web['HttpsPort'], "SubDomain": args.SubDomain, "Access": args.Access,
                  "Listen": args.listen, "Admin": args.admin, "PortMax": args.portmax, "ErrorPage": args.ErrorPage,
                  "Token": TOKEN, "dashboard_user": dashboard_user, "dashboard_pass": dashboard_pass}
        #写入到json 文件夹中
        public.WriteFile(self.__plugin_path+"conf/json/"+ID+".json", json.dumps(Config))
        #创建日志文件目录
        os.mkdir(self.__plugin_path+"logs/"+ID)
        #启动指定的服务器
        server = py_object()
        server.ID = ID
        self.Server_Start(server)
        return {"status": "Success", "msg": "启动服务端: " + args.ServerName + " 成功"}

    #启动指定服务端
    # @args.ID 服务端的本地序列号
    def Server_Start(self, args):
        #判断进程是否需要启动
        if self.Server_Process(args)['Process'] == "dead":
            self.Server_LoadConfig(args)
            public.ExecShell("cd " + self.__plugin_path + " && nohup ./frp_server/frps -c conf/ini/" + args.ID + ".ini &")
        # 判断守护进程是否已经启动
        if not self.ServerKeep_Status():
            self.ServerKeep_Start()
        return {"status": "Success","msg": "启动 服务端 [" + args.ID +"] 成功"}

    # 查询守护进程的运行状态
    def ServerKeep_Status(self):
        lines = os.popen("ps -ef | grep frps_simple_keep.py")
        status = False
        for path in lines:
            colum = path.split()
            if colum[7] == "python":
                status = True
        return status

    # 启动守护进程
    def ServerKeep_Start(self):
        public.ExecShell("cd " + self.__plugin_path + " && nohup python frps_simple_keep.py &")
        return {"status": "Success", "msg": "启动 守护进程 成功："+"cd " + self.__plugin_path + " && python frps_simple_keep.py &"}

    # 杀死守护进程
    def ServerKeep_Stop(self):
        lines = os.popen(' ps -ef | grep frps_simple_keep.py')
        for path in lines:
            colum = path.split()
            pid = colum[1]
            os.popen(" kill " + pid)


    #停止指定的服务端
    # @args.ID 服务端的本地序列号
    def Server_Stop(self, args):

        self.ServerKeep_Stop()
        args.ID = args.ID.strip()
        lines = os.popen(' ps -ef | grep conf/ini/'+ args.ID + '.ini')
        for path in lines:
            colum = path.split()
            pid = colum[1]
            os.popen(" kill " + pid)
        return {"status": "Success", "msg": "停止 服务端 [" + args.ID +  "] 成功 "}


    #重启指定的服务端
    # @args.ID 服务端的本地序列号
    def Server_Reload(self, args):
        self.Server_Stop(args)
        self.Server_Start(args)
        return {"status": "Success", "msg": "重启 服务端 [" + args.ID + "] 成功"}


    #删除指定的服务端
    # @args.ID 服务端的本地序列号
    def Server_Del(self,args):
        #停止指定的服务端
        self.Server_Stop(args)
        config = json.loads(public.readFile(self.__plugin_path + "conf/json/" + args.ID + ".json"))
        # 请求授信服务器 删除数据
        url = "http://auth.iw3c.top/?api=frps_simple&fun=del"
        UserToken = self.Get_UserToken()
        auth = json.loads(public.ReadFile(self.__plugin_path+"auth.json"))
        UserKey = auth['UserKey']
        key = public.md5(self.Getip("add")+config['Token']+UserKey)
        post = {"token": config['Token'], "key": key,"UserToken":UserToken}
        try:
            res = requests.post(url, post, verify=False).text
            response = json.loads(res)
        except:
            return {"status": "Failed", "msg": "在与授信服务器 auth.iw3c.top 通信时发生了错误"}
        if response['status'] != "success":
            return {"status": "Failed", "msg": "在与授信服务器 auth.iw3c.top 通信时发生了错误"}
        else:
            #删除 本地配置文件
            os.popen("rm -rf " + self.__plugin_path + "conf/json/" + args.ID+".json")
            os.popen("rm -rf " + self.__plugin_path + "conf/ini/" + args.ID + ".ini")
            #删除 本地日志文件
            os.popen("rm -rf " + self.__plugin_path + "logs/" + args.ID )
            return {"status": "Success", "msg": "删除 服务端 [" + args.ID +"] 成功"}

    # 读取指定的服务端的配置
    # @args.ID 读取指定的服务端的配置信息
    def Server_ReadConfig(self,args):
        config = json.loads(public.readFile(self.__plugin_path + "conf/json/" + args.ID + ".json"))
        return  {"status": "Success", "config": config}



    #更新指定服务端的配置
    # @args.ID 服务端的本地序列号
    def Server_Update(self,args):
        config = json.loads(public.readFile(self.__plugin_path + "conf/json/" + args.ID + ".json"))
        config['ServerName'] = args.ServerName
        config['Access'] = args.Access
        config['SubDomain'] = args.SubDomain
        config['ErrorPage'] = args.ErrorPage
        config['PortMax'] = args.PortMax
        WebPort = args.WebPort.split("/")
        # 防火墙放行指定的端口
        # 添加新的防火墙端口
        port = py_object()
        port.port = WebPort[0]
        port.ps = "FRPS——HTTP"
        fire = firewalls.firewalls()
        fire.AddAcceptPort(port)
        # 添加新的防火墙端口
        port = py_object()
        port.port = WebPort[1]
        port.ps = "FRPS——HTTPS"
        fire = firewalls.firewalls()
        fire.AddAcceptPort(port)
        config['HttpPort'] = WebPort[0]
        config['HttpsPort'] = WebPort[1]
        public.WriteFile(self.__plugin_path + "conf/json/" + args.ID + ".json", json.dumps(config))
        self.Server_Reload(args)
        return {"status": "Success", "msg": "更新 服务端 [" + args.ID + "] 配置成功"}



    #获取指定服务端的进程状态
    # @args.ID 服务端的本地序列号
    def Server_Process(self,args):
        lines = os.popen('ps -ef | grep ' + args.ID + '.ini')
        Process = 'dead'
        for path in lines:
            colum = path.split()
            if colum[7] == './frp_server/frps':
                Process = 'live'
        return {"status": "Success", "Process": Process}

    # 获得某个服务器的日志信息
    # @args.ID 服务端的本地序列号
    def Server_Logs(self, args):
        alllogs = ""
        last = str(self.getYesterday())
        if os.path.exists(self.__plugin_path + 'logs/' + args.ID + "/frps_"+args.ID+"." + last + '.log'):
            alllogs = public.ReadFile(self.__plugin_path + 'logs/' + args.ID + "/frps_"+args.ID+"." + last + '.log')
        if os.path.exists(self.__plugin_path + 'logs/' + args.ID + "/frps_"+args.ID+'.log'):
            alllogs = alllogs + public.ReadFile(self.__plugin_path + 'logs/' + args.ID + "/frps_"+args.ID+'.log')
        listlogs = alllogs.split("\n")
        lens = len(listlogs)
        start = lens - 101
        logs = ""
        if start < 0:
            start = 0
        while start != (lens - 1):
            logs = logs + listlogs[start] + "\n"
            start = start + 1
        if lens == 0:
            logs = '日志文件不存在'
        return {"status": "Success",'logs': logs}

    #获取指定服务端的运行状态
    # @args.ID 服务端的本地序列号
    def Server_Status(self, args):
        #使用管理端口获得服务端的运行状态信息
        #读取配置信息
        config = json.loads(public.readFile(self.__plugin_path + "conf/json/" + args.ID + ".json"))
        #编码加密后的HttpAuth
        Auth = config['dashboard_user'] + ":" + config['dashboard_pass']
        HttpAuth ="Basic "+base64.b64encode(Auth.encode()).decode()
        Header={"Authorization": HttpAuth}
        url = "http://127.0.0.1:"+config['Admin']+"/api/serverinfo"
        Server=json.loads(requests.get(url,headers=Header).text)
        if config['HttpPort'] == "0":
            Server['vhost_http_port'] = "未开启HTTP 端口转发"
        else:
            Server['vhost_http_port'] = config['HttpPort']
        if config['HttpsPort'] == "0":
            Server['vhost_https_port'] = "未开启HTTPS 端口转发"
        else:
            Server['vhost_https_port'] = config['HttpsPort']
        url = "http://127.0.0.1:" + config['Admin'] + "/api/proxy/tcp"
        tcp = json.loads(requests.get(url,headers=Header).text)
        url = "http://127.0.0.1:" + config['Admin'] + "/api/proxy/udp"
        udp = json.loads(requests.get(url,headers=Header).text)
        url = "http://127.0.0.1:" + config['Admin'] + "/api/proxy/http"
        http = json.loads(requests.get(url,headers=Header).text)
        url = "http://127.0.0.1:" + config['Admin'] + "/api/proxy/https"
        https = json.loads(requests.get(url,headers=Header).text)
        proxy = {"tcp": tcp, "udp" : udp, "http": http, "https": https}
        return  {"status": "Success","Server": Server, "proxy": proxy}

    #载入指定的服务端的配置文件
    # @args.ID 服务端的本地序列号
    def Server_LoadConfig(self, args):
        # 读取全局配置
        ServiceConfig = json.loads(public.readFile(self.__plugin_path + "conf/service.json"))
        #读取配置文件
        config = json.loads(public.readFile(self.__plugin_path+"conf/json/"+args.ID+".json"))

        # | =======================================
        # | 构造配置文件
        # | =======================================

        Initialization = '''
#| ================================
#| 必填配置区域
#| ================================
[common]
bind_addr = 0.0.0.0
#通讯端口
bind_port = %s

#dashboard 功能
#仅用于本地获取服务器的配置信息
dashboard_addr = 0.0.0.0
dashboard_port = %s
dashboard_user = %s
dashboard_pwd = %s

#自定义错误页面
custom_404_page = %s

#token
token= %s

#日志文件
log_file = %s
log_level = info
log_max_days = 3

#| ================================
#| 可选配置区域
#| ================================
'''%(config['Listen'],config['Admin'],config['dashboard_user'],config['dashboard_pass'],self.__plugin_path+config['ErrorPage'],config['Token'],self.__plugin_path+"logs/"+args.ID+"/"+"frps_"+args.ID+".log")
        #| =======================================
        #| 补充写入配置文件功能
        #| =======================================

        # 写入web 转发功能
        Initialization = Initialization + "\n# WEB 转发功能"
        if config['HttpPort'] != "0":
            Initialization = Initialization + "\nvhost_http_port = "+config['HttpPort']
        else:
            Initialization = Initialization + "\n#未开启HTTP转发"
        if config['HttpsPort'] != "0":
            Initialization = Initialization + "\nvhost_https_port = "+config['HttpsPort']
        else:
            Initialization = Initialization + "\n#未开启HTTPS转发"

            #判断是否需要启用 子域名功能
        if config['SubDomain'] !="":
            Initialization = Initialization + '''
# 设置默认子域名
subdomain_host = %s
 ''' % config['SubDomain']

        #判断是否需要限制端口范围
        if config['Access']!="":
            Initialization = Initialization + '''
 # 设置允许转发的端口范围
 allow_ports =  %s
 ''' % config['Access']

        #判断是否需要限制端口数量
        if config['PortMax'] != "0":
            Initialization = Initialization + '''
 # 设置允许转发的端口范围
max_ports_per_client = %s
 ''' % config['PortMax']

        # | =======================================
        # | 构造配置文件结束
        # | =======================================

        #将配置文件写入到 ini 文件夹中
        public.WriteFile(self.__plugin_path+"conf/ini/"+args.ID+".ini",Initialization)
        return {"status": "Success", "msg": "写入 ID:"+args.ID+" 配置文件成功"}


    # |   ===================================================
    # |   拓展功能函数
    # |   Version:1.0
    # |   Author:Sudem  sang8052@qq.com
    # |   Tips:
    # |        一些拓展功能
    # |   ===================================================

    # 检查服务器的 指定 端口是否已经被占用
    # @port 需要检查的端口号
    def PortStatus(self,port):
        import os, re
        for line in os.popen("netstat -tunlp | grep :" + port).read().split("\n"):
            info = line.split(" ")
            if len(info) != 1:
                t = 0
                q = 0
                while (t != 4):
                    if info[q] != "":
                        lport = info[q]
                        t = t + 1
                    q = q + 1
                lport = re.compile(r':\d{1,}').findall(lport)[0].replace(":", "")
                if lport == port :
                    return {"status": "used", "pid": line}
        return {"status": "no used", "pid": ""}

    #获取昨天的日期
    def getYesterday(self):
        today = datetime.date.today()
        oneday = datetime.timedelta(days=1)
        yesterday = today - oneday
        return yesterday


    # 获取本机IP地址的信息
    # @mode add   取得本地服务器的ip地址（公网）
    # @mode local 取得本地服务器的位置信息（根据公网ip）
    def Getip(self, mode):
        url = "http://v2.api.iw3c.top/?api=ip&ip=0.0.0.0"
        res = requests.get(url,verify=False).text
        _data = json.loads(res)
        data = _data['data']
        if mode== "add":
            return data['ip']
        elif mode== "local":
            return data['local'] + "--" + data['isp']


    #计算本机的UserToken
    def Get_UserToken(self):
        lines = os.popen("cd " + self.__plugin_path + " && ./BT_Auth -T ").read()
        lines = lines.split("\n")[0].strip()
        return lines


    # 系统注册 换取 UserToken 票据
    # 请注意 UserToken 票据非常重要 ，这是开启 客户端管理功能 时的加密密钥
    # 如果 服务器的 系统版本和 CPU 型号 以及公网IP地址 发生了变化 UserToken 的值将发生变化
    # TOKENKEY 一串随机字符串 用来辅助加密UserToken
    def Auth_Reg(self):
        osys = system_info()
        System_Version = osys.GetSystemVersion()
        CPU_Model = osys.GetCPUModel()
        CPU_Num = osys.GetCPUNum()
        Mac_Address = public.get_mac_address()
        BT_Version = public.version()
        info = json.loads(public.ReadFile(self.__plugin_path + 'info.json'))
        Plugin_Version = info['versions']
        data = "MAC=" + Mac_Address + "&CPU_Model=" + CPU_Model + "&CPU_Num=" + CPU_Num + "&Sys=" + System_Version + "&BT_Ver=" + BT_Version + "&Plugin_Ver=" + Plugin_Version +"&Type=frps_simple"
        data = base64.b64encode(data.encode()).decode()
        # 执行BT_Auth 进行授权
        os.popen("cd " + self.__plugin_path + " && ./BT_Auth -A " + data)
        #public.WriteFile(self.__plugin_path + 'cmd', "cd " + self.__plugin_path + " && ./BT_Auth -A " + data)
        Server = {"Port": "10000-20000"}
        public.WriteFile(self.__plugin_path + 'conf/service.json', json.dumps(Server))

    #系统授权授信更新
    # Tips: 当用户机器上安装的插件版本,宝塔面板版本发生改变时，为了确保数据安全，更新授权授信数据
    def Auth_Update(self):
        osys = system_info()
        Mac_Address = public.get_mac_address()
        BT_Version = public.version()
        info = json.loads(public.ReadFile(self.__plugin_path + 'info.json'))
        Plugin_Version = info['versions']
        data = "MAC=" + Mac_Address + "&BT=" + BT_Version + "&Plugin=" + Plugin_Version;
        data = base64.b64encode(data.encode()).decode()
        auth = json.loads(public.ReadFile(self.__plugin_path + 'auth.json'))
        # 执行BT_Auth 进行授权
        os.popen("cd " + self.__plugin_path + " && ./BT_Auth -U " + data + " " + auth['UserKey']);



class   system_info:
    def GetSystemVersion(self):
        # 取操作系统版本
        version = public.readFile('/etc/redhat-release')
        if not version:
            version = public.readFile('/etc/issue').strip().split("\n")[0].replace('\\n', '').replace('\l','').strip();
        else:
            version = version.replace('release ', '').strip();
        return version

    def GetCPUModel(self):
        # 取得CPU的型号
        model = os.popen("cat /proc/cpuinfo | grep 'model name' |uniq").readlines()[0]
        model = model.split(":")[1].strip()
        return model

    def GetCPUNum(self):
        num = psutil.cpu_count()
        return str(num)


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session

