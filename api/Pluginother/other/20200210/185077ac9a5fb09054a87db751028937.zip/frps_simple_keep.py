#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: Sudem <mail@szhcloud.cn>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   frp 服务器 管理工具 守护进程
#+--------------------------------------------------------------------

# 因为某些原因： 如 客户端网络条件差,服务器遭到端口扫描 等 可能会导致 frps 进程异常退出
# 本文件为守护进程  脚本将每 10S 一次自动检查 frps 是否正常运行
# 当检查到 frps 异常退出时 会自动重启

# Warning： 请在退出FRPS 时杀死守护进程!!!!!



import sys,os,json,base64,re,datetime,time

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

KeepTime = 10




class frps_simple_keep:
    __plugin_path = "/www/server/panel/plugin/frps_simple/"
    def Process_Watch(self):
        for file in os.listdir(self.__plugin_path + "conf/json/"):
            if re.match("\S{16}.json", str(file)) and os.path.isfile(self.__plugin_path + "conf/json/" + file):
                # 获得服务端ID
                ID = file.split(".")[0]
                if not self.Process_Check(ID):
                    self.Process_Reload(ID)


    # 判断指定的进程是否已经启动
    def Process_Check(self,ID):
        lines = os.popen('ps -ef | grep ' + ID + '.ini')
        Process = False
        for path in lines:
            colum = path.split()
            if colum[7] == './frp_server/frps':
                Process = True
        return Process


    # 重启指定的异常进程
    def Process_Reload(self,ID):
        os.popen("cd " + self.__plugin_path + " && ./frp_server/frps -c conf/ini/" + ID + ".ini &")


if __name__ == '__main__':
    Keep = frps_simple_keep()
    while True:
        Keep.Process_Watch()
        time.sleep(KeepTime)







