#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/frps_simple

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始

    pip install psutil
    pip install requests

	#依赖安装结束
	#==================================================================
     #设置777权限 避免出现因为权限不足导致添加新的服务器无法启动的现象
    sudo -i chmod -R 777 /www/server/panel/plugin/frps_simple/frp_server/ 
	  sudo -i chmod -R 777 /www/server/panel/plugin/frps_simple/BT_Auth
    python frps_simple_main.py
     
	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
