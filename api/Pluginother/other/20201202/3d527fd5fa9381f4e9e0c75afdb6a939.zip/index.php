<?php
//@author 阿修罗<610176732@qq.com>
require 'main.php';
require  'vendor/autoload.php';
require   'sitemap.php';


class bt_main extends main {
    function get_web_list(){
        try {
            $db2 = new SQLite(PLUGIN_DB);
            $list = $db2->getlist("select * from web order by  id desc");
            foreach ($list as &$v){
                $v['status'] =  !empty($v['baidu_api'])?'<span style="color: green">已完善</span>':'<span style="color: red">未完善</span>';
            }
            $this->success('success',$list);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    /**
     * @action  新增网站
     * @Auther 阿修罗<610176732@qq.com>
     * @Date   2020/8/5
     */
    function edit_web(){
        try {
            $param  = _post();
            $db2 = new SQLite(PLUGIN_DB);
            if( empty($param['baidu_api'])  ){
                throw  new Exception('别让我为难,老哥至少填下百度Api撒!');
            }
            $sql = <<<EOF
update  web set path =   "{$param['path']}" ,host =   "{$param['host']}"   ,baidu_api = "{$param['baidu_api']}" ,sm_api =  "{$param['sm_api']}" where id = "{$param['id']}"
EOF;
            $db2->query($sql);
            $this->success('提交成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    function del_web(){
        try {
            $param  = _post();
            $db2 = new SQLite(PLUGIN_DB);
            $sql = <<<EOF
delete from web where id = "{$param['id']}"
EOF;
            $db2->query($sql);
            $this->success('删除成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    /**
     * @action 同步数据
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/5
     */
    function sync_data(){
        $db = new SQLite(MAIN_DB);
        $web_list = $db->getlist('select * from sites');
        $db2 = new SQLite(PLUGIN_DB);
        foreach ($web_list as $v){
            $res = $db2->RecordCount("select * from web where host =  '{$v['name']}'  ");
            if($res == 0){
                $db2->query("insert into web (host,type,path) values('{$v['name']}','内部服务器','{$v['path']}') ");
            }
        }
        $this->success('success');
    }
    
    /**
     * @action 关于
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/5
     */
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function get_wc(){
        $db2 = new SQLite(PLUGIN_DB);
        $list = $db2->getlist("select * from web     order by  id desc");
        foreach ($list as &$v){
            $v['status'] =  !empty($v['baidu_api'])?'<span style="color: green">已完善</span>':'<span style="color: red">未完善</span>';
        }
        $this->success('success',$list);
    }
	function man_push(){
	    try{
            $param =  _post();
            $config  = $this->get_config($param['host']);
            $urls = $this->getUrls($param['protocol'],$param['host']);
            if($param['way'] == 2){
                $urls = $this->getUrls($param['protocol'],$param['host'],2);
            }
            $content = "";
            $sitemap_url = $param['protocol'].$param['host'].DS."sitemap.xml";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.=  "<p>sitemap.xml保存至地址:<a target='_blank' class='btlink' href='{$sitemap_url}'>".$sitemap_url."</a></p>";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.= "<p>共计生成".count($urls)."条链接如下:</p>";
            foreach ($urls as $url){
                $content.=  "<p >".$url."</p>";
            }
            $this->save_sitemap($param['host'],$urls);
            $this->success('success',[
                'urls'=>$urls,
                'content'=>$content,
                'sitemap_url'=>$param['protocol'].$param['host'].DS.'sitemap.xml',
            ]);
        }catch (\Exception $e){
	       $this->error($e->getMessage()."<br>发生错误可能原因:<br>1.爬取该域名时可能因为防火墙限制,<br>2.协议或权限限制(比如启用了强制https或加密等),<br>3.域名本身不存在或不可访问等原因 ");
        }
    }
    function active_push(){
        try {
            $param =  _post();
            $site =  $param['protocol'].$param['host'].DS.'sitemap.xml';
            $urls = $this->switchXml2arr($site);
            if(!$urls){
                throw  new Exception('读取sitemap.xml失败');
            }
             $msg = $this->fenPush($param['host'],$urls);
            $this->success($msg);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    public  function get_log(){
        try{
            $sql =  "select * from  log order by id desc";
            $list =  $this->db->getlist($sql);
            $this->success('success',[
                'content'=>$list
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function getPath(){
        if(PHP_OS == 'Linux'){
            $php_path = PLU_PATH."/../../../php/71/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/71/php.exe";
        }
        
        $this->json([
            'path'=>$this->ds_file,
            'dir'=> PLU_PATH,
            'php_path'=>$php_path
        ]);
    }
    public function check_os(){
        if(PHP_OS == 'Linux'){
            $this->success('success',[
                'os'=>'linux'
            ]);
        }else{
            $this->success('success',[
                'os'=>'windows'
            ]);
        }
    }
    
    /**
     * @action 清除日志
     * @Auther 阿修罗 <QQ 610176732>
     * @Date   2020/9/12
     */
    public function rmlog(){
        $db2 = new SQLite(PLUGIN_DB);
        $db2->query("delete  from log");
        $this->success('已清空日志');
    }
    public function backup(){
        @unlink('/tmp/web.db');
        copy(__DIR__.'/web.db','/tmp/web.db');
        $this->success('备份成功');
    }
    public  function recover(){
        copy('/tmp/web.db',__DIR__.'/web.db');
        $this->success('配置恢复成功');
    }
}


?>