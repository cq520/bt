<?php
//@author 阿修罗<610176732@qq.com>
require 'vendor/autoload.php';
require 'sitemap.php';
require 'main.php';

use QL\QueryList;
use QL\Ext\AbsoluteUrl;

class console extends  main {
    public $chunk;
    public function  __construct($host,$sitemap,$dir,$protocol,$level){
        parent::__construct();
        echo '当前PHP版本:'.PHP_VERSION;
        echo "\n本插件仅支持PHP7.1.x哦!如果不一致,请设置下PHP-CLI命令行版本,linux版在[网站]-[PHP命令行版本]中设置\n";
        define("PLUGIN_DB",$dir."/web.db");
        define('PLU_NAME', 'sitemap');
        define('DS', '/');
        $this->chunk = 2000;
        $this->init($host,$protocol,$level);
    }
    
    function init($host,$protocol,$level){
        //获取链接保存
        $urls =  $this->getUrls($protocol,$host,$level);
        $this->save_sitemap($host,$urls);
        $this->fenPush($host,$urls);
    }
    /**
     * @action 保存sitemap
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function save_sitemap($host, $urls)
    {
        $config = $this->get_config($host);
        $map = new Sitemap();
        $urls = array_unique($urls);
        $txt = "";
        foreach ($urls as $v) {
            $v = $this->dlamp($v);
            $txt .= $v . "\n";
            $map->AddItem($v, 1);
        }
        $map->SaveToFile($config['path'] .  '/sitemap.xml');
        //判断public目录
        if (is_dir($config['path'] . DS . "/public")) {
            $map->SaveToFile($config['path'] . DS . 'public/sitemap.xml');
        }
        //判断web目录
        if (is_dir($config['path'] . DS . "/web")) {
            $map->SaveToFile($config['path'] . DS . 'web/sitemap.xml');
        }
        echo  "\n-------------------------------------";
        echo "\n sitemap.xml保存地址:".$config['path'] . DS . "sitemap.xml ";
    }
    function get_config($host)
    {
        $db = new SQLite(PLUGIN_DB);
        $config = $db->query("select * from web where host   =  '{$host}' ")->fetch();
        return $config;
    }
    function baidu_push($host, $urls)
    {
        $config_json = $this->get_config($host);
        $api = $config_json['baidu_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch), true);
    }
    
    function sm_push($host, $urls)
    {
        $config_json = $this->get_config($host);
        $api = $config_json['sm_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return json_decode($result, true);
    }
    function fenPush($host, $urls)
    {
        $urls = array_unique($urls);
        if (empty($urls)) {
            echo "\n插件警告:1.推送的链接全部为重复网址或者过滤后无有效网址\n";
        }
        $chunk = $this->chunk;
        $msg = '';
        if (count($urls) > $chunk) {
            $msg .= '推送总数:' . count($urls);
            $url_chunk = array_chunk($urls, $chunk);
            $i = 0;
            foreach ($url_chunk as $value) {
                $i++;
                $msg .= "\n-------------网址数量大于" . $chunk . ",自动启用分批推送,每批" . $chunk . "条,当前第" . $i . "批--------------" . $this->push_all($host, $value, true);
            }
        } else {
            $msg = $this->push_all($host, $urls);
        }
        if(preg_match('/成功/',$msg)){
            $msg .= "\n--------------------------------------";
            $msg .= "\n成功推送网址列表:";
            foreach ($urls as $url) {
                $msg .= "\n" . $url;
            }
        }
        echo "\n--------------------------------------";
        echo $msg;
        echo "\n--------------------------------------";
    }
    
    function push_all($host, $urls){
        $host_config  = $this->get_config($host);
        if(  empty( $host_config['baidu_api'] )  && empty($host_config['sm_api'])  ){
            echo '至少开启一个推送类型';exit;
        }
        //百度主动推送
        $msg = '';
        $str = '';
        if( !empty($host_config['baidu_api']) ){
            $res =  $this->baidu_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success'])){
                @$msg .= "\n".'百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条';
                @$str .= '<p class="bt-text">百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</p>';
            }else{
                $warn =  isset($res['message'])?$res['message']:'';
                if($warn == 'token is not valid'){
                    $warn = "百度API填写错了,别这么粗心哦!请仔细检查下";
                }
                $msg .= "\n".'百度普通收录推送失败:'.$warn;
                $str .= '<br><p class="bt-text-danger">百度普通收录推送失败:'.$warn.'</p>';
            }
        }
        
        
        //神马推送
        if( !empty($host_config['sm_api']) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres['returnCode']==200){
                $msg .= "\n神马mip推送成功:".count($urls)."条(神马官方不提供额度返回)";
                $str .= '<p class="bt-text">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</p>';
            }else{
                $msg .= "神马mip推送失败:配置错误,".(isset($smres['returnCode'])?$smres['returnCode']:'');
                $str .= '<p class="bt-text-danger">神马mip推送失败:配置错误,'.(isset($smres['returnCode'])?$smres['returnCode']:'')."</p>";
            }
        }
        
        $this->record_log($str,$host);
        

        return $msg;
    }
    function  record_log($msg,$host,$type = "定时推送"){
        $create_time = date('Y-m-d H:i:s',time());
        $this->db->query("insert into `log` (msg,host,type,create_time) values('{$msg}','{$host}','{$type}','{$create_time}')  ");
    }
    /**
     * @action 方法作用
     * @param $urlx   域名
     * @param string $protocol 协议
     * @param int $level 层级
     * @return array
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function getUrls($protocol = 'http://', $urlx, $level = 1)
    {
        $url = $protocol . $urlx . '/';
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
        $urlsa = $ql->get($url)
            ->absoluteUrl($url)
            ->find('a')
            ->attrs('href')
            ->all();
        //过滤
        $urls = [];
        foreach ($urlsa as $key => $v) {
            if (preg_match("/" . $urlx . "/", $v)) {
                $urls[] = $v;
            }
        }
        if ($level == 2) {
            $arr = [];
            foreach ($urls as $v) {
                $ql = QueryList::getInstance();
                $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                $urlsb = $ql->get($v)
                    ->absoluteUrl($v)
                    ->find('a')
                    ->attrs('href')
                    ->all();
                //过滤
                $ax = [];
                foreach ($urlsb as $key => $v) {
                    if (preg_match("/" . $urlx . "/", $v)) {
                        $ax[] = $v;
                    }
                }
                foreach ($ax as $vx) {
                    $arr[] = $vx;
                }
            }
            return array_unique($arr);
        }
        return array_unique($urls);
    }
    
    
    

}

//初始化类
echo "开始执行:\n";
$param = $param_arr = getopt("a:b:c:d:e:");
$console = new console($param["a"],$param["b"],$param["c"],$param['d'],$param['e']);