<?php

#coding: utf-8
# +-------------------------------------------------------------------
# | 百度云加速 v1.03
# +-------------------------------------------------------------------
# | Copyright (c) 2019-2020 趣域商务(http://66web.com) All rights reserved.
# +-------------------------------------------------------------------
# | 本插件由趣域网开发及维护，遇到相关问题可以向趣域商务反馈
# +-------------------------------------------------------------------
# | Author: 趣域商务 <support@66web.com>
#+--------------------------------------------------------------------



//api_key
$OPENAPI_BASE_URL = "";  
$ACCESS_KEY = "";
$SECRET_KEY = "";
$SIGN_METHOD = "";
function header_api_key($api_key_status,$ACCESS_KEY="",$SECRET_KEY="",$quyu_account="",$quyu_password=""){
    if($api_key_status=="quyu"){
       $GLOBALS['OPENAPI_BASE_URL']= "quyu";
       $GLOBALS['ACCESS_KEY']= $quyu_account;
       $GLOBALS['SECRET_KEY']= $quyu_password;
       $GLOBALS['SIGN_METHOD']= "HMAC-SHA1";
    }else if($api_key_status=="self"){
       $GLOBALS['OPENAPI_BASE_URL']= "api.su.baidu.com/";
       $GLOBALS['ACCESS_KEY']= $ACCESS_KEY;
       $GLOBALS['SECRET_KEY']= $SECRET_KEY;
       $GLOBALS['SIGN_METHOD']= "HMAC-SHA1";
    }
}
//设置全局zone_id
function get_zone_id($zone_id=""){
    $GLOBALS['zone_id']= $zone_id; 
}




// 排序并拼接参数
function getParsedAllParams($paramMap)
{
    ksort($paramMap);
    $paramSortedArray = array();
    
    foreach ($paramMap as $k => $v) {
        if (is_bool($v)) {
            if ($v) {
                $v = 'true';
            } else {
                $v = 'false';
            }
        }
        
        //新加
        if(is_array($v)){
            $v= str_replace(array(":",","),array(": ",", "),json_encode($v));
            
        }
        
        array_push($paramSortedArray, $k . "=" . $v);
    }
	$params = join("&",$paramSortedArray);		//兼容php7.4
    return $params;
}

// 获取签名
function getSignature($str, $key)
{
    $signature = "";
    if (function_exists('hash_hmac')) {
        $signature = base64_encode(hash_hmac("sha1", $str, $key, true));
    } else {
        $blocksize = 64;
        $hashfunc = 'sha1';
        if (strlen($key) > $blocksize) {
            $key = pack('H*', $hashfunc($key));
        }
        $key = str_pad($key, $blocksize, chr(0x00));
        $ipad = str_repeat(chr(0x36), $blocksize);
        $opad = str_repeat(chr(0x5c), $blocksize);
        $hmac = pack('H*', $hashfunc(($key ^ $opad) . pack('H*', $hashfunc(($key ^ $ipad) . $str))));
        $signature = base64_encode($hmac);
    }
    return $signature;
}

// 生成请求头
function getRequestHeader($path, $request)
{   
    $request=del_array($request);//tan,防止参数为空出错

    $authTimestamp = time();
    $commonParamsMap = array(
        "X-Auth-Access-Key" => $GLOBALS['ACCESS_KEY'],
        "X-Auth-Nonce" => $authTimestamp,
        "X-Auth-Path-Info" => $path,
        "X-Auth-Signature-Method" => $GLOBALS['SIGN_METHOD'],
        "X-Auth-Timestamp" => $authTimestamp
    );
    $allParamsMap = array();
    $headersMap = array();
    $headersMap = array_merge($commonParamsMap);
    $allParamsMap = array_merge($commonParamsMap, $request);
    $allParamsStr = getParsedAllParams($allParamsMap);
    $sign = getSignature($allParamsStr, $GLOBALS['SECRET_KEY']);
    $headersMap['X-Auth-Sign'] = $sign;
    $Headers = array();
    
    foreach ($headersMap as $k => $v) {
        array_push($Headers, $k . ": " . $v);
    }

    return $Headers;
}

// 发送http请求 
function request($method, $path, $request=array(), $Headers,$domain="",$classType="")
{   
    
    //最后合并新加:1.需要全部方法都传$domain 2.request()方法判断。
    if($GLOBALS['OPENAPI_BASE_URL']== "quyu"){
        $bt_data=array(
            "email"=>$GLOBALS['ACCESS_KEY']      
            ,"password"=>$GLOBALS['SECRET_KEY'] 
            ,"domain"=>$domain
            ,"method"=>$method
            ,"path"=>$path
            ,"request"=>$request
            ,"classType"=>$classType
        );
 
       //var_dump(SendDataByCurl("http://www.66web.com/api/cdn",$bt_data));
       //var_dump(SendDataByCurl("http://test2017.quyu.net/api/cdn",$bt_data));
//      return SendDataByCurl("http://test2017.quyu.net/api/cdn",$bt_data);
        return SendDataByCurl("http://www.66web.com/api/cdn",$bt_data);     
    }



    $request=del_array($request);   //tan,防止参数为空出错

    $curl = curl_init();
    $url = $GLOBALS['OPENAPI_BASE_URL'] . $path;

    if ($method == "GET") {
        $getString = getParsedAllParams($request);
        $url = $url . "?" . $getString;
    }

    $setoptArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "UTF-8",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $Headers
    );
      
    if ($method != "GET" && !empty($request)) {
        $setoptArray[CURLOPT_POSTFIELDS] = json_encode($request);
    }
           
    curl_setopt_array($curl, $setoptArray);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    if ($err) {
        return "cURL Error #:" . $err;
    } else {
       
        $response = Message($response);
        return $response;
    }
}

//分配域名(暂时没有该API)
function Distribute($domain, $bid)
{
    $response = GetZoneInfo($domain);
    $zid = trim($response[result][id]);
    $path = "v31/yjs/link_zones";
    $request = array(
        'zone_id' => $zid,                          //域名的标识
        'auth_code' => $bid,                        //云加速的用户识别码
    );
    $Headers = getRequestHeader($path, $request);   //请求头
    $json_data = request('POST', $path, $request, $Headers,$domain);
    
    return json_decode($json_data, true);
}
//查询域名,域名ID
function GetZoneInfo($domain="",$id="",$page=1,$per_page=999)
{   
    $path = "v31/yjs/zones";
    $bodyParams = array();
    $request = array(
        'name' => $domain       
        ,'page' => $page       
        ,'per_page' => $per_page      
    );
    $Headers = getRequestHeader($path, $request);   

    //最后合并新加:查全部子域名就加allDomain。查id或者单个就为空
    if(empty($domain)){
      $json_data = request("GET", $path, $request, $Headers,$domain,'allDomain'); 
      return json_decode($json_data, true);
    }
    //获取全局zone_id
    if($id=="id"){
      if(!empty($GLOBALS['zone_id'])){
       return $GLOBALS['zone_id'];  
      }  
    }
    if(!empty($domain)){
      $json_data = request("GET", $path, $request, $Headers,$domain,'');
      return json_decode($json_data, true);
    }
    
    
    //旧版:api获取id
    if(!empty($id)){
        $json_data=json_decode($json_data, true);
        $id = trim($json_data['result']['id']); 
        return $id;
    }

    return json_decode($json_data, true);
}

//添加域名
function AddZone($domain, $type = "cname")
{
    $path = "v31/yjs/zones";
    $request = array(
        'name' => $domain,          //域名
        'type' => $type             //添加方式
    );
    // 海外版
    // if($type=="overseas"){
    //   $request = array(
    //     'name' => $domain,          
    //     'type' => 'cname',          
    //     'label' => 'overseas'
    //   );  
    // }
    $Headers = getRequestHeader($path, $request);   
    $json_data = request('POST', $path, $request, $Headers,$domain,"createZone");
    
    return json_decode($json_data, true);
}
//删除域名
function DeleteZone($id,$domain="")
{
    $path = "v31/yjs/zones/".$id;
    $request = array();
    $Headers = getRequestHeader($path, $request);   
    $json_data = request('DELETE', $path, $request, $Headers,$domain);
    
    return json_decode($json_data, true);
}
//续费或修改域名
function UpdateZone($domain, $paused, $plan)
{
    $response = GetZoneInfo($domain);
    $id = trim($response[result][id]);
    $path = "v31/yjs/zones/".$id;
    $request = array(
        'paused' => $paused                         //string 可选 回源或非回源，true:访问回源，false：正常访问
    );
    if(!empty($plan)){
        $request['plan_bd'] = $plan;                //string 可选 域名所属的套餐版本，套餐：free:免费版，pro:专业版，bus:商务版，ent:企业版
    }
    $Headers = getRequestHeader($path, $request);   //请求头
    return request('PATCH', $path, $request, $Headers,$domain);
}
function crssl()
{
    $path = "v3/yjs/zones/ssl";
    $domain = "*.hk.xxx.com";
    //$bizParamsMap['type'] = "ns";
    $request = array(
        'domain' => $domain,                        //string 可选 网站域名，例如： example.com
        'status' => 'enable',                       //string 可选 域名状态，例如： enable => 开启，disable => 关闭
    );
    $Headers = getRequestHeader($path, $request);   //请求头
    request('PATCH', $path, $request, $Headers,$domain);
}







//以下tan开始:
//一.网站接入
//子域名集合   
//1.$name:www.xxx.com
//2.$isp_uuid参数是:0默认,2电信,4联通,6移动,12海外。 $ttl:1是自动
function dns_records($domain,$status,$name="",$type="",$content="",$ttl="",$isp_uuid="",$proxied="",$priority="")
{   
    //$proxied false不行。true可以
    if($proxied=="true"){
        $proxied=true;
    }else if($proxied=="false"){ 
        $proxied=false;
    }
    $ttl=intval($ttl);
    $priority=intval($priority);
 
    $id = GetZoneInfo($domain,"id");     
    if($status=="post"){            
        $path = "v31/yjs/zones/".$id."/dns_records";
        $method="POST";
        $request = array(
            'name' => $name  
            ,'type' => $type  
            ,'content' => $content  
            ,'ttl' => $ttl  
            ,'isp_uuid' => $isp_uuid       
            ,'priority' => $priority
        );
    }else if($status=="delete"){      
        $del_id = $type;               
        $method="DELETE";  
        $path = "v31/yjs/zones/".$id."/dns_records/".$del_id;
        $request = array();
    }else if($status=="get"){         
        $method="GET";
        $path = "v31/yjs/zones/".$id."/dns_records";
        $request = array(
            'name' => $name   
        ); 
    
    }else if($status=="patch"){
        $del_id = $type;              
        $method="PATCH";
        $path = "v31/yjs/zones/".$id."/dns_records/".$del_id;
        $request = array(
            'content' => $content  
            ,'ttl' => $ttl 
            ,'proxied' => $proxied 
            ,'isp_uuid' => $isp_uuid       
            ,'priority' => $priority    
        );
    }
    $Headers = getRequestHeader($path, $request);   
    $json_data = request($method, $path, $request, $Headers,$domain,'dns_records');
    return json_decode($json_data, true);
}
//子域名 旧版更改
function dns_records_patch($domain,$status,$name="",$type="",$content="",$ttl="",$isp_uuid="",$proxied="",$priority="",$content_old="",$isp_uuid_old="")//priority:MX优先级
{   
           
   $ttl=intval($ttl);

   $name = str_replace(".".$domain,'',$name); //原版
   if($isp_uuid=="0"){ $isp_uuid='default';  }  
   if($isp_uuid=="2"){ $isp_uuid='telecom';}
   if($isp_uuid=="4"){ $isp_uuid='unicom';}
   if($isp_uuid=="6"){ $isp_uuid='cmcc'; }
   if($isp_uuid=="12"){ $isp_uuid='default';} //海外旧版出错。看是提示先改状态为开启
   
   if($isp_uuid_old=="0"){ $isp_uuid_old='default';}  
   if($isp_uuid_old=="2"){ $isp_uuid_old='telecom';}
   if($isp_uuid_old=="4"){ $isp_uuid_old='unicom';}
   if($isp_uuid_old=="6"){ $isp_uuid_old='cmcc'; }
   if($isp_uuid_old=="12"){ $isp_uuid_old='default';}

   $post_request = array(
        'domain' => $domain,                 //域名   
        'subdomain' => $name,                //子域名
        'content' => $content_old,           //指向
        'isp_uuid' => $isp_uuid_old,         //线路 
        'new_content' => $content,
        'new_isp_uuid' => $isp_uuid,
        'new_ttl' => $ttl,                   
        'new_proxied' => 0,                  //状态
   );
   
   //curl
   if($GLOBALS['OPENAPI_BASE_URL']== "quyu"){
        $bt_data=array(
            "email"=>$GLOBALS['ACCESS_KEY']      
            ,"password"=>$GLOBALS['SECRET_KEY'] 
            ,"domain"=>$domain
            ,"method"=>$method
            ,"path"=>$path
            ,"request"=>$post_request
            ,"classType"=>'dns_records_patch'
        );
        $json_data = SendDataByCurl("http://www.66web.com/api/cdn",$bt_data);
        return json_decode($json_data, true);
   }
   
   $json_data = ModifyZone($post_request);   
   return json_decode($json_data, true);
}




//二.通用配置
//缓存设置     CDN加速--缓存粒度设置
function cache_level($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/cache_level";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   //请求头
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(cache_level("xxx.com","simplified"));exit;

//清除缓存    CDN加速--全部缓存刷新可以。多文件缓存刷新参数不行
function purge_cache($domain,$purge_everything="",$files="")
{   
    if($purge_everything=="true"){
        $purge_everything=true;
    }else if($purge_everything=="false"){ 
        $purge_everything=false;
    }
    
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/purge_cache";
    $bodyParams = array();
    $request = array(
        'purge_everything' => $purge_everything       
        ,'files' => $files    
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("DELETE", $path, $request, $Headers,$domain,'purge_cache');
    return json_decode($json_data, true);
}
//var_dump(purge_cache("xxx.com",true));exit;

//设置浏览器缓存有效期  
function browser_cache_ttl($domain,$value)
{   
    $value=intval($value);
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/browser_cache_ttl";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain,'browser_cache_ttl');
    return json_decode($json_data, true);
}
// var_dump(browser_cache_ttl("xxx.com",10800));exit;

//设置图片快速加载(专业版及以上) 
function mirage($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/mirage";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   //请求头
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(mirage("xxx.com","on"));exit;

//设置图片压缩(专业版及以上)     CDN加速--图片自动压缩
//$value : lossless => 无损压缩lossy => 有损压缩off => 关闭
function polish($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/polish";
    $bodyParams = array();
    $request = array(
        'value' => $value        
    );
    $Headers = getRequestHeader($path, $request);  
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(polish("xxx.com","off"));exit;

//节点缓存有效期设置 
function edge_cache_ttl($domain,$value)
{   
    $value=intval($value);
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/edge_cache_ttl";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain,'edge_cache_ttl');
    return json_decode($json_data, true);
}
//var_dump(edge_cache_ttl("xxx.com",10800));exit;

//设置开启ipv6   
function ipv6($domain,$value="")
{   
    if(empty($value)){
        $method="GET";
    }else{
        $method="PATCH";
    }
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/ipv6";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);  
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(ipv6("xxx.com"));exit;       //GET查询     
// var_dump(ipv6("xxx.com","off"));exit; //PATCH更改



//三.WAF相关配置
//设置防盗链      
function hotlink_protection($domain,$value=[])
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/hotlink_protection";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//WAF开关     Web应用防火墙
function waf($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/waf";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(waf("xxx.com","on"));exit;

//WAF黑白名单集合(专业版+)      安全功能--IP防火墙   
function firewall($domain,$operation="",$value="",$del_id="")
{    
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/firewall";
    $bodyParams = array();
    $request = array(
        'value' => $value       
        ,'operation' => $operation
        ,'type' => 'ip'                 
    );
    if($operation=="block"){            //WAF黑名单
        $method="POST";
    }elseif($operation=="whitelist"){   //WAF白名单
        $method="POST";
    }elseif($operation=="get"){         //查询WAF黑白名单
        $request = array();
        $method="GET";
    }elseif($operation=="delete"){      //删除WAF黑白名单
        $request = array();
        $method="DELETE";
        $path = "v31/yjs/zones/".$id."/firewall/".$del_id;
    }elseif($operation=="challenge"){   //WAF强力防护名单
        $method="POST";
    }
    $Headers = getRequestHeader($path, $request);  
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(firewall("xxx.com","block","134.175.46.22"));exit;
// var_dump(firewall("xxx.com","whitelist","134.175.46.22"));exit;
// var_dump(firewall("xxx.com","get"));exit;
// var_dump(firewall("xxx.com","delete","","5f3500fe6472de40d972f785"));exit;
// var_dump(firewall("xxx.com","challenge","134.175.46.22"));exit;

//CC防护  
function security_level($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/security_level";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   //请求头
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(security_level("xxx.com","high"));exit;

//设置邮件混淆   邮件地址混淆
function email_obfuscation($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/email_obfuscation";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(email_obfuscation("xxx.com","on"));exit;

//设置浏览器检查(专业版+)
function browser_check($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/browser_check";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);  
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(browser_check("xxx.com","on"));exit;



//四.安全防护相关配置
//URL黑名单(商务部+)     xxx  //ADS--URL黑名单
function security_url($domain,$method,$url)
{   
    $id = GetZoneInfo($domain,"id");
    $method=$method;
    $path = "v31/yjs/zones/".$id."/security_url";
    $bodyParams = array();
    $request = array(
        'url' => $url       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}

//禁止海外用户(商务部+)  xxx  //ADS--海外IP防护
function security_boip($domain,$method,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/security_boip";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}

//海外IP限速(商务部+)   xxx
function security_speed($domain,$method,$value,$user_qps)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/security_speed";
    $bodyParams = array();
    $request = array(
        'value' => $value       
        ,'user_qps' => $user_qps       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(security_speed("xxx.com","PATCH","on",10));exit;

//回源限速     安全功能--ADS--源站保护
function security_source_speed($domain,$value="",$user_qps="")
{   
    if(empty($value)){
        $method="GET";
    }else{
        $method="PATCH";
    }
    $user_qps=intval($user_qps);
    
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/security_source_speed";
    $bodyParams = array();
    $request = array(
        'value' => $value       
        ,'user_qps' => $user_qps       
    );
    $Headers = getRequestHeader($path, $request);            
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(security_source_speed("xxx.com"));exit;           //查询
// var_dump(security_source_speed("xxx.com","on",10000));exit;//开启,修改次数
// var_dump(security_source_speed("xxx.com","off",""));exit;  //关闭



//四.SEO
//新站报到和收录黑名单（专业版及以上）     流量功能--引擎收录加速
function seo_settings($domain,$status="",$value="",$data=[])
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/seo_settings";
    if(empty($status)){
        $method="GET";                       
        $request = array();
    }else{
        $method="PATCH";
    }

    if($status=="newsite_switch"){          //新站报到
        $request = array(
            'newsite_switch' => $value     
        );
    }elseif($status=="black_switch"){       //收录黑名单 
        $request = array(   
            'black_switch' => $value        
        );
        if(empty($value)){
          $request = array(   
            'black_list' => $data   
          ); 
        }
    }elseif($status=="update_switch"){      //更新通知 
        $request = array(
            'update_switch' => $value    
        );
        if(empty($value)){
          $request = array(   
            'update_list' => $data   
          ); 
        }
    }elseif($status=="redesign_switch"){   //改版通知
        $request = array(
            'redesign_switch' => $value    
        );
        if(empty($value)){
          $request = array(   
            'redesign_list' => $data   
          ); 
        }
    }

    $bodyParams = array();
    $Headers = getRequestHeader($path, $request); 
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(seo_settings("xxx.com"));exit;
// var_dump(seo_settings("xxx.com","newsite_switch","on"));exit;
// var_dump(seo_settings("xxx.com","black_switch","on"));exit;   
// var_dump(seo_settings("xxx.com","update_switch","on"));exit;   
// var_dump(seo_settings("xxx.com","redesign_switch","on"));exit;   


//七.证书相关
//证书申请-专有证书申请  
function cert_orders($domain,$cn,$dv_auth_method,$auto="")
{   
    $auto = intval($auto);

    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/cert_orders";
    $bodyParams = array();
    $request = array(
        'cn' => $cn 
        ,'dv_auth_method' => $dv_auth_method 
        ,'auto' => $auto 
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("POST", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(cert_orders("xxx.com","www.xxx.com","FILE",1));exit;

//证书申请-专有证书总查询,查询单个和取消       
function orders($domain,$orders_id="",$status="")
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/cert_orders";  
    $method = "GET";
    $bodyParams = array();
    $request = array(
        'domain'=>$domain
    );

    if($status=="get"){
        $method = "GET";
        $path = "v31/yjs/zones/".$id."/cert_orders/".$orders_id;
        $request = array();
    }else if($status=="delete"){
        $method = "DELETE";
        $path = "v31/yjs/zones/".$id."/cert_orders/".$orders_id;
        $request = array();
    }

    $Headers = getRequestHeader($path, $request);   
    $json_data = request($method, $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(orders("xxx.com"));exit;                                  //总查询
//var_dump(orders("xxx.com","5f4385ad645542ed3a2e5214","get"));exit; //查单个

//证书列表-证书查询   ddd
function custom_certificates_get($domain)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/custom_certificates";
    $bodyParams = array();
    $request = array();
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("GET", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(custom_certificates_get("xxx.com"));exit;

//证书列表-证书部署   ddd  
function custom_certificates_patch($domain,$switch,$custom_certificates_id)
{   
    //$switch 0字符串类型!!!,1是int类型!!
    if($switch==0){
       $switch="0";
    }else if($switch==1){
       $switch=1; 
    }

    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/custom_certificates/".$custom_certificates_id;
    $bodyParams = array();
    $request = array(
        'switch' => $switch
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain,'custom_certificates_patch');
    return json_decode($json_data, true);
}
// var_dump(custom_certificates_patch("xxx.com","0","5f477094b6d9c1af02f3581b"));exit;
// var_dump(custom_certificates_patch("xxx.com",1,"5f477094b6d9c1af02f3581b"));exit;

//证书列表-详情--修改证书名   ddd
function custom_certificates_details($domain,$info,$custom_certificates_id)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/custom_certificates/".$custom_certificates_id;
    $bodyParams = array();
    $request = array(
        'info' => $info
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(custom_certificates_details("xxx.com","ddd","5f47732d9c1af02f35123"));exit;

//证书列表-证书上传  ddd
function custom_certificates_post($domain,$info,$certificate,$private_key)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/custom_certificates";
    $bodyParams = array();
    $request = array(
        'domain' => $domain 
        ,'info' => $info 
        ,'certificate' => $certificate 
        ,'private_key' => $private_key 
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("POST", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(custom_certificates_post("xxx.com","xxx.nettest","sss","sss"));exit;

//证书列表-证书删除   需要专业版,还没测试
function custom_certificates_delete($domain,$info)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/custom_certificates";
    $bodyParams = array();
    $request = array(
        'domain' => $domain 
        ,'info' => $info 
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("DELETE", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}

//证书列表-证书下载     xxxx        //api错误,response an error:msg:Incorrect Parent Resource:code:10013
function custom_certificates_download($orders_id,$keystorepwd="",$type="")
{   
    $path = "v31/yjs/zones/cert_download";
    $bodyParams = array();
    $request = array(
        'id' => "5dd0a669d97c45d397ab633a"
        ,'keystorepwd' => "MzEzMjMz" 
        ,'type' => "PEM_Privatekey"
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("GET", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(custom_certificates_download("5dd0a6612321333a","MzEzMjMz","PEM_Privatekey"));exit;





//九.文档没有的
//查询安全功能等状态    
function settings($domain)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings";
    $bodyParams = array();
    $request = array();
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("GET", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(settings("xxx.com"));exit;

//ns,cname解析未生效,重新验证和改变添加流程wizard状态    
function record_check($status,$domain)
{   
    $id = GetZoneInfo($domain,"id");
    if($status=="ns"){
        $path = "v31/yjs/zones/".$id."/ns_record_check";
    }elseif($status=="cname"){
        $path = "v31/yjs/zones/".$id."/txt_record_check";
    }
    $bodyParams = array();
    $request = array();
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PUT", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(record_check("ns","xxx.com"));exit;

//安全功能:WAF--安全验证有效期
function challenge_ttl($domain,$value)
{   
    $value=intval($value);
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/challenge_ttl";
    $bodyParams = array();
    $request = array(
        'value' => $value       
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain,'challenge_ttl');
    return json_decode($json_data, true);
}
// var_dump(challenge_ttl("xxx.com",10800));exit();

//安全功能:HTTPS加速
//$value = 严格加密:strict,全程加密:full,半程加密:flexible,关闭:off
function settings_ssl($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/ssl";
    $bodyParams = array();
    $request = array(
        'value' => $value   
    );
    $Headers = getRequestHeader($path, $request);   //请求头
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
//var_dump(settings_ssl("xxx.com","off"));exit();

//CDN加速:最大上传文件大小
function max_upload($domain,$value)
{   
    $value=intval($value);
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/max_upload";
    $bodyParams = array();
    $request = array(
        'value' => $value   
    );
    $Headers = getRequestHeader($path, $request);   
    $json_data = request("PATCH", $path, $request, $Headers,$domain,'max_upload');
    return json_decode($json_data, true);
}
// var_dump(max_upload("xxx.com",200));exit();

//流量功能:永久在线
function always_online($domain,$value)
{   
    $id = GetZoneInfo($domain,"id");
    $path = "v31/yjs/zones/".$id."/settings/always_online";
    $bodyParams = array();
    $request = array(
        'value' => $value   
    );
    $Headers = getRequestHeader($path, $request);  
    $json_data = request("PATCH", $path, $request, $Headers,$domain);
    return json_decode($json_data, true);
}
// var_dump(always_online("xxx.com","on"));exit();





//十.全局方法
//删除空数组(传参为空会出错)
function del_array($array=array())
{ 
    foreach ($array as $key => $value) {
        //不能用empty(),有些参数是 0 ，禁止把为 0 参数也删除掉
        if($value==""){         
            unset($array[$key]);
        }
    }
    return $array;
}
//返回中文错误信息原版
function Message($json_data=''){
    $json_data = json_decode($json_data, true);
    if(empty($json_data['errors'])){
        return json_encode($json_data);
    }
    $msg = $json_data['errors'][0]['message'];
    
    $ErrorCodes = ErrorCodes($msg);
    if($msg=='Bad signature:X-Auth-Timestamp must in 300 sec'){
        $ErrorCodes = 'linux系统时间与本机时间不一致,请调准。宝塔主页:面板设置--服务器时间--同步'; 
    }
    $json_data['errors'][0]['message']=$ErrorCodes;
    return json_encode($json_data);
}

//通过curl模拟post的请求；
function SendDataByCurl($url,$data=array()){
    //对空格进行转义
    $url = str_replace(' ','+',$url);
    $ch = curl_init();
    //设置选项，包括URL
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch,CURLOPT_TIMEOUT,30);  //设置超时  
     // POST数据
    curl_setopt($ch, CURLOPT_POST, 1);
    // 把post的变量加上
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    
    //执行并获取url地址的内容
    $output = curl_exec($ch);
    $errorCode = curl_errno($ch);
    
    //释放curl句柄
    curl_close($ch);
    if(0 !== $errorCode) {
        return false;
    }
    
    return $output;
}





//调用旧版本:更改子域名
function ModifyZone($post_request=array()){
    $path = "/v3/yjs/zones/dns_records/";
    $third_id = '';                
    $result = sendRequest($post_request, $third_id, $path, 'PUT'); 
    return $result;
}
//智能压缩(调用旧版本)
function minify_old($domain,$js,$css,$html)
{
    $method = 'PATCH';
    $path = "/v3/yjs/zones/settings/minify/";
    $third_id = '';                
    $result = sendRequest(["domain" => $domain,"js" => $js,"css" => $css,"html" => $html], $third_id, $path, $method); 
    return json_decode($result, true); //直接调用转json
}
function sendRequest($post_params, $third_id, $path = '', $method){
    $AccessKey = $GLOBALS['ACCESS_KEY'];
    $SecretKey = $GLOBALS['SECRET_KEY'];
    $url = 'https://api.su.baidu.com';
    if(!empty($path)){
        $url .= $path;
    }
    if($method == 'GET'){
        $url .= '?'.http_build_query($post_params);
    }
    $get_params = array();
    $headers = buildHeaders( $third_id, $AccessKey, $SecretKey, $path, $get_params, $post_params);
    $curl = curl_init(); // 启动一个CURL会话
    curl_setopt($curl, CURLOPT_URL, $url);          // 要访问的地址 
    curl_setopt($curl, CURLOPT_HEADER, 0);      //设定是否显示头信息
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);    //设定返回的数据是否自动显示
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);          
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($post_params));    //请求数据
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}
function buildHeaders( $third_id='', $access_key, $secret_key, $path, $get_params=array(), $post_params=array()){
    $h_array = array(
        'X-Auth-Access-Key' => $access_key,
        'X-Auth-Timestamp' => (string)time(),
        'X-Auth-Signature-Method' => 'HMAC-SHA1',
        'X-Auth-Nonce' => md5(time()),
        'X-Auth-Path-Info' => trim($path, '/'),
    );
    if( $third_id ){
        $h_array['X-User-Id'] = $third_id;
    }
    $all_params = array();
    $all_params = $h_array + $get_params + $post_params;
    //print_r($all_params);exit;
    $auth_sign = buildSign($secret_key, $all_params);
    $h_array['X-Auth-Sign'] = $auth_sign;
    $headers = array();
    foreach ($h_array as $k => $v) {
        $headers[] = $k . ":" . $v;
    }
    return $headers;    
}
function buildSign($secret_key, $params){
    // array_keys 返回数组中所有的键名 
    $keys = array_keys($params); 
    // sort 对数组排序 
    sort($keys);
    $tmp_array = array();
    foreach($keys as $k) {
        if ($k == "X-Auth-Path-Info") {
            // stripslashes 反引用一个引用字符串 
            $tmp_array[] = $k . '=' . stripslashes(json_encode($params[$k]));
        } else {
            // json_encode 对变量进行 JSON 编码 
            $tmp_array[] = $k . '=' . json_encode($params[$k]);
        }
    }

    // implode 将一个一维数组的值转化为字符串 
    $base_str = implode('&', $tmp_array);
    $base_str =str_replace('"','',$base_str);

    // base64_encode 使用 MIME base64 对数据进行编码 
    // hash_hmac 使用HMAC方法生成一个密钥的哈希值
    $res = base64_encode(hash_hmac("sha1", $base_str, $secret_key, true));
    //var_dump($res);
    return $res;
}




function ErrorCodes($msg){
    $msg_strstr = strstr($msg, 'code:');
    $msg2 = substr($msg_strstr,5);
    $ErrorCodes = array(
        10308 => "用户已存在",
        40031 => "资源不存在",
        43034 => "姓名有误",
        40056 => "验证码超时，请重新申请验证码",
        71002 => "无法将未备案或违规域名设置为付费版",
        11002 => "代理商结算日期未到",
        43073 => "域名在旗舰版黑名单上",
        43196 => "退票失败，请重试",
        41010 => "有其他用户使用该zone开启反屏蔽功能，不允许再次添加",
        40064 => "兑换的积分商品不存在",
        41012 => "已经有另外一个用户使用该zone开启了反屏蔽功能",
        50301 => "没有权限设置域名为此版本",
        11404 => "奖品已抽完",
        70200 => "无权限操作代理商账户",
        10011 => "无效的id",
        43046 => "营业执照号码有误",
        40065 => "用户积分不足",
        40051 => "貔貅开关未开启",
        40053 => "不支持添加泛域",
        43026 => "域名已经是回源状态并且生效在限流记录中",
        70304 => "不存在的分组",
        41015 => "同一个时间段只能有一个活动",
        11200 => "该域名不存在，请确认是否已删除",
        12301 => "不允许给TLD域名打分",
        72000 => "不存在该广告用户",
        43071 => "程序出错或响应超时,请重试",
        10008 => "参数错误",
        10013 => "错误的父资源指定",
        11517 => "活动分组不存在",
        50300 => "无法创建发票",
        11518 => "存在关联的活动，无法删除",
        43072 => "设置旗舰版套餐失败",
        40030 => "创建云观测用户失败",
        50303 => "域名未备案无法升级为此套餐",
        43191 => "备注字符不能超过40字",
        43200 => "用户重复添加",
        10026 => "后端API返回错误",
        10050 => "创建TLD失败",
        50105 => "无法取消该订单",
        43002 => "重复的代理商收件人",
        40005 => "注册扫雷错误",
        43068 => "操作失败,QS服务异常",
        40034 => "站点数量限制",
        40039 => "获取网站失败, 只有激活域名可配置此项",
        11001 => "该用户不是代理商",
        10000 => "系统错误",
        43199 => "此域名禁止添加，请联系客服",
        40004 => "无效的扫雷设置",
        43050 => "系统维护升级中，暂不可用",
        11528 => "一个域名只限秒杀一次",
        43184 => "绑定失败",
        50206 => "更新退款状态出错",
        12304 => "退款通知回调不能通过检查，有可能是订单示退款或重复通知",
        11206 => "付费域名不允许删除",
        70001 => "无权限请求链接资源",
        41003 => "添加记录达到上限，请升级套餐",
        12302 => "不允许给强制违规的域名打分",
        40057 => "验证码错误",
        11308 => "返回值错误",
        50005 => "无效的订单号",
        50204 => "无法更新订单状态",
        43052 => "审核分类名重复",
        40058 => "此种类型操作不支持",
        11520 => "很抱歉，超出本次活动期间该商品的购买数量限制",
        12306 => "不存在的代理商id",
        43079 => "证书取消失败",
        43054 => "导出数据失败",
        11504 => "调整调度方式出错",
        40055 => "发送次数过多，请稍后再试",
        11525 => "很抱歉,只有新域名才可以参与活动，请添加新域名",
        10009 => "无效的用户",
        70101 => "重复分配权限出错",
        10001 => "认证失败",
        11312 => "参数类型错误",
        43181 => "获取函数失败",
        50009 => "订单数过多",
        70203 => "必须填写扣款原因",
        10003 => "没有这个API",
        50001 => "无法创建订单",
        11203 => "该活动不存在",
        40041 => "请求参数不正确",
        10305 => "没有这个用户",
        43182 => "超出爬虫检测深度",
        70303 => "重复的user from记录",
        43032 => "限流请求CF错误",
        40036 => "没有创建此任务",
        43057 => "不能操作此站",
        11401 => "没有这个奖品id",
        43051 => "添加域名超时(nid)",
        43196 => "下发限速配置到redis失败",
        43180 => "删除函数失败",
        11508 => "活动不存在",
        40050 => "该子域正在使用安全检测，请删除后再进行操作",
        70021 => "分配账户是代理商，不能分配",
        10032 => "节点名称已存在",
        10034 => "priority'参数值超出限制",
        43183 => "函数不存在",
        40009 => "无效的域名，请确保该域名已接入云加速",
        71000 => "无法操作免费试用专业版活动",
        43013 => "未经验证的电话号码",
        40035 => "此站点未激活",
        60001 => "cdn features操作权限错误",
        43011 => "所传抬头不可用",
        11513 => "此活动没有奖品",
        40052 => "非活动用户",
        43179 => "上传函数失败",
        43060 => "操作失败,QS服务异常",
        10004 => "错误的URI请求",
        43038 => "未输入验证码",
        10040 => "一个子域名需要一条默认线路记录",
        43201 => "创建订单太快,请稍等",
        43007 => "没有待开的发票申请",
        43079 => "证书删除失败",
        70010 => "分配权限错误",
        43182 => "函数名不合法",
        41021 => "此功能在当前版本下不可用，请升级版本",
        43185 => "获取account_id失败",
        43061 => "操作失败,QS服务异常",
        10033 => "缺少'priority'参数",
        11519 => "存在关联的商品，无法删除",
        43079 => "证书订单已存在",
        70305 => "有不存在的split DnsGroups",
        11505 => "参数priority值有错",
        72003 => "获取广告资源出错",
        50103 => "无法生成支付链接",
        70000 => "无权限删除链接资源",
        10303 => "缺少Key参数",
        10037 => "防盗链白名单个数超出限制",
        43182 => "函数名已存在",
        11524 => "您好,代理商不能参加该活动",
        43198 => "角色名重复，请检查",
        43012 => "所传公司不可用",
        50406 => "该代理商订单已退款",
        10027 => "该分组有网站，先调分组再删除",
        10036 => "不可识别的主域",
        43186 => "该域名是付费域名",
        11526 => "很抱歉,只有续费域名才可以参与活动",
        43044 => "上传文件路径有误",
        43033 => "白名单删除失败",
        43048 => "流量包退款未找到匹配的订单",
        43182 => "函数已存在",
        11304 => "没有开启www子域",
        43182 => "模板名不合法",
        43043 => "未实名无法添加域名",
        12303 => "打分时修改DNS分组出错",
        11501 => "非法的电话号码",
        43062 => "5分钟内只能请求一次检测",
        50000 => "操作权限错误",
        41002 => "域名已经是专业版， 不能再设置成专业版或其他支付版本",
        43080 => "请上传正确的证书链（服务器+中间证书）",
        10030 => "per_page和page参数必须为正整数",
        10029 => "添加的域名已存在",
        11400 => "无抽奖机会",
        11516 => "该名称已存在",
        10031 => "per_page或page超过了限制值",
        43021 => "消耗流量失败",
        10007 => "参数解析错误",
        43203 => "仅可操作当前主域的相关子域",
        43194 => "开票失败，请重试",
        11402 => "缺少域名参数",
        41014 => "申请证书时一次所传dns_name不能超过5个",
        43180 => "扫雷配置信息不存在",
        12307 => "创建优惠券生成任务失败",
        43063 => "8小时内只能提交一次申请",
        43037 => "地址有误",
        70201 => "账号余额不足, 请续费",
        10307 => "缺少组Id",
        11523 => "您好,优惠权益已经领取过",
        40054 => "不存在的tmpl",
        70302 => "活动名称重复",
        10035 => "添加的子域名已存在",
        43047 => "已添加站不能取消实名",
        43195 => "2018年1月1号之前订单不能开电子发票",
        43040 => "姓名有误",
        11506 => "参数pop_id值有错",
        43020 => "消耗流量包流量失败",
        40040 => "请求参数不正确",
        60000 => "cdn configs操作权限错误",
        40063 => "不可修改的参数字段",
        43058 => "海外ip初始化失败",
        10006 => "未知错误",
        40060 => "position出错",
        12308 => "不可用的优惠券",
        43193 => "退票金钱不能大于订单金额",
        43045 => "企业名有误",
        11514 => "抽奖失败",
        60003 => "override host 参数出错",
        50102 => "无法获取套餐",
        11510 => "没有参加此活动",
        43036 => "手机号有误",
        11205 => "优惠券不存在",
        50404 => "非法的代理商订单",
        43016 => "记录代理商帐单失败",
        11101 => "条数超出本套餐限制，请购买或升级套餐",
        60004 => "origin host 参数出错",
        43182 => "模板名已存在",
        43204 => "批量下节点失败",
        11100 => "参数value只能为off或on",
        43015 => "不存在的流量包",
        43028 => "设置回源失败",
        70011 => "获取分配权限记录错误",
        43005 => "不可操作的发票申请",
        41001 => "域名已存在，如需继续添加请联系客服",
        10025 => "后端API请求超时",
        70012 => "修改分配权限记录错误",
        43184 => "抱歉，您的用户下没有付费域名，请前往新人体验站参与活动",
        43019 => "拉取所消耗流量失败",
        43073 => "旗舰版套餐已存在",
        43079 => "证书申请失败",
        11307 => "没有http协议",
        10015 => "重置密码链接失效",
        41016 => "不存在的agency account",
        11204 => "优惠券不属于该活动",
        41007 => "联盟反屏蔽域名不允许使用该功能，有疑问请联系客服",
        50302 => "域名未备案无法设置为此套餐",
        43049 => "批量上传地址已存在",
        50008 => "域名未备案或违规，无法创建订单",
        12310 => "生成未支付购买记录失败",
        43004 => "重复的域名申诉记录",
        43179 => "任务ID不存在",
        43079 => "证书名称已存在",
        43042 => "未实名无法取消实名",
        11207 => "自定义规则超过套餐条数",
        11403 => "缺少用户来源参数",
        11507 => "删除app出错",
        72002 => "不存在该广告资源",
        43031 => "限流白名单记录不存在",
        70307 => "非法的user from记录",
        50202 => "订单支付金额不存在",
        43202 => "海外域名只允许以cname方式接入",
        43075 => "证书还未生效",
        50304 => "域名违规无法升级为此套餐",
        11511 => "不在此活动期间",
        40038 => "网站无法访问",
        40033 => "已经存在相同的资源",
        40062 => "非激活域名不可设置SSL",
        40037 => "站点验证失败",
        40059 => "此操作已开过发票",
        72005 => "查询日期区间超出限制",
        43027 => "限流记录解除回源失败",
        70020 => "用户识别码错误",
        11201 => "此优惠券已经绑定用户，他人不能领取",
        43017 => "记录代理商总帐单失败",
        43025 => "域名已经是回源状态",
        50010 => "未支付订单数过多",
        43197 => "接口请求速度过快，请稍后重试",
        43059 => "网站地址不存在",
        11515 => "不能领奖",
        43078 => "证书不属于该域名",
        41013 => "dns_names里有不属于此域名的子域名",
        60002 => "cdn features zone状态错误",
        43069 => "操作失败,qps需为大于等于1的正整数",
        43076 => "证书已经过期",
        43181 => "超出爬虫最大抓取URL数量",
        50200 => "退款错误",
        11309 => "不支持这种第三方类型",
        50007 => "此订单不可取消",
        10005 => "没有权限",
        70306 => "split DnsGroups里不存在激活的dns_route",
        43009 => "所传操作记录不可用",
        43201 => "该代理商不允许添加海外域名，请联系商务或客服升级",
        41005 => "用户身份已经验证成功，无须再次验证",
        11202 => "active_type 类型错误",
        12305 => "退款通知回调更新refund记录失败",
        43022 => "活动期间每个域名最多可买5个流量包",
        41011 => "当前套餐最多可监控100个域名，请您重新选择，或者购买企业版，可监控500个域名",
        43055 => "审核未通过，不能开启加速",
        10306 => "缺少组名",
        50101 => "无法生成订单",
        11509 => "收货地址不存在",
        41006 => "联盟反屏蔽域名不能开启CC防护，有疑问请联系客服",
        41008 => "指定URL过长，不能超过255个字符",
        43182 => "无可用计算包",
        43178 => "微信生成二维码错误",
        41016 => "当前套餐最多可监控500个域名，请您重新选择",
        50104 => "无法创建百付宝支付订单",
        43190 => "参数抬头不能为北京百度网讯科技有限公司",
        43018 => "记录代理商定单信息失败",
        11500 => "非法的邮箱地址",
        43006 => "错误的发票号",
        43057 => "有效期限过长",
        41017 => "验证码已经申请，短期无法再次创建",
        10039 => "CNAME记录的指向必须是一个域名",
        43067 => "操作失败,QS服务异常",
        10002 => "不支持的方法",
        43064 => "请求网址安全API失败",
        43070 => "请输入一个正确的子域",
        50002 => "无法获取订单",
        10304 => "缺少用户组列表参数",
        43066 => "QPS限速初始化失败",
        43073 => "旗舰版套餐名不存在",
        11522 => "很抱歉,当前优惠券不能领取",
        41004 => "代理商帐号不支持退款",
        10042 => "缺少必须参数",
        70300 => "不存在的市场推广活动",
        10038 => "A记录的指向必须是一个ip地址",
        43024 => "限流白名单记录已存在",
        10028 => "您的网站由于违规已被加入黑名单，不可添加，如有异意请联系客服",
        43192 => "请检查发票状态",
        70100 => "权限出错",
        50207 => "查询百付宝退款状态出错",
        12311 => "通过域名在本地创建付费版记录失败",
        70301 => "活动时间重叠",
        10302 => "缺少APP名称参数",
        43039 => "类型错误",
        11521 => "很抱歉，今天的抽奖次数已经超出上限",
        43053 => "导出数据为空",
        10024 => "后端API请求失败",
        43065 => "批量拉黑url部分失败",
        43023 => "未备案域名，你可选择接入海外版",
        50205 => "订单未支付不能退款",
        11512 => "没有抽奖次数",
        10014 => "该记录已存在",
        43073 => "删除旗舰套餐失败",
        50106 => "订单已经过期",
        41031 => "请勿重复添加联系人",
        43003 => "域名不存在或不能添加，请联系客服",
        11102 => "参数字符串长度不能超过100",
        72004 => "未实名认证",
        71001 => "不存在该域名",
        10010 => "API调用失败",
        43001 => "重复的代理商记录",
        43077 => "证书与私钥不匹配",
        43014 => "未经验证的邮箱",
        41005 => "条数超出限制，请删除现有数据再添加",
        40061 => "url_pattern出错",
        40032 => "缺少必要的请求参数",
        12309 => "使用优惠券失败",
        10301 => "缺少用户ID参数",
        50203 => "退款金额超过支付金额",
        43008 => "生成未开发票申请并上传文件失败",
        43030 => "域名状态不符合",
        43056 => "请求ADS接口超时",
        50405 => "非法的代理商订单退款金额",
        10012 => "缺少父资源指定",
        72001 => "不存在该广告商",
        43010 => "所传地址不可用",
        10041 => "该域名强制违规，不能直接调整其分组，请修改其审核状态后再调整分组",
        11208 => "缓存时间设置超过了套餐限制",
        43183 => "znames参数错误",
        50006 => "此订单已有发票",
        71003 => "其他用户已添加该域名并且域名已激活",
        50201 => "订单号不存在",
        11502 => "请升级套餐以使用该功能",
        43029 => "流量不足开启失败，请购买流量包或升级套餐",
        70202 => "无权限获取账户操作记录",
        43041 => "身份证号码有误",
        43074 => "导出数据失败"
    );
    
    if(empty($ErrorCodes[$msg2])){
        return  $msg;
    }
    return  $ErrorCodes[$msg2];
}


?>