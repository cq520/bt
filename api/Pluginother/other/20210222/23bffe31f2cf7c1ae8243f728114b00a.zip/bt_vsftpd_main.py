#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem <sang8052@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   bt-vsftp 基于vsftp 开发的增强功能的ftp 插件
#+--------------------------------------------------------------------
import sys,os,json,requests,re,time


#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

logpath = "/www/server/panel/plugin/bt_vsftpd/log/autolog.log"


class bt_vsftpd_main:
    __plugin_path = "/www/server/panel/plugin/bt_vsftpd/"
    __config = None
    __service_md5 = "7fd3f3e263e8d059fbeca65f26053682"
    __python = ""

    #构造方法
    def  __init__(self):
        if os.path.exists("/www/server/panel/pyenv/bin/python"):
            self.__python = "/www/server/panel/pyenv/bin/python"
        else:
            self.__python = "python"
        # 初始化全局配置文件
        if not os.path.exists(self.__plugin_path+"conf/vsftpd.json"):
            vsftpd = {"uuid":"","controlport":"21","portport":"20","pavsport":"39000-40000","usernum":0,"speed":0,"loginmes_status":"on",
                      "loginmes_content":"Welcome To Login BT-FTP SERVER,This Server is Build in vsftpd 3.0.3 with bt-vsftpd plugin","listen":"ipv4"}
            public.WriteFile(self.__plugin_path+"conf/vsftpd.json",json.dumps(vsftpd))
        # 初始化虚拟用户配置文件
        if not os.path.exists(self.__plugin_path+"conf/virtualuser.txt"):
            public.WriteFile(self.__plugin_path+"conf/virtualuser.txt","")
            public.WriteFile(self.__plugin_path+"conf/virtualuser.json","{}")
        # 初始化缓存数据文件
        if not os.path.exists(self.__plugin_path + "conf/cache.json"):
            cache = {"ip":"","ip_expire":0,"expand":"","expand_expire":0,"softdown":"","softdown_expire":0}
            public.WriteFile(self.__plugin_path + "conf/cache.json",json.dumps(cache))

    def PageLoad(self,args):
        page = args.page
        if os.path.exists(self.__plugin_path+"templates/"+page+".html"):
            html = public.ReadFile(self.__plugin_path + "templates/" + page + ".html")
            if page == "about":
                PluginVersion = self.GetPluginVersion()
                html = html.replace("BTPLUGINVERSION", PluginVersion)
            return {"status":"Success","msg":"Load Static Page Success","html":html}
        else:
            return {"status":"Error","msg":"Request Page ["+page + "] Not Exist!"}


    def GetTotalData(self,args):
        import  system
        btsys = system.system()
        # 获取服务状态
        if self.GetServiceStatus():
            ServerStatus  = "live"
        else:
            ServerStatus = "dead"
        # 获取系统版本信息
        SystemOS = btsys.GetSystemVersion()
        # 获取插件版本信息
        PluginVersion  = self.GetPluginVersion()
        # 获取内核版本信息
        CoreVersion = self.GetCoreVersion()
        # 获取服务器地址信息
        LocalIp = self.GetLocalIpaddress()
        # 获取全局配置信息（控制端口、主动数据端口、被动数据端口、用户数量、全局限速、登录消息显示 和 内容）
        GlobalConfig = self.GetGlobalConfig()
        usernum  = self.GetUserNum()
        # 获取日志文件大小信息
        logsize = public.get_path_size(self.__plugin_path+"log/vsftpd.log")
        logsize = public.to_size(logsize)
        return {"status":"Success","ServerStatus":ServerStatus,"SystemOS":SystemOS,"PluginVersion":PluginVersion,
                "CoreVersion":CoreVersion,"LocalIp":LocalIp,"logsize":logsize,"controlport":GlobalConfig["controlport"],
                "pavsport":GlobalConfig["pavsport"],"portport":GlobalConfig["portport"],"usernum":usernum,
                "speed":GlobalConfig["speed"],
                "loginmes_status": GlobalConfig["loginmes_status"],"loginmes_content": GlobalConfig["loginmes_content"]}

    # 启动服务
    def Service_Start(self,args):
        # 检查当前系统的启动服务项是否被修改
        if public.FileMd5("/lib/systemd/system/vsftpd.service")!= self.__service_md5:
            self.reInstallService()
        GlobalConfig = self.GetGlobalConfig()
        if not  self.GetServiceStatus():
            if  public.check_port_stat(int(GlobalConfig["controlport"])) == 2:
                return {"status": "Success", "ServerStatus": "portuse", "time": public.format_date(),"port":GlobalConfig["controlport"]}
            self.ServiceBuildConfig()
            shell = "systemctl start vsftpd"
            os.system(shell)
        if self.GetServiceStatus():
            ServerStatus = "live"
        else:
            ServerStatus = "dead"
        log = self.Sevicce_StatusLog(public.dict_obj())["log"]
        return {"status":"Success","ServerStatus":ServerStatus,"time":public.format_date(),"port":GlobalConfig["controlport"],"ServerLog":log}

    # 停止服务器
    def Service_Stop(self,args):
        if self.GetServiceStatus():
            shell = "systemctl stop vsftpd"
            os.system(shell)
        if self.GetServiceStatus():
            ServerStatus = "live"
        else:
            ServerStatus = "dead"
        return {"status": "Success", "ServerStatus": ServerStatus, "time": public.format_date()}

    # 重启服务器
    def Service_Restart(self,args):
        self.Service_Stop(args)
        return self.Service_Start(args)

    # 清空系统日志信息
    def Service_LogClean(self,args):
        public.WriteFile(self.__plugin_path + "log/vsftpd.log","")
        return {"status": "Success", "time": public.format_date()}

    # 获取当前服务器的运行状态信息、
    # 用于启动失败时输出异常
    def Sevicce_StatusLog(self,args):
        popen = os.popen("systemctl status vsftpd.service -l")
        log = "<br><br>"+popen.read()
        popen.close()
        log = log.replace("\n","<br>")
        return {"status":"Success","log":log}

    # 获取配置文件信息的
    def GetConfigText(self,args):
        ConfigText = public.ReadFile(self.__plugin_path+"conf/vsftpd.conf")
        return {"status":"Success","ConfigText":ConfigText}

    # 获取日志文件信息的
    def GetLogText(self,args):
        LogText = public.ReadFile(self.__plugin_path+"log/vsftpd.log")
        if not LogText:
            LogText = "日志文件不存在"
        return {"status":"Success","LogText":LogText}

    # 获取全局配置页面的信息
    def GetGlobalData(self,args):
        GlobalConfig = self.GetGlobalConfig()
        return {"status":"Success","controlport":GlobalConfig["controlport"],"pavsport":GlobalConfig["pavsport"],"speed":GlobalConfig["speed"],
                "listenmode":GlobalConfig["listen"],"loginmes":GlobalConfig["loginmes_status"],"loginmes_content":GlobalConfig["loginmes_content"]}

    # 修改全局配置页面的信息
    def SetGlobalData(self,args):
        GlobalConfig = self.GetGlobalConfig()
        GlobalConfig["listen"] = args.listenmode
        GlobalConfig["speed"] = int(args.speed)
        GlobalConfig["loginmes_content"] = args.loginmes_content
        GlobalConfig["loginmes_status"] = args.loginmes
        GlobalConfig["pavsport"] = args.pavsport
        GlobalConfig["controlport"] = args.controlport
        import firewalls
        bt_firewalls = firewalls.firewalls()
        controlport = public.dict_obj()
        controlport.port = args.controlport
        controlport.ps = "FTP 控制端口"
        pavsport = public.dict_obj()
        pavsport.port = args.pavsport
        pavsport.ps = "FTP 被动模式端口"
        bt_firewalls.AddAcceptPort(controlport)
        bt_firewalls.AddAcceptPort(pavsport)
        public.WriteFile(self.__plugin_path+"conf/vsftpd.json",json.dumps(GlobalConfig))
        return self.Service_Restart(args)

    # 获取第三方拓展接入信息
    def GetExpandData(self,args):
        cache = json.loads(public.ReadFile(self.__plugin_path + "conf/cache.json"))
        if cache["expand_expire"] <= time.time():
            expand=requests.get("https://auth.iw3c.top/?api=bt_vsftpd&data=expand",verify=False).text
            _expand = json.loads(expand)
            cache["expand"] = _expand
            cache["expand_expire"] = time.time() + 60 * 60 * 24
            public.WriteFile(self.__plugin_path + "conf/cache.json", json.dumps(cache))
        else:
            expand = json.dumps(cache["expand"])
            _expand = cache["expand"]
        num = len(_expand["expand"])
        return {"status":"Success","data":expand,"num":num}

    # 获取软件下载的信息
    def GetSoftDownData(self,args):
        cache = json.loads(public.ReadFile(self.__plugin_path + "conf/cache.json"))
        if cache["softdown_expire"] <= time.time():
            soft = requests.get("https://auth.iw3c.top/?api=bt_vsftpd&data=soft", verify=False).text
            _soft = json.loads(soft)
            cache["softdown"] = _soft
            cache["softdown_expire"] = time.time() + 60 * 60 * 24
            public.WriteFile(self.__plugin_path + "conf/cache.json", json.dumps(cache))
        else:
            soft = json.dumps(cache["softdown"])
            _soft = cache["softdown"]
        num = len(_soft["soft"])
        return {"status": "Success", "data": soft, "num": num}

    # 获取设备信息代码
    def GetPluginUUid(self,args):
        GlobalConfig = self.GetGlobalConfig()
        if GlobalConfig["uuid"] == "":
            # 添加开机启动项目
            self.Service_AutoRunAdd()
            import system
            btsys = system.system()
            osversion = btsys.GetSystemVersion().split("(")[0]
            cpuversion = btsys.GetCpuInfo()[3]
            macaddress = public.get_mac_address()
            uuid = public.md5(osversion + cpuversion + macaddress)
            GlobalConfig["uuid"] = uuid
            public.WriteFile(self.__plugin_path+"conf/vsftpd.json",json.dumps(GlobalConfig))
            return {"status":"Success","uuid":""}
        else:
            return {"status":"Success","uuid":GlobalConfig["uuid"]}

    # 第三方API 调用鉴权
    def _check(self,args):
        return True;


    # ========================================
    # 用户处理逻辑
    # ========================================
    def Users_AddUser(self,args):
        args.disksize=  int(round(float(args.disksize)))
        args.speed = int(round(float(args.speed)))
        BlackUser  = {"root","mysql","www","ftp","vsftpd","centos","guest","vsftpd-defuser"}
        if args.username in BlackUser:
            return {"stauts": "Failed", "msg": "添加用户失败，不允许添加系统用户!", "userid": public.md5(args.username)[9:16],"diskstatus":"unknow"}
        # 检查用户名是否存在
        elif not self.Check_UserExist(args.username) or args.username == "vsftpd_guest":
            return {"stauts":"Failed","msg":"添加用户失败，指定的用户已经存在!","userid":public.md5(args.username)[9:16],"diskstatus":"unknow"}
        elif args.disksize != 0 and os.path.exists(args.homepath):
            return {"status": "Failed", "msg": "添加用户失败，添加磁盘限容类型的FTP时，用户目录["+args.homepath+"]必须不存在!请先删除此目录在添加!~", "userid": public.md5(args.username)[9:16],"diskstatus":"unknow"}
        # 检查目录是否存在 or 是否能够创建
        elif not self.Check_HomePath(args.homepath):
            return {"status":"Failed","msg":"添加用户失败，试图添加的用户目录存在风险或目录地址错误","userid":public.md5(args.username)[9:16],"diskstatus":"unknow"}
        # 启用磁盘限容功能
        elif args.disksize != 0:
            shell = "cd "+self.__plugin_path + " && " + self.__python +" bt_vsftpd_disk.py -m init -p " + args.homepath + " -u "+ public.md5(args.username)[9:16] + " -s "+ str(args.disksize)
            # 启用计划任务
            import panelTask
            task = panelTask.bt_task()
            task_name = "BT-VSFTPD 插件初始化磁盘["+args.homepath+"])"
            task_type = 0
            task.create_task(task_name, task_type, shell)
            diskstatus = "virtual-disk"
        else:
            diskstatus = "local-disk"


        # 构造用户的配置数据文件
        newUser = {"username":args.username,"password":args.password,"speed":args.speed,"homepath":args.homepath,"powerlevel":args.powerlevel,"disksize":args.disksize,"userid":public.md5(args.username)[9:16],"diskstatus":diskstatus}
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        userid = public.md5(args.username)[9:16]
        virtualuser[userid] = newUser
        public.WriteFile(self.__plugin_path + "conf/virtualuser.json",json.dumps(virtualuser))


        # 重载用户的虚拟数据库配置文件
        self.LoadConfig_UserDB()
        # 重载用户的权限管理控制文件
        self.LoadConfig_UserConf()
        # 重新启动服务器
        self.Service_Restart(public.dict_obj())
        return {"status":"Success","msg":"创建用户成功...","diskstatus":diskstatus,"userid":public.md5(args.username)[9:16]}

    def Users_DelUser(self,args):
        # 读取 虚拟数据文件
        userdata = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        _userdata = userdata
        for t in userdata:
            user = userdata[t]
            if user["userid"] == args.userid:
                _userdata.pop(args.userid)
                # 虚拟磁盘、删除用户数据
                if user["diskstatus"] !="local-disk":
                    shell = "cd "+self.__plugin_path + " && " + self.__python +" bt_vsftpd_disk.py -m del -u "+ args.userid
                    public.ExecShell(shell)
                public.WriteFile(self.__plugin_path + "conf/virtualuser.json", json.dumps(_userdata))
                self.Service_Restart(public.dict_obj())
                break;
        return {"status": "Success", "RequestId": public.md5(public.md5(args.userid) + public.format_date()),"time": public.format_date()}

    def Users_Update(self,args):
        # 读取 虚拟数据文件
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        for p in virtualuser:
            user = virtualuser[p]
            if user["userid"] == args.userid:
                # 判断homepath 是否修改
                if args.homepath !=user["homepath"]:
                    if not self.UpdateUser_HomePath(args.userid,args.homepath):
                        return {"status":"Failed","msg":"无法修改绑定限容盘的用户的根目录地址!","RequestId": public.md5(public.md5(args.userid) + public.format_date()),"time": public.format_date()}
                    else:
                        user["homepath"] = args.homepath
                else:
                    user["password"] =args.password
                    user["speed"] = args.speed
                    user["powerlevel"] = args.powerlevel
                    virtualuser[args.userid] = user
                public.WriteFile(self.__plugin_path + "conf/virtualuser.json", json.dumps(virtualuser))
                self.Service_Restart(public.dict_obj())
                break
        return {"status": "Success","msg":"修改用户信息成功","RequestId": public.md5(public.md5(args.userid) + public.format_date()),"time": public.format_date()}

    def Users_List(self,args):
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        _virtualuser = virtualuser
        for p in virtualuser:
            user = virtualuser[p]
            _virtualuser[p]["diskuse"] = self.GetUser_DiskUse(p)
        return {"status": "Success", "RequestId": public.md5(public.GetRandomString(16) + public.format_date()),"list": _virtualuser}

     # 获取指定用户得信息配置信息
    def Users_Info(self,args):
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        _virtualuser = virtualuser
        for p in virtualuser:
            user = virtualuser[p]
            if user["userid"] == args.userid:
                user["diskuse"] = self.GetUser_DiskUse(p)
                user["powerlevel"]=user["powerlevel"].split("_")
                break
        return {"status": "Success", "RequestId": public.md5(public.GetRandomString(16) + public.format_date()),"user": user}

    # ========================================
    # 内部处理方法
    # ========================================

    # 查看服务的状态信息
    # 返回 true | false
    def GetServiceStatus(self):
        lines = os.popen('ps -ef | grep vsftpd')
        for path in lines:
            colum = path.split()
            if colum[7] == '/usr/sbin/vsftpd':
                return True
        return False


    # 获取插件的版本信息
    def GetPluginVersion(self):
        Plugin = json.loads(public.ReadFile(self.__plugin_path+"/info.json"))
        return Plugin["versions"]
        # 获取内核版本信息

    def GetCoreVersion(self):
        import system
        btsys = system.system()
        SystemOS = btsys.GetSystemVersion()
        if re.findall(r'CentOS', SystemOS):
            res = "unfind"
            popen = os.popen("yum list installed | grep vsftpd")
            version = popen.read()
            version = version.split(" ")
            m = 0
            for t in version:
                if t != "" and m != 0:
                    res = t
                    break
                else:
                    m = 1
        else:
            popen = os.popen("apt list --installed | grep vsftpd")
            cli = popen.read()
            res = cli.split(" ")[1]
            if res == "":
                res = "unfind"
        popen.close()
        return res


    # 获取服务器的ip地址信息
    def GetLocalIpaddress(self):
        cache = json.loads(public.ReadFile(self.__plugin_path + "conf/cache.json"))
        if cache["ip_expire"] <= time.time():
            url = "http://v2.api.iw3c.top/?api=ip&ip=0.0.0.0"
            res = requests.get(url, verify=False).text
            _data = json.loads(res)
            cache["ip"] = _data
            cache["ip_expire"] = time.time() + 60 * 60 * 24
            public.WriteFile(self.__plugin_path + "conf/cache.json", json.dumps(cache))
        else:
            _data = cache["ip"]
        return _data['data']['ip']

    # 获取全局配置信息
    def GetGlobalConfig(self):
        GlobalConfig = json.loads(public.ReadFile(self.__plugin_path+"conf/vsftpd.json"))
        return GlobalConfig

    # 生成符合pam 调用标准的用户数据库文件
    def ServiceUserDataBase(self):
        # 删除核心数据库文件
        os.system("rm -rf "+self.__plugin_path+"conf/virtualuser.db")
        os.system("db_load -T -t hash -f "+self.__plugin_path+"conf/virtualuser.txt "+self.__plugin_path+"conf/virtualuser.db")
        os.system("chmod 600 "+self.__plugin_path+"conf/virtualuser.db")



    # 渲染主配置文件
    def ServiceBuildConfig(self):
        self.ServiceUserDataBase()
        GlobalConfig = self.GetGlobalConfig()
        if GlobalConfig["listen"] == "ipv4":
            listen = "listen=YES"
        else:
            listen = "listen_ipv6=YES"
        pavsport = GlobalConfig["pavsport"].split("-")
        min_port = pavsport[0]
        max_port = pavsport[1]
        if GlobalConfig["loginmes_status"] == "on":
            dirmessage = "YES"
        else:
            dirmessage ="NO"
        if GlobalConfig["speed"] !=0:
            speed = "local_max_rate=" + str(int(GlobalConfig["speed"])*1024)
            speed = speed + "\nanon_max_rate=" + str(int(GlobalConfig["speed"])*1024)
        else:
            speed = ""
        Config = '''# vsftpd 核心配置文件 
# 渲染时间 [%s]

#======= 端口监听 =============
%s
listen_port=%s
# [异步数据传输 ASCII 编码支持]
async_abor_enable=YES
ascii_upload_enable=YES
ascii_download_enable=YES

# [主动 / 被动模式]
port_enable=YES
connect_from_port_20=YES
pasv_enable=YES
pasv_min_port=%s
pasv_max_port=%s
#===========================


# ======= 用户权限 ===========
# [匿名用户配置]
anonymous_enable=NO
anon_upload_enable=NO
anon_mkdir_write_enable=NO
anon_other_write_enable=NO

# [虚拟用户访问配置]
local_enable=YES
chroot_local_user=YES
allow_writeable_chroot=YES
userlist_enable=YES
guest_enable=YES
guest_username=root
pam_service_name=vsftpd
virtual_use_local_privs=NO
user_config_dir=/www/server/panel/plugin/bt_vsftpd/conf/user
#==============================


# ======== 日志限流 ===========
#[系统日志]
xferlog_enable=YES
dual_log_enable=YES
vsftpd_log_file=/www/server/panel/plugin/bt_vsftpd/log/vsftpd.log
use_localtime=YES

#[登录消息]
dirmessage_enable=%s
ftpd_banner=%s

#[限速限流限时]
max_per_ip= 5
max_clients= 300
idle_session_timeout=300
%s
# ===============================
'''%(public.format_date(),listen,GlobalConfig["controlport"],min_port,max_port,dirmessage,GlobalConfig["loginmes_content"],speed)
        public.WriteFile(self.__plugin_path+"conf/vsftpd.conf",Config)
        # 重载用户的虚拟数据库配置文件
        self.LoadConfig_UserDB()
        # 重载用户的权限管理控制文件
        self.LoadConfig_UserConf()

    def Check_UserExist(self,username):
        Users = json.loads(public.ReadFile(self.__plugin_path+"conf/virtualuser.json"))
        userid = public.md5(username)[9:16]
        try :
            Udata = Users[userid]
            if Udata["username"] == username:
                return False
            else :
                return True
        except:
            return True

    def Check_HomePath(self,homepath):
        dangerpath = ['/','/etc','/usr','/var','/dev','/sys','/tmp','/bin','/sbin','/root','/www','/www/wwwroot']
        if homepath in dangerpath:
            return False
        else:
            try:
                if os.path.exists(homepath):
                    return True
                else:
                    os.mkdir(homepath)
                    if os.path.exists(homepath):
                        return True
                    else:
                        return False
            except:
                return False


    def Service_AutoRunAdd(self):
        if not os.path.exists(self.__plugin_path + 'BT_vsftpd'):
            autorun = public.httpGet("https://download.szhcloud.cn/shell/BT_vsftpd")
            public.WriteFile(self.__plugin_path+"BT_vsftpd",autorun)
        # 复制开机启动脚本
        os.system('cp ' + self.__plugin_path + 'BT_vsftpd /etc/rc.d/init.d/BT_vsftpd')
        os.system("chmod -R 777 "+"/etc/rc.d/init.d/BT_vsftpd")
        # 判断系统类型
        import system
        btsys = system.system()
        System = btsys.GetSystemVersion()
        if re.findall(r'CentOS', System):
            # 注册开机启动
            os.popen('chkconfig --add BT_vsftpd')
        elif re.findall(r"Debian", System) or re.findall(r'Ubuntu', System):
            os.open('sudo update-rc.d BT_vsftpd defaults')

    def LoadConfig_UserDB(self):
        # 删除 虚拟数据库文件 和 txt 文件
        os.system('rm -rf ' + self.__plugin_path + "conf/virtualuser.db")
        virtualuser_txt = ""
        # 读取 虚拟数据文件
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        for p in virtualuser:
            user = virtualuser[p]
            virtualuser_txt = virtualuser_txt + user["username"]  + "\n"
            virtualuser_txt = virtualuser_txt + user["password"]  + "\n"
        public.WriteFile(self.__plugin_path + "conf/virtualuser.txt",virtualuser_txt)
        # 生成新的虚拟数据库文件
        os.system("db_load -T -t hash -f " +self.__plugin_path + "conf/virtualuser.txt" + " "+self.__plugin_path + "conf/virtualuser.db")


    def LoadConfig_UserConf(self):
        os.system("rm -rf " + self.__plugin_path + "conf/user")
        os.mkdir(self.__plugin_path+"conf/user")
        level = {}
        # 读取 虚拟数据文件
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        for p in virtualuser:
            user = virtualuser[p]
            powerlevel = user["powerlevel"].split("_")
            if "download" in powerlevel:
                level["download"] = "download_enable=YES"
            else:
                level["download"] = "download_enable=NO"
            if "upload" in powerlevel:
                level["upload"] = "anon_upload_enable=YES"
            else:
                level["upload"] = "anon_upload_enable=NO"
            if "mkdir" in powerlevel:
                level["mkdir"] = "anon_mkdir_write_enable=YES"
            else:
                level["mkdir"] = "anon_mkdir_write_enable=NO"
            if "other" in powerlevel:
                level["other"] = "anon_other_write_enable=YES"
            else:
                level["other"] = "anon_other_write_enable=NO"
            speed = "local_max_rate=" + str(int(user["speed"]) * 1024)
            speed = speed + "\nanon_max_rate=" + str(int(user["speed"]) * 1024)
            UConfig = """# vsftpd 虚拟用户配置文件
# 用户名 [%s]
# 用户id [%s]
# 配置文件渲染时间 [%s]           
local_root=%s
write_enable=YES
anon_umask=022
%s
%s
%s
%s
%s
""" %(user["username"],user["userid"],public.format_date(),user["homepath"],level["download"],level["upload"],level["mkdir"],level["other"],speed)
            public.WriteFile(self.__plugin_path+"conf/user/"+user["username"],UConfig)

    # 修改用户所对应的家目录地址
    def UpdateUser_HomePath(self,userid,newHomePath):
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        for p in virtualuser:
            if p == userid:
                user = virtualuser[p]
                if user["diskstatus"] != "local-disk":
                    return False
                else:
                    if self.Check_HomePath(newHomePath):
                        return True



    # 取用户目录使用的空间大小
    def GetUser_DiskUse(self,userid):
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        for p in virtualuser:
            if p == userid:
                user = virtualuser[p]
                if user["diskstatus"] == "local-disk":
                    try:
                        diskuse = str(round(public.get_path_size(user["homepath"]) / (1024 * 1024),2)) + " MB"
                        return diskuse
                    except:
                        return "Error"
                else:
                    use = public.get_path_size(user["homepath"]) /(1024*1024)
                    max = user["disksize"]
                    per = str(round(float(use) / float(max) * 100,2)) + "%"
                    try:
                        diskuse = str(round(use,2)) + " MB / " + str(round(max,2)) + " MB (" + per + ")"
                        return diskuse
                    except:
                        return "Error"


    # 获取用户的总数量
    def GetUserNum(self):
        num = 0
        virtualuser = json.loads(public.ReadFile(self.__plugin_path + "conf/virtualuser.json"))
        for p in virtualuser:
            num = num + 1
        return num

    # 重新部署vsftpd 的系统服务项
    def reInstallService(self):
        shell = """
    mv  /lib/systemd/system/vsftpd.service /lib/systemd/system/vsftpd.service.bak
    wget https://download.szhcloud.cn/conf/vsftpd.service && mv vsftpd.service /lib/systemd/system/vsftpd.service
    systemctl daemon-reload
    """
        os.system(shell);



# 开机自动启动vsftpd_ 服务器
if __name__ == '__main__':
    cli_vsftpd = bt_vsftpd_main()
    cli_vsftpd.LoadConfig_UserDB()




