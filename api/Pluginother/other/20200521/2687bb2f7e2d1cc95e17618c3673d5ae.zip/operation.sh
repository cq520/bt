#!/bin/bash
#错误代码 1101 源目录不存在 1102 目标目录不为空 1103 目标目录已是软连接 1104 目标目录不是软连接

install_path=/www/server/panel/plugin/linksforbt


# current=`date "+%Y-%m-%d_%H%M%S"`  
current=app
LOGDIR=${install_path}/log/
LOGFILE=${LOGDIR}${current}.log

if [ ! -d "${LOGDIR}" ]; then
	mkdir ${LOGFILE}
fi

#判断系统发行版本
Get_Dist_Name()
{
    if grep -Eqii "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
        DISTRO='CentOS'
        PM='yum'
    elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
        DISTRO='RHEL'
        PM='yum'
    elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
        DISTRO='Aliyun'
        PM='yum'
    elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
        DISTRO='Fedora'
        PM='yum'
    elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
        DISTRO='Debian'
        PM='apt'
    elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
        DISTRO='Ubuntu'
        PM='apt'
    elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
        DISTRO='Raspbian'
        PM='apt'
    else
        DISTRO='unknow'
    fi
#    echo $DISTRO;
#	echo $PM

}

Get_Dist_Name


Link(){
#判断目录是否存在
if [ ! -d "${1}" ]; then
	echo 1101
	return 0
fi
#目标目录已是软连接
if [  -L "${2}"  ]; then 
	echo 1103
	return 0
fi
#目标目录不为空
if [ -d "${2}" ] && [ "`ls -A ${2}`" != "" ]; then 
	echo 1102
	return 0
fi

echo "ln -s ${1} ${2} ">> ${LOGFILE} 2>&1
#创建软连接
ln -s ${1} ${2}  >> ${LOGFILE} 2>&1
}

Unlink(){
#删除软连接
	if [ -L "${1}"  ]; then 
		rm -rf ${1} >> ${LOGFILE} 2>&1
	else
		echo 1104
		return 0
	fi
}

#操作判断
if [ "${1}" == 'link' ];then
	Link ${2} ${3}
elif [ "${1}" == 'unlink' ];then
	Unlink ${2}
else
	echo 'Error!';
fi
