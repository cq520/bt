#coding: utf-8
#Author: 山水有相逢 <1757638147@qq.com>

import os,json
os.chdir("/www/server/panel")
import public,psutil,re,sys

class diskquota_main:
    __projects = "/etc/projects"
    __projid = "/etc/projid"
    __conf = "/www/server/panel/plugin/diskquota/conf.json"
    # 取挂载信息
    def GetMountPart(self,get):
        m = {"isset":{},"notset":{}}
        syspart = ["/","/boot"]
        res = psutil.disk_partitions()
        for i in res:
            if i.fstype != "xfs":continue
            if i.mountpoint in syspart:continue
            if "prjquota" in i.opts:
                m["isset"][i.device] = i.mountpoint
            else:
                m["notset"][i.device] = i.mountpoint
        return m

    # 设置磁盘配额
    def SetDiskQuota(self,get):
        if get.act == "start":
            mset = "notset"
            even = "开启"
        else:
            mset = "isset"
            even ="停止"
        mountInfo = self.GetMountPart(get)
        if get.dev in mountInfo[mset].keys():
            fstab = public.readFile("/etc/fstab")
            rep = "%s.*0" % get.dev
            oldc = re.search(rep,fstab).group()
            if not "prjquota" in oldc and get.act == "start":
                newc = oldc.replace("defaults","defaults,prjquota")
                fstab = fstab.replace(oldc,newc)
                public.writeFile("/etc/fstab",fstab)
            if "prjquota" in oldc and get.act == "stop":
                newc = oldc.replace("defaults,prjquota", "defaults")
                fstab = fstab.replace(oldc, newc)
                public.writeFile("/etc/fstab", fstab)
            a,e = public.ExecShell("umount %s" % get.dev)
            if e:
                if "busy" in e:
                    return public.returnMsg(False, "设备繁忙，请关闭终端或停止分区上的应用后再试")
            a,e = public.ExecShell("mount -a")
            if e:
                return public.returnMsg(False, e)
            mountInfo = self.GetMountPart(get)
            if get.dev not in mountInfo[mset].keys():
                public.WriteLog('目录配额', '【 %s 】分区%s磁盘配额'% (get.dev,even))
                return public.returnMsg(True, "【 %s 】分区%s磁盘配额成功" % (get.dev,even))
            else:
                return public.returnMsg(False, "【 %s 】分区%s磁盘配额失败" % (get.dev,even))
        else:
            return public.returnMsg(False, "没有找到该分区【 %s 】，请确认是否已经挂载或文件系统格式是否为xfs" % get.dev)

    # 取所有目录配额
    def GetDirQuota(self,get):
        rconf = self.__readConfig(self.__conf)
        for r in rconf:
            a,e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'report -pbih' %s" % r["mp"])
            if e and not "Success" in e:
                if "No such device" in e:
                    e = re.search("for\s+mount\s+([\/\w\_\-]+):",e).group(1)
                    return public.returnMsg(False, "【%s】分区没有挂载！" % e)
                return public.returnMsg(False, e)
            rep = "\n%s.*" % r["qname"]
            try:
                r["open"] = "0"
                res = re.search(rep,a).group().split()
                if r["bhard"] == res[3] and res[3] != "0":
                    r["open"] = "1"
                if res[5] != "[------]":
                    r["graceTime"] = res[5][1:]+"天"
                else:
                    r["graceTime"] = "未触发宽容期"
                r["use"] = res[1]
            except:
                r["graceTime"] = "未触发宽容期"
        rconf = sorted(rconf, key=lambda d:d["graceTime"], reverse=True)
        return rconf

    def BackConf(self):
        os.system("/usr/bin/cp /etc/projects /tmp/projects_bak ")
        os.system("/usr/bin/cp /etc/projids /tmp/projids_bak ")

    def RestoreConf(self):
        os.system("/usr/bin/cp /etc/projects /tmp/projects_bak ")
        os.system("/usr/bin/cp /etc/projids /tmp/projids_bak ")

    def GetLastId(self):
        try:
            a,e = public.ExecShell("xfs_quota -x -c 'report -pbin' /data|awk '{print $1}'")
            if e and not "Success" in e:
                return public.returnMsg(False, "获取id失败")
            a = a.split()[-1][1:]
            return a
        except:
            return 0


    # 添加目录配额
    def AddDirQuota(self,get):
        rconf = self.__readConfig(self.__conf)
        if get.siteName:
            get.dir = public.M("sites").where("name=?",(get.siteName,)).getField('path')
        if not re.match(get.mp+"/",get.dir):
            return public.returnMsg(False, "设置的目录配额【%s】不在挂载点【%s】内" % (get.dir,get.mp))
        if sys.version_info.major < 3:
            if len(get.qname) < 3 or len(get.qname) > 15:
                print("名称必须大于3小于15个字符串")
                return public.returnMsg(False, '名称必须大于3小于15个字符串')
        else:
            if len(get.qname.encode("utf-8")) < 3 or len(get.qname.encode("utf-8")) > 15:
                print("名称必须大于3小于15个字符串")
                return public.returnMsg(False, '名称必须大于3小于15个字符串')
        for r in rconf:
            if get.qname in r.values():
                return public.returnMsg(False, "目录配额名称已经存在")
            if get.dir in r.values():
                return public.returnMsg(False, "目录配额路径已经存在")
        try:
            l = [get.bsoft,get.bhard]
            for i in range(len(l)):
                if re.search("[mMgG]",l[i]):
                    int(l[i][:-1])
                else:
                    l[i] = l[i]+"M"
            if "." in get.bsoft or "." in get.bhard:
                return public.returnMsg(False, "阈值不能为整数以外的值")
        except:
            return public.returnMsg(False, "阈值不能为整数以外的值")
        get.bsoft = l[0]
        get.bhard = l[1]
        if int(get.bhard[:-1]) <= int(get.bsoft[:-1]):
            return public.returnMsg(False, "锁定阈值不能小于等于告警阈值")
        if get.mp[-1] == "/":
            get.mp = get.mp[:-1]
        mountInfo = self.GetMountPart(get)
        a = ""
        lastid = self.GetLastId()
        for v in mountInfo["isset"].values():
            if get.mp == v:
                did = int(lastid) + 1
                ps = "%s:%s\n" % (did, get.dir)
                pi = "%s:%s\n" % (get.qname, did)
                pso = public.readFile(self.__projects)
                pio = public.readFile(self.__projid)
                if not pso or not pio:
                    os.system("touch %s && touch %s" % (self.__projid,self.__projects))
                pso = public.readFile(self.__projects)
                pio = public.readFile(self.__projid)
                if ps not in pso:public.writeFile(self.__projects,ps,"a+")
                if pi not in pio:public.writeFile(self.__projid,pi,"a+")
                self.BackConf()
                a,e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'project -s %s' %s" % (get.qname,v))
                if e and not "Success" in e:
                    return public.returnMsg(False, e)
                a, e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'report -pbih' %s|awk '{print $1}'" % v)
                if e and not "Success" in e:
                    return public.returnMsg(False, e)
                if get.qname in a:
                    a,e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'limit -p bsoft=%s bhard=%s %s' %s" % (get.bsoft,get.bhard,get.qname,v))
                    if e and not "Success" in e:
                        return public.returnMsg(False, e)
                    a,e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'report -pbih' %s|awk '{print $3}'" % v)
                    if get.bsoft in a:
                        a = 1
                        break
        if a == 1:
            conf = {"qname":get.qname,"dir":get.dir,"id":did,"bsoft":get.bsoft,"bhard":get.bhard,"mp":get.mp,"siteName":get.siteName}
            rconf.append(conf)
            self.__writeConfig(self.__conf,rconf)
            public.WriteLog('目录配额', '【 %s 】设置目录配额成功' % get.dir)
            return public.returnMsg(True, "添加目录配额成功")
        else:
            return public.returnMsg(False, "添加目录配额失败")
    #设置目录配额停起
    def SetDirQuota(self,get):
        rconf = self.__readConfig(self.__conf)
        for r in rconf:
            if get.qname == r["qname"]:
                if get.act == "stop":
                    r["bhard"] = "0"
                    r["bsoft"] = "0"
                a, e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'limit -p bsoft=%s bhard=%s %s' %s" % (r["bsoft"], r["bhard"], get.qname, r["mp"]))
                if e and not "Success" in e:
                    if "invalid project name" in e:
                        return public.returnMsg(False, "没找到该配额名的配置，请删除后重新配置。")
                    return public.returnMsg(False, e)
                a = {"stop": "停止", "start": "开启"}
                public.WriteLog('目录配额', "【 %s 】目录配额%s成功" % (r["qname"],a[get.act]))
                return public.returnMsg(True, "【 %s 】目录配额%s成功" % (r["qname"],a[get.act]))

    # 修改目录配额
    def MoidfyDirQuota(self,get):
        rconf = self.__readConfig(self.__conf)
        for r in rconf:
            if get.qname == r["qname"]:
                r["bhard"] = get.bhard
                r["bsoft"] = get.bsoft
                a, e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'limit -p bsoft=%s bhard=%s %s' %s" % (r["bsoft"], r["bhard"], r["qname"], r["mp"]))
                if e and not "Success" in e:
                    return public.returnMsg(False, e)
                self.__writeConfig(self.__conf,rconf)
                public.WriteLog('目录配额', "【 %s 】目录配额修改成功" % r["qname"])
                return public.returnMsg(True, "【 %s 】目录配额修改成功" % r["qname"])
    # 删除目录配额
    def DelDirQuota(self,get):
        rconf = self.__readConfig(self.__conf)
        for i in range(len(rconf)):
            if get.qname == rconf[i]["qname"]:
                a, e = public.ExecShell("/usr/sbin/xfs_quota -x -c 'limit -p bsoft=0 bhard=0 %s' %s" % (get.qname, rconf[i]["mp"]))
                if e and not "Success" in e:
                    if "invalid project name" in e:
                        pass
                    else:
                        return public.returnMsg(False, e)
                ps = "%s:%s" % (rconf[i]["id"], rconf[i]["dir"])
                pi = "%s:%s" % (rconf[i]["qname"], rconf[i]["id"])
                pl = [{self.__projects:ps},{self.__projid:pi}]
                for p in pl:
                    pd = public.readFile(p.keys()[0])
                    pd = pd.replace(p.values()[0],"")
                    pd = pd.replace("\n", "")
                    s = ""
                    for x in pd.splitlines():
                        if x == "": continue
                        s += x + "\n"
                    pd = s
                    public.writeFile(p.keys()[0],pd)
                del(rconf[i])
                self.__writeConfig(self.__conf, rconf)
                public.WriteLog('目录配额', "【 %s 】目录配额删除成功" % get.qname)
                return public.returnMsg(True, "【 %s 】目录配额删除成功" % get.qname)

    def GetNameOfSites(self,get):
        sites = []
        getsites = public.M('sites').field('name').select()
        for s in getsites:
            sites.append(s["name"])
        return sites

    # 取日志
    def get_logs(self, get):
        import page
        page = page.Page()
        count = public.M('logs').where('type=?', (u'目录配额',)).count()
        limit = 12
        info = {}
        info['count'] = count
        info['row'] = limit
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = get
        info['return_js'] = ''
        if hasattr(get, 'tojs'):
            info['return_js'] = get.tojs
        data = {}

        # 获取分页数据
        data['page'] = page.GetPage(info, '1,2,3,4,5,8')
        data['data'] = public.M('logs').where('type=?', (u'目录配额',)).order('id desc').limit(
            str(page.SHIFT) + ',' + str(page.ROW)).field('log,addtime').select()
        return data

    def __readConfig(self, path):
        if not os.path.exists(path) or not public.readFile(path):
                public.writeFile(path, '[]')
        conf = public.readFile(path)
        return json.loads(conf)

    def __writeConfig(self ,path, data):
        return public.writeFile(path, json.dumps(data))
