#!/usr/bin/python
# coding: utf-8

import sys,os,json,time
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
panel_path = os.path.dirname(os.path.dirname(plugin_path))
# os.chdir(panel_path);

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db

#添加包引用位置
plugin_libs_path = "%s/libs/" % (plugin_path)
sys.path.append(plugin_libs_path)
# 引入扩展包
import utils
import sized_file_adapter

class BaiduNetdisk:
    # 插件目录
    __plugin_path = "%s/" % (plugin_path)
    # 日志目录
    __logs_path = "%s/logs" % (plugin_path)
    # 百度网盘默认根目录
    __basePath = '/apps/宝塔面板网盘助手/'
    __wget_path = 'wget'
    __curl_path = 'curl'

    def  __init__(self):
        reload(utils)
        self.utils = utils.Utils()
        if self.utils.is_win():
            # wget路径
            self.__wget_path = "%s/script/wget.exe" % (panel_path)
            # curl路径
            self.__curl_path = "%s/script/curl.exe" % (panel_path)

    # 获取服务器信息
    def __get_serverid(self):
        import panelAuth
        auth = panelAuth.panelAuth()
        return auth.create_serverid({})

    # 获取插件购买状态
    def __get_payinfo(self):
        import panelPlugin
        plugin = panelPlugin.panelPlugin()
        state = plugin.getEndDate('baidu_netdisk')
        if state in ['未开通','待支付','已到期']:
            return False
        else:
            return True

    # 获取备份根目录
    def __get_base_path(self):
        if self.utils.get_config('base_path') == None or self.utils.get_config('base_path') == "" :
            return self.__basePath
        else:
            return self.utils.get_config('base_path')

    # 获取access_token
    def __get_access_token(self):
        if self.utils.get_config('expires_in') != None and self.utils.get_config('expires_in') < int(time.time()): 
            result = self.__refresh_token()
            if result['code'] == 0:
                return result

        return self.utils.get_config('access_token')

    # 刷新access_token
    def __refresh_token(self):
        url = 'https://lxyit.com/api/bdnetdisk/refreshAccess.html?refresh_token='+self.utils.get_config('refresh_token')

        userinfo = self.__get_serverid()
        if not 'uid' in userinfo:
            return {"code":0,"msg":"请先在【面板设置】中绑定宝塔账号后使用！"}

        data = {
            'username':userinfo['username'],
            'uid':userinfo['uid'],
            'serverid':userinfo['serverid'],
            'address':userinfo['address'],
        }

        result = self.utils.post(url,data)
        try:
            result = json.loads(result)
            if result['code'] == 1:
                access = result['data']
                self.utils.set_config('access_token',access['access_token'])
                self.utils.set_config('refresh_token',access['refresh_token'])
                self.utils.set_config('expires_in',int(time.time()) + int(access['expires_in']) - 3600)
                self.utils.set_config('session_key',access['session_key'])
                self.utils.set_config('session_secret',access['session_secret'])
                return {"code":1,"msg":"授权成功"}
            else:
                return {"code":0,"msg":"授权失败：%s" % (result)}
        except:pass;

        return {"code":0,"msg":"授权失败：%s" % (result)}

    # 请求授权信息
    def get_auth(self):

        userinfo = self.__get_serverid()
        if not 'uid' in userinfo:
            return {"code":2,"msg":"请先在【面板设置】中绑定宝塔账号并重启面板后使用！"}

        # 判断是否需要重新授权
        if self.utils.get_config('expires_in') != None and self.utils.get_config('expires_in') > int(time.time()): 
            return {"code":"0","msg":"已经授权","data":{"base_path":"%s" % (self.__get_base_path())}}
        elif self.utils.get_config('refresh_token') != None:
            result = self.__refresh_token()
            if result['code'] == 1:
                return {"code":"0","msg":"已经授权","data":{"base_path":"%s" % (self.__get_base_path())}}

        url = 'https://lxyit.com/api/bdnetdisk/index.html'
        result = self.utils.post(url,{})

        return json.loads(result)

    # 获取授权信息
    def get_access(self,state):

        url = 'https://lxyit.com/api/bdnetdisk/getAccess.html?state='+state

        userinfo = self.__get_serverid()
        if not 'uid' in userinfo:
            return {"code":2,"msg":"请先在【面板设置】中绑定宝塔账号并重启面板后使用！"}

        data = {
            'username':userinfo['username'],
            'uid':userinfo['uid'],
            'serverid':userinfo['serverid'],
            'address':userinfo['address'],
        }

        result = self.utils.post(url,data)
        try:
            result = json.loads(result)
            if result['code'] == 1:
                access = result['data']
                self.utils.set_config('access_token',access['access_token'])
                self.utils.set_config('refresh_token',access['refresh_token'])
                self.utils.set_config('expires_in',int(time.time()) + int(access['expires_in']) - 3600)
                self.utils.set_config('session_key',access['session_key'])
                self.utils.set_config('session_secret',access['session_secret'])
                return {"code":1,"msg":"授权成功","data":{"base_path":"%s" % (self.__get_base_path())}}
            else:
                return {"code":0,"msg":"授权失败：%s" % (result)}
        except:pass;

        return {"code":0,"msg":"授权失败：%s" % (result)}


    # 获取账号信息
    def get_userinfo(self):
        try:
            url = 'https://pan.baidu.com/rest/2.0/xpan/nas?method=uinfo&access_token='+self.__get_access_token()
            userinfo = self.utils.post(url,{})
            userinfo = json.loads(userinfo)
            # return userinfo
            if userinfo['errno'] == 0:
                url = 'https://pan.baidu.com/api/quota?checkfree=1&checkexpire=1&access_token='+self.__get_access_token()
                diskinfo = self.utils.post(url,{})
                diskinfo = json.loads(diskinfo)
                if diskinfo['errno'] == 0:
                    userinfo['total'] = public.to_size(diskinfo['total'])
                    userinfo['used'] = public.to_size(diskinfo['used'])
                    userinfo['free'] = public.to_size(diskinfo['free'])
                    userinfo['expire'] = diskinfo['expire']
                return {"code":1,"msg":"操作成功","data":userinfo}
        except:pass;
        return {"code":0,"msg":"操作失败"}


    # 获取文件列表
    def get_list(self,path):
        userinfo = self.__get_serverid()
        if not 'uid' in userinfo:
            return {"code":0,"msg":"请先在【面板设置】中绑定宝塔账号后使用！"}

        # if self.__get_payinfo() == False:
            # return {"code":0,"msg":"插件授权异常请检查插件购买情况"}

        # remote_path = "%s%s" % (self.__get_base_path(),path)
        remote_path = path
        url = 'https://pan.baidu.com/rest/2.0/xpan/file?method=list&access_token='+self.__get_access_token()
        data = {"dir":remote_path,"order":"name","web":"web","showempty":1}
        result = self.utils.post(url,data)
        result = json.loads(result)

        if result['errno'] == -9:
            create_result = self.create_dir(remote_path)
            if create_result['errno'] == 0:
                return self.get_list(path)
            else:
                return {"code":0,"msg":"获取文件列表失败"}

        return {"code":"1","msg":"获取文件列表成功","data":result}


    # 上传文件
    def upload_file(self,filename,remote_path='',debug=True):

        if not os.path.exists(filename): return False;
        if remote_path == '' : remote_path = self.__get_base_path()
        remote_path = remote_path + os.path.basename(filename);

        self.utils.logs("★[%s] 开始上传文件 %s 至 %s" % (time.strftime('%Y/%m/%d %X',time.localtime()),filename,remote_path))

        block_list = self.__upload_file_create_block(filename)
        # return block_list

        total_block = len(block_list)
        self.utils.logs('总分片数量:%s 分片大小:%sM' % (total_block,self.utils.get_config('block_size')),debug)

        uploaded_block = 0
        upload_fail_block = 0
        
        # 文件预上传
        self.utils.logs('文件预上传开始',debug)
        precreate = self.__upload_file_pre(filename,remote_path,block_list,'',1,debug)
        if precreate == False or precreate['errno'] != 0:
            self.utils.logs('文件预上传失败')
            # self.utils.logs(precreate)
            return False

        if len(precreate["block_list"]) == 0:
            uploaded_block = total_block

        # 文件分片上传
        self.utils.logs('文件分片上传开始',debug)
        if len(precreate["block_list"]) > 0:
            for block_number in precreate["block_list"]:
                upload_file_block_info = self.__upload_file_block(filename,precreate['uploadid'],remote_path,block_number,1,debug)
                if upload_file_block_info != False and 'md5' in upload_file_block_info:
                    self.utils.logs('第 %s 分片上传成功' % (block_number),debug)
                    uploaded_block = uploaded_block + 1
                else:
                    upload_fail_block = upload_fail_block + 1
                # self.utils.logs("已上传分片数：%s 上传失败分片数：%s" % (uploaded_block,upload_fail_block))
                self.utils.logs("已上传：%.2f%%" % ((uploaded_block*100)/total_block),debug)

        # 文件预上传
        precreate = self.__upload_file_pre(filename,remote_path,block_list,precreate['uploadid'],1,debug)
        if precreate == False or precreate['errno'] != 0:
            self.utils.logs('文件预上传失败')
            # self.utils.logs(precreate)
            return False
        else:
            upload_fail_block = 0
            # 文件分片上传
            if precreate["return_type"] == 1 and len(precreate["block_list"]) > 0:
                for block_number in precreate["block_list"]:
                    upload_file_block_info = self.__upload_file_block(filename,precreate['uploadid'],remote_path,block_number,1,debug)
                    if upload_file_block_info != False and 'md5' in upload_file_block_info:
                        self.utils.logs('第 %s 分片上传成功' % (block_number),debug)
                        uploaded_block = uploaded_block + 1
                    else:
                        upload_fail_block = upload_fail_block + 1
                    # self.utils.logs("已上传分片数：%s 上传失败分片数：%s" % (uploaded_block,upload_fail_block))
                    self.utils.logs("已上传：%.2f%%" % ((uploaded_block*100)/total_block),debug)


        # 远程文件创建
        self.utils.logs('创建远程文件开始',debug)
        create = self.__upload_file_create(filename,precreate['uploadid'],remote_path,1,debug)
        if create == False or create['errno'] != 0:
            self.utils.logs('远程文件创建失败')
            # self.utils.logs(create)
            return False
        else:
            if os.path.basename(filename) != os.path.basename(create['path']):
                self.utils.logs('由于文件名重复百度网盘中文件已更名为：%s' % (os.path.basename(create['path'])))

        return True

    # 文件预上传
    def __upload_file_pre(self,filename,remote_path,block_list,uploadid,trys,debug=True):

        try:
            url = 'https://pan.baidu.com/rest/2.0/xpan/file?method=precreate&access_token='+self.__get_access_token()
            size = os.path.getsize(filename)
            # md5 = public.FileMd5(filename)
            data = {"path":remote_path,"size":size,"isdir":"0","autoinit":1,"block_list":json.dumps(block_list)}
            if uploadid != '':
                data['uploadid'] = uploadid
            # return data
            precreate = self.utils.post(url,data)
            # self.utils.logs(precreate)
            # return precreate
            precreate = json.loads(precreate)
            return precreate
        except Exception as e:
            # self.utils.logs(e)
            if trys <= int(self.utils.get_config('retry_times')):
                self.utils.logs('文件预上传失败，重新预上传',debug)
                trys = trys + 1
                self.__upload_file_pre(filename,remote_path,block_list,uploadid,trys,debug)
            else:
                self.utils.logs('文件预上传失败',debug)
                return False

    # 文件分块上传
    def __upload_file_block(self,filename,uploadid,remote_path,block_number,trys,debug=True):

        try:
            url = 'https://d.pcs.baidu.com/rest/2.0/pcs/superfile2?method=upload&access_token='+self.__get_access_token()
            url += '&type=tmpfile&path=%s&uploadid=%s&partseq=%d' % (remote_path,uploadid,block_number)
            size = os.path.getsize(filename)
            tempfile = self.__upload_file_create_block(filename,block_number)

            import requests
            files = {'file':tempfile}
            headers = {
                "User-Agent":"pan.baidu.com"
            }
            upload=requests.post(url,files=files,params={},headers=headers,timeout=30,stream=True)
            upload = upload.text
            return upload
        except Exception as e:
            self.utils.logs(e)
            if trys <= int(self.utils.get_config('retry_times')):
                self.utils.logs('第 %s 分片上传失败，重新上传' % (block_number),debug)
                trys = trys + 1
                return self.__upload_file_block(filename,uploadid,remote_path,block_number,trys,debug)
            else:
                self.utils.logs('第 %s 分片上传失败' % (block_number),debug)
                return False


    # 远程文件创建
    def __upload_file_create(self,filename,uploadid,remote_path,trys,debug=True):

        try:
            url = 'https://pan.baidu.com/rest/2.0/xpan/file?method=create&access_token='+self.__get_access_token()
            size = os.path.getsize(filename)
            block_list = self.__upload_file_create_block(filename)
            data = {"path":remote_path,"size":size,"isdir":"0","uploadid":uploadid,"block_list":json.dumps(block_list)}
            create = self.utils.post(url,data)
            create = json.loads(create)
            return create
        except:
            if trys <= int(self.utils.get_config('retry_times')):
                self.utils.logs('远程文件创建失败，重新创建',debug)
                trys = trys + 1
                self.__upload_file_create(filename,uploadid,remote_path,trys,debug)
            else:
                self.utils.logs('远程文件创建失败',debug)
                return False


    # 文件分块
    def __upload_file_create_block(self,filename,number=""):
        part_size = int(self.utils.get_config('block_size'))*1024*1024
        total_size = os.path.getsize(filename)
        if number == "":
            blocks = []
            with open(filename, 'rb') as fileobj:
                # part_number = 1
                offset = 0
                while offset < total_size:
                    num_to_upload = min(part_size, total_size - offset)
                    fileobj.seek(offset,0)
                    tempfile = fileobj.read(num_to_upload)
                    blocks.append(self.__md5(tempfile))
                    offset += num_to_upload
                    # part_number += 1
        else:
            fileobj = open(filename, 'rb')
            if total_size - number*part_size > 0:
                num_to_upload = min(part_size, total_size - number*part_size)
                fileobj.seek(number*part_size,0)
            else:
                num_to_upload = 0
            blocks = sized_file_adapter.SizedFileAdapter(fileobj,number*part_size,num_to_upload)
            # from tempfile import NamedTemporaryFile
            # tempfile = NamedTemporaryFile("rb+")
            # tempfile.write(fileobj.read(num_to_upload))
            # tempfile.seek(0)
            # blocks = tempfile
            # fileobj.close()
        return blocks

    # md5序列化
    def __md5(self,text):
        import hashlib
        md5obj = hashlib.md5()
        md5obj.update(text)
        return md5obj.hexdigest()

    # 创建远程目录
    def create_dir(self,path):
        url = 'https://pan.baidu.com/rest/2.0/xpan/file?method=create&access_token='+self.__get_access_token()
        data = {"path":path,"size":"0","isdir":"1"}
        http_body = self.utils.post(url,data)
        http_body = json.loads(http_body)
        return http_body


    # 删除文件
    def delete_file(self,path,trys,debug=True):
        try:
            url = 'https://pan.baidu.com/rest/2.0/xpan/file?method=filemanager&access_token='+self.__get_access_token()
            url += '&opera=delete'
            data = {
                "filelist":json.dumps([path]),
                "async":1
            }
            result = self.utils.post(url,data)
            result = json.loads(result)
            if result['errno'] == 0:
                return True
            else:
                return False
        except:
            if trys <= int(self.utils.get_config('retry_times')):
                self.utils.logs('远程文件删除失败，重新删除',debug)
                trys = trys + 1
                self.delete_file(path,trys,debug)
            else:
                self.utils.logs('远程文件删除失败',debug)
                return False

    # 下载文件
    def download_file(self,fs_id):
        url = 'https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&access_token='+self.__get_access_token()
        url += '&fsids=%s&dlink=1' % ('['+fs_id+']')
        # return url
        result = self.utils.post(url,{})
        result = json.loads(result)
        if result['errno'] == 0:

            if result['list'][0]['size'] < 5*1024*1024:
                #获取下载链接
                import requests
                dlink = requests.get(result['list'][0]['dlink']+'&access_token='+self.__get_access_token(),allow_redirects=False)
                result['list'][0]['dlink'] = dlink.headers['Location']
            else:
                result['list'][0]['dlink'] = result['list'][0]['dlink']+'&access_token='+self.__get_access_token()

            return {"code":"1","msg":"操作成功","data":result['list'][0]}
        else:
            return {"code":0,"msg":"操作失败"}

    # 执行shell
    # def run_shell(self,shell):
    #     import subprocess
    #     cmd = subprocess.Popen(shell, stdin=subprocess.PIPE, stderr=sys.stderr, close_fds=False,
    #         stdout=sys.stdout, universal_newlines=True, shell=True, bufsize=1)
    #     cmd.communicate()
    #     return cmd.returncode

    # 执行shell
    def run_shell(self,command):
        import subprocess
        p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        print(type(p))
        lines = []
        for line in iter(p.stdout.readline, b''):
            line = line.strip().decode("GB2312")
            print(">>>", line)
            lines.append(line)

    # 下载文件到服务器操作
    def download_file_server(self,path,fs_id,task_id):
        if path == '' or fs_id == '' or task_id == '':
            return False
        url = 'https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&access_token='+self.__get_access_token()
        url += '&fsids=%s&dlink=1' % ('['+fs_id+']')
        # return url
        result = self.utils.post(url,{})
        result = json.loads(result)
        if result['errno'] == 0:
            dlink = result['list'][0]['dlink']+'&access_token='+self.__get_access_token()
            temp_log_file = '%s/%s_temp.log' % (self.__logs_path,task_id)
            if self.utils.is_win():
                # self.utils.logs(fs_id)
                shell = "%s --header=\"User-Agent: pan.baidu.com\" \"%s\" -O \"%s/%s\" -o %s" % (self.__wget_path,dlink,path,result['list'][0]['filename'],log_file)
                # shell = '%s -L "%s" -H "User-Agent: pan.baidu.com" -o "%s/%s" > %s/%s.log' % (self.__curl_path,dlink,path,result['list'][0]['filename'],self.__logs_path,task_id)
                # print(shell)
                os.system(shell)
            else:
                # public.ExecShell('curl -L "%s" -H "User-Agent: pan.baidu.com"' % (dlink))
                # os.popen("wget --header=\"User-Agent: pan.baidu.com\" \"%s\" -O \"%s/%s\"" % (dlink,path,result['list'][0]['filename']))
                # os.system("wget --header=\"User-Agent: pan.baidu.com\" \"%s\" -O \"%s/%s\"" % (dlink,path,result['list'][0]['filename']))
                # self.utils.logs("aria2c -U \"pan.baidu.com\" --check-certificate=false -x %s -d \"%s\" -o \"%s\" \"%s\"" % (self.utils.get_config('download_concurrent'),path,result['list'][0]['filename'],dlink))
                os.system("aria2c -U \"pan.baidu.com\" --check-certificate=false -x %s -d \"%s\" -o \"%s\" \"%s\"" % (self.utils.get_config('download_concurrent'),path,result['list'][0]['filename'],dlink))
            if os.path.exists(temp_log_file):
                self.utils.logs(public.readFile(temp_log_file))
                self.utils.remove(temp_log_file)
            return True
        else:
            return False