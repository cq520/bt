#!/usr/bin/python
# coding: utf-8

import sys,os,json,time,shutil
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
panel_path = os.path.dirname(os.path.dirname(plugin_path))

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db

class Utils:

    # 插件配置
    __config = None
    # 插件目录
    __plugin_path = "%s/" % (plugin_path)
    # 百度网盘默认根目录
    __basePath = '/apps/宝塔面板网盘助手/'
    __redirect_uri = "https://lxyit.com/api/bdnetdisk/callback.html"

    def  __init__(self):
        self.__init_config()

    # 初始化配置
    def __init_config(self):
        if self.__config: return;
        self.__config = self.get_config(None,True);

        if self.get_config('file_size') == None :
            self.set_config('file_size', 0);
        if self.get_config('block_size') == None :
            self.set_config('block_size', 4);
        if self.get_config('base_path') == None :
            self.set_config('base_path', "");
        if self.get_config('retry_times') == None :
            self.set_config('retry_times', 3);
        if self.get_config('standalone_directory') == None :
            self.set_config('standalone_directory', 0);
        if self.get_config('download_concurrent') == None :
            self.set_config('download_concurrent', 5);
        if self.get_config('bandwidth_optimization') == None :
            self.set_config('bandwidth_optimization', 0);

        return self.__config

    # 发起post请求
    def post(self,url,data):
        import requests
        import ssl
        if sys.version_info[0] == 2:
            reload(ssl)
        elif sys.version_info[0] == 3:
            import importlib
            importlib.reload(sys)
        try:
            ssl._create_default_https_context = ssl._create_unverified_context
        except:pass
        headers = {'User-Agent':'pan.baidu.com'}
        result = requests.post(url,data=data,verify=True,headers=headers)
        return result.text
        # result = json.loads(result.text)

    def get(self,url,data):
        import requests
        import ssl
        if sys.version_info[0] == 2:
            reload(ssl)
        elif sys.version_info[0] == 3:
            import importlib
            importlib.reload(sys)
        try:
            ssl._create_default_https_context = ssl._create_unverified_context
        except:pass
        headers = {'User-Agent':'pan.baidu.com'}
        result = requests.get(url,data=data,verify=True,headers=headers)
        return result.text
        # result = json.loads(result.text)

    # 修复插件
    def get_fix(self):
        # 安装试试管道刷新组件
        platform = self.get_platform()
        if platform == 'CentOS':
            public.ExecShell('yum install expect-devel -y')
        elif platform == 'CentOS8':
            public.ExecShell('yum install expect -y')
        elif platform == 'Ubuntu':
            public.ExecShell('apt install expect -y')
        elif platform == 'Windows':
            return {"code":1,"msg":"Windows修复完成"}
        else:
            public.ExecShell('apt install expect -y')

        public.ExecShell('pip install pyOpenSSL -I')
        public.ExecShell('pip install requests -I')

        return {"code":1,"msg":"修复完成"}

    # 获取平台信息
    def get_platform(self):
        os_type_text = '';
        import platform
        systype = platform.system()
        if systype == "Windows":
            os_type_text = 'Windows';
        elif systype == "Linux":
            os = platform.linux_distribution()
            os_type = os[0]
            os_ver = os[1]
            if 'CentOS' in os_type:
                if int(os_ver.split('.')[0]) == 8:
                    os_type_text = 'CentOS8'
                else:
                    os_type_text = 'CentOS'
            elif 'Ubuntu' in os_type:
                os_type_text = 'Ubuntu'
            else:
                os_type_text = 'Linux'
        else:
            os_type_text = 'Other'

        return os_type_text

    # 判断是否是Windows平台
    def is_win(self):
        platform = self.get_platform()
        return platform == 'Windows'

    # 执行shell并获取结果
    def run_shell(self,shell):
        result = os.popen(shell)
        text = result.read()
        result.close()
        return text

    # 更新命令行信息获取进程信息(Windows)
    def get_proc_by_cmd(self,cmd):
        import psutil
        cmdline_list = []
        for proc in psutil.process_iter():
            try:
                if not len(proc.cmdline()):
                    pass
                cmdline = ' '.join(proc.cmdline())
                if cmd in cmdline:
                    cmdline_list.append([proc.pid,cmdline])
            except psutil.AccessDenied:
                pass
            except psutil.NoSuchProcess:
                pass
        return cmdline_list

    #文件压缩
    def zip(self,sfile,dfile) :           
        try:
            import zipfile
            filelists = []
            path = sfile;
            if os.path.isdir(sfile): 
                self.get_file_list(sfile, filelists)
            else:
                path = os.path.dirname(sfile)
                filelists.append(sfile)
       
            f = zipfile.ZipFile(dfile,'w',zipfile.ZIP_DEFLATED)
            for item in filelists:
                f.write(item,item.replace(path,''))       
            f.close()   
            return True
        except :
            return False      
    
    #获取所有文件列表
    def get_file_list(self,path,list):
        files = os.listdir(path)
        list.append(path)
        for file in files:
            if os.path.isdir(path + '/' + file):
                self.get_file_list(path + '/' + file, list)
            else:
                list.append(path + '/' + file)

    # 分卷压缩
    def zip_by_volume(self, sfile, dfile, block_size):
        import zipfile

        # 判断是否是zip，不是zip则进行压缩
        if not zipfile.is_zipfile(sfile):
            if not self.zip(sfile,dfile):
                return ''
        else:
            dfile = sfile

        file_size = os.path.getsize(dfile)  # 文件字节数
        path, file_name = os.path.split(dfile)  # 除去文件名以外的path，文件名
        suffix = file_name.split('.')[-1]  # 文件后缀名

        # 小于分卷尺寸则直接返回压缩文件路径
        if file_size <= block_size:
            return dfile
        else:
            fp = open(dfile, 'rb')
            count = file_size // block_size + 1
            # 创建分卷压缩文件的保存路径
            save_dir = path + os.sep + file_name + '.tmp'
            if os.path.exists(save_dir):
                import shutil
                shutil.rmtree(save_dir)
            os.makedirs(save_dir)
            # 拆分压缩包为分卷文件
            for i in range(1, count + 1):
                _suffix = 'z{:0>2}'.format(i) if i != count else 'zip'
                name = save_dir + os.sep + file_name.replace(str(suffix), _suffix)
                f = open(name, 'wb+')
                if i == 1:
                    f.write(b'\x50\x4b\x07\x08')  # 添加分卷压缩header(4字节)
                    f.write(fp.read(block_size - 4))
                else:
                    f.write(fp.read(block_size))
            fp.close()
            # 如果原始文件不是zip文件，则删除临时文件
            if not zipfile.is_zipfile(sfile):
                os.remove(dfile)
            return save_dir

    # 删除文件
    def remove(self,filename):
        try:
            if os.path.exists(filename): os.remove(filename)
        except Exception as e:
            self.logs(e)

    # 递归删除文件夹
    def rmtree(self,dir):
        try:
            if os.path.exists(dir): shutil.rmtree(dir)
        except Exception as e:
            self.logs(e)

    # 打印日志
    def logs(self,msg="",type=True):
        if type :
            print(msg)
        else:
            return msg

    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                default = {
                    "redirect_uri":self.__redirect_uri,
                    "file_size":0,
                    "block_size":4,
                    "base_path":"",
                    "retry_times":3,
                    "standalone_directory":0,
                    "download_concurrent":5,
                    "bandwidth_optimization":0,
                }
                public.writeFile(config_file,json.dumps(default));
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True