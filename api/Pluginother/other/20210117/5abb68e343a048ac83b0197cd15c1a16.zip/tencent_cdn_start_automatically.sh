#!/bin/bash

if [ $1 == "start" ];then
	chmod -Rf 775 /www/server/panel/plugin/tencent_cdn/*.sh
	chmod -Rf 775 /www/server/panel/plugin/tencent_cdn/*.py
	if [ -d "/etc/init.d" ]; then
		cp /www/server/panel/plugin/tencent_cdn/tencent_cdn_init.sh /etc/init.d/tencent_cdn
		chmod -Rf 775 /etc/init.d/tencent_cdn
		chkconfig --add tencent_cdn
		chkconfig --level 2345 tencent_cdn on
		systemctl enable tencent_cdn.service
		/etc/init.d/tencent_cdn start
	else
		if [ -d "/lib/systemd/system" ]; then
			cp /www/server/panel/plugin/tencent_cdn/tencent_cdn /usr/lib/systemd/system/tencent-cdn.service
			systemctl start tencent-cdn.service
			systemctl enable tencent-cdn.service
		fi
	fi
else
	if [ -d "/etc/init.d" ]; then
		/etc/init.d/tencent_cdn stop
		chkconfig --level 2345 tencent_cdn off 
		chkconfig --del tencent_cdn
		systemctl disable tencent-cdn.service
		rm -rf  /etc/init.d/tencent_cdn
	else
		if [ -d "/lib/systemd/system" ]; then
			cp /www/server/panel/plugin/tencent_cdn/tencent_cdn /usr/lib/systemd/system/tencent-cdn.service
			systemctl stop tencent-cdn.service
			systemctl disable tencent_cdn.service
			rm -rf /usr/lib/systemd/system/tencent-cdn.service
		fi
	fi
fi
