import os
import json
import re
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models


def StartCDN(Domain, ID, Key):
    try:
        cred = credential.Credential(ID, Key)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "cdn.tencentcloudapi.com"

        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = cdn_client.CdnClient(cred, "ap-shanghai", clientProfile)

        req = models.StartCdnDomainRequest()
        params = '{"Domain":"'+Domain+'"}'
        req.from_json_string(params)

        resp = client.StartCdnDomain(req)
        cdn_start_result = resp.to_json_string()

    except TencentCloudSDKException as err:
        print(err)


if(os.path.exists('/www/server/panel/plugin/tencent_cdn/config.json')):
    while(1):
        try:
            config = json.load(
                open('/www/server/panel/plugin/tencent_cdn/config.json'))
            cred = credential.Credential(
                config['secretId'], config['secretKey'])
            httpProfile = HttpProfile()
            httpProfile.endpoint = "cdn.tencentcloudapi.com"

            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = cdn_client.CdnClient(cred, "ap-shanghai", clientProfile)

            req = models.DescribeDomainsRequest()
            params = '{}'
            req.from_json_string(params)

            resp = client.DescribeDomains(req)
            results = json.loads(resp.to_json_string())['Domains']
            for result in results:
                if(result['Status'] == 'offline'):
                    UpdateTime = time.mktime(time.strptime(
                        result['UpdateTime'], '%Y-%m-%d %H:%M:%S'))
                    NowTime = time.time()
                    TimeG = NowTime-UpdateTime
                    if(TimeG >= int(config['autoOnline'])*60):
                        if(not result['Domain'] in os.listdir('/www/server/panel/plugin/tencent_cdn/config')):
                            StartCDN(
                                result['Domain'], config['secretId'], config['secretKey'])
                            f = open(
                                '/www/server/panel/plugin/tencent_cdn/plugin.log', 'a')
                            f.write(time.asctime(time.localtime(time.time())) +
                                    ' - '+result['Domain']+': CDN Started.\n')
                            f.close()
                    else:
                        if(not result['Domain'] in os.listdir('/www/server/panel/plugin/tencent_cdn/config')):
                            f = open(
                                '/www/server/panel/plugin/tencent_cdn/plugin.log', 'a')
                            f.write(time.asctime(time.localtime(
                                time.time()))+' - '+result['Domain']+': CDN Off , Will be restarted\n')
                            f.close()

        except TencentCloudSDKException as err:
            print(err)
        time.sleep(int(config['sleeptime'])*60)
else:
    os.system(
        'bash /www/server/panel/plugin/tencent_cdn/tencent_cdn_start_automatically.sh stop')
