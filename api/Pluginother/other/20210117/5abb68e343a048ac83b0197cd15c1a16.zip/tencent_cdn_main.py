#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2020 吴先森 All rights reserved.
# +-------------------------------------------------------------------
# | Author: 吴先森 <i@mr-wu.top>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   腾讯CDN自动上线
# +--------------------------------------------------------------------
import public
import sys
import os
import json
import re
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models

os.chdir("/www/server/panel")

sys.path.append("class/")

if __name__ != '__main__':
    from BTPanel import cache, session, redirect


def try_a(variable, a):
    try:
        if(variable[a] == ''):
            return 0
        else:
            return 1
    except:
        return 0


class tencent_cdn_main:
    __plugin_path = "/www/server/panel/plugin/tencent_cdn/"
    __config = None

    def __init__(self):
        pass

    def _check(self, args):
        return True

    def index(self, args):
        return self.get_logs(args)

    def refresh(self, args):
        a = 0
        apireturn = {"Error": {"Code": "Error", "Message": "致命错误！"},
                     "RequestId": "000-000-000-000"}
        if(args.value == ""):
            return {'message': '错误！值未填写！', 'apireturn': apireturn, 'status': 0}
        if(args.rtype == ""):
            return {'message': '错误！未选择刷新类型！', 'apireturn': apireturn, 'status': 0}
        while(try_a(args.value.split('\n'), a)):
            if(args.rtype == 'url'):
                config = json.load(
                    open('/www/server/panel/plugin/tencent_cdn/config.json'))
                try:
                    cred = credential.Credential(
                        config['secretId'], config['secretKey'])
                    httpProfile = HttpProfile()
                    httpProfile.endpoint = "cdn.tencentcloudapi.com"

                    clientProfile = ClientProfile()
                    clientProfile.httpProfile = httpProfile
                    client = cdn_client.CdnClient(cred, "", clientProfile)

                    req = models.PurgeUrlsCacheRequest()
                    params = '{\"Urls\":[\"'+args.value.split('\n')[a]+'"]}'
                    req.from_json_string(params)

                    resp = client.PurgeUrlsCache(req)
                    apireturn = json.loads(resp.to_json_string())

                except TencentCloudSDKException as err:
                    return {'message': '错误！刷新失败！'+str(err), 'apireturn': str(err), 'status': 0}
            else:
                if(args.ptype == ""):
                    return {'message': '错误！未选择"仅刷新变更资源"或"刷新全部资源"！', 'apireturn': apireturn, 'status': 0}
                config = json.load(
                    open('/www/server/panel/plugin/tencent_cdn/config.json'))
                apireturn = {"Response": {"Error": {"Code": "Error",
                                                    "Message": "致命错误！"}, "RequestId": "000-000-000-000"}}
                try:
                    cred = credential.Credential(
                        config['secretId'], config['secretKey'])
                    httpProfile = HttpProfile()
                    httpProfile.endpoint = "cdn.tencentcloudapi.com"

                    clientProfile = ClientProfile()
                    clientProfile.httpProfile = httpProfile
                    client = cdn_client.CdnClient(cred, "", clientProfile)

                    req = models.PurgePathCacheRequest()
                    params = '{\"Paths\":[\"'+args.value.split(
                        '\n')[a]+'\"],\"FlushType\":\"'+args.ptype+'\"}'
                    req.from_json_string(params)

                    resp = client.PurgePathCache(req)
                    apireturn = json.loads(resp.to_json_string())
                except TencentCloudSDKException as err:
                    return {'message': '错误！刷新失败！'+str(err), 'apireturn': str(err), 'status': 0}
            a += 1
        if ('Error' in apireturn):
            return {'message': '错误！刷新失败！', 'apireturn': apireturn, 'status': 0}
        else:
            return {'message': '刷新缓存成功！', 'apireturn': apireturn, 'status': 1}

    def five_star(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/showed')):
            return 1
        f = open('/www/server/panel/plugin/tencent_cdn/showed', 'a')
        f.write('Thanks')
        f.close()
        return 0

    def get_domains(self, args):
        config = json.load(
            open('/www/server/panel/plugin/tencent_cdn/config.json'))
        apireturn = {"Response": {"Error": {"Code": "Error",
                                            "Message": "致命错误！"}, "RequestId": "000-000-000-000"}}
        try:
            cred = credential.Credential(
                config['secretId'], config['secretKey'])
            httpProfile = HttpProfile()
            httpProfile.endpoint = "cdn.tencentcloudapi.com"

            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = cdn_client.CdnClient(cred, "", clientProfile)

            req = models.DescribeTrafficPackagesRequest()
            params = '{}'
            req.from_json_string(params)

            resp = client.DescribeDomains(req)
            apireturn = json.loads(resp.to_json_string())

        except TencentCloudSDKException as err:
            print(err)
        if (not 'Domains' in apireturn):
            return {'message': '连接到腾讯云失败！请检查您的密钥是否正确', 'apireturn': apireturn, 'status': 0}
        else:
            return {'message': '查询成功！', 'apireturn': apireturn, 'status': 1}

    def whitelist_add(self, args):
        f = open('/www/server/panel/plugin/tencent_cdn/config/'+args.domain, 'w')
        f.write('0000')
        f.close()
        f = open('/www/server/panel/plugin/tencent_cdn/plugin.log', 'a')
        f.write(time.asctime(time.localtime(time.time()))+' - ' +
                args.domain+': Be added to the white list\n')
        f.close()
        return {'message': '成功关闭此域名CDN自动启动服务！', 'status': 1}

    def whitelist_remove(self, args):
        os.remove('/www/server/panel/plugin/tencent_cdn/config/'+args.domain)
        f = open('/www/server/panel/plugin/tencent_cdn/plugin.log', 'a')
        f.write(time.asctime(time.localtime(time.time()))+' - ' +
                args.domain+': Removed from whitelist\n')
        f.close()
        return {'message': '成功启动此域名CDN自动启动服务！', 'status': 1}

    def service_d(self, args):
        if(args.serviceD == 'start'):
            public.ExecShell(
                'bash /www/server/panel/plugin/tencent_cdn/tencent_cdn_start_automatically.sh start')
            result = re.sub("\D", "", os.popen(
                'echo `ps ax | grep -i \'/tencent_cdn/cron.py\' | grep -v grep`').read())
            if(result == ''):
                public.ExecShell(
                    'bash /www/server/panel/plugin/tencent_cdn/tencent_cdn_start.sh &')
                result = re.sub("\D", "", os.popen(
                    'echo `ps ax | grep -i \'/tencent_cdn/cron.py\' | grep -v grep`').read())
                if(result == ''):
                    return {'message': '启动失败！请联系开发者（开发者邮箱: i@mr-wu.top），并且附上您的系统发行版，谢谢！', 'status': 1}
                else:
                    return {'message': '启动成功！但是添加系统启动项失败！', 'status': 1}
            else:
                return {'message': '启动成功！并且已经成功添加到系统启动项！', 'status': 1}
        else:
            public.ExecShell(
                'bash /www/server/panel/plugin/tencent_cdn/tencent_cdn_start_automatically.sh stop')
            result = re.sub("\D", "", os.popen(
                'echo `ps ax | grep -i \'cron.py\' | grep -v grep`').read())
            if(result == ''):
                return {'message': '成功关闭了服务！', 'status': 1}
            else:
                PID = str(os.popen(
                    "echo `ps ax | grep -i 'python /www/server/panel/plugin/tencent_cdn/cron.py' | sed 's/^\([0-9]\{1,\}\).*/\1/g' | head -n 1`").read())
                public.ExecShell('kill -9 '+PID)
                result = re.sub("\D", "", os.popen(
                    'echo `ps ax | grep -i \'/tencent_cdn/cron.py\' | grep -v grep`').read())
                if(result == ''):
                    return {'message': '成功关闭了服务！', 'status': 1}
                else:
                    return {'message': '抱歉！服务似乎关闭失败了！请手动使用SSH检测或联系开发者（i@mr-wu.top）！', 'status': 0}
        return {'message': 'emmm，不知道发生了什么奇怪的bug...请多尝试几次或联系开发者（i@mr-wu.top）', 'status': 0}

    def Delete(self, args):
        if os.path.exists('/www/server/panel/plugin/tencent_cdn/config.json'):
            os.remove('/www/server/panel/plugin/tencent_cdn/config.json')
        return {'message': '删除成功！', 'status': 1}

    def DeleteLog(self, args):
        if os.path.exists('/www/server/panel/plugin/tencent_cdn/plugin.log'):
            os.remove('/www/server/panel/plugin/tencent_cdn/plugin.log')
        return {'message': '删除成功！', 'status': 1}

    def get_whitelist(self, args):
        return os.listdir('/www/server/panel/plugin/tencent_cdn/config')

    def manula(self, args):
        config = json.load(
            open('/www/server/panel/plugin/tencent_cdn/config.json'))
        apireturn = {"Response": {"Error": {"Code": "Error",
                                            "Message": "致命错误！"}, "RequestId": "000-000-000-000"}}
        try:
            cred = credential.Credential(
                config['secretId'], config['secretKey'])
            httpProfile = HttpProfile()
            httpProfile.endpoint = "cdn.tencentcloudapi.com"

            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = cdn_client.CdnClient(cred, "", clientProfile)

            req = models.StopCdnDomainRequest()
            params = '{"Domain":"'+args.domain+'"}'
            req.from_json_string(params)
            if(args.status == 'true'):
                resp = client.StartCdnDomain(req)
            else:
                resp = client.StopCdnDomain(req)
            apireturn = json.loads(resp.to_json_string())

        except TencentCloudSDKException as err:
            print(err)
        if ('Error' in apireturn):
            return {'message': '出现致命错误！', 'apireturn': apireturn, 'status': 0}
        else:
            f = open('/www/server/panel/plugin/tencent_cdn/plugin.log', 'a')
            f.write(time.asctime(time.localtime(time.time()))+' - ' +
                    args.domain+': CDN '+args.status)
            f.close()
            return {'message': '操作成功！如果是开启CDN服务，那么可能还需要5分钟，按钮才会变成绿色', 'apireturn': apireturn, 'status': 1}

    def get_status(self, args):
        result = re.sub("\D", "", os.popen(
            'echo `ps ax | grep -i \'cron.py\' | grep -v grep`').read())
        if(result == ''):
            return {'p_status': 0, 'status': 1}
        else:
            return {'p_status': 1, 'status': 1}

    def save_key(self, args):
        apireturn = {"Response": {"Error": {"Code": "Error",
                                            "Message": "致命错误！"}, "RequestId": "000-000-000-000"}}
        try:
            cred = credential.Credential(args.SecretId, args.SecretKey)
            httpProfile = HttpProfile()
            httpProfile.endpoint = "cdn.tencentcloudapi.com"

            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = cdn_client.CdnClient(cred, "", clientProfile)

            req = models.DescribeDomainsRequest()
            params = '{}'
            req.from_json_string(params)

            resp = client.DescribeDomains(req)
            apireturn = json.loads(resp.to_json_string())
        except TencentCloudSDKException as err:
            print(err)

        if (not 'Domains' in apireturn):
            return {'message': '连接到腾讯云失败！请检查您的密钥是否正确', 'apireturn': apireturn, 'status': 0}

        dict_var = {
            'secretId': args.SecretId,
            'secretKey': args.SecretKey,
            'sleeptime': args.sleeptime,
            'autoOnline': args.autoOnline
        }

        with open('/www/server/panel/plugin/tencent_cdn/config.json', "w") as f:
            json.dump(dict_var, f, indent=2,
                      sort_keys=True, ensure_ascii=False)
        return {'message': '保存成功！', 'status': 1}

    def get_config_main(self, args):
        return json.load(open('/www/server/panel/plugin/tencent_cdn/config.json'))

    def get_logs(self, args):
        if os.path.exists('/www/server/panel/plugin/tencent_cdn/plugin.log'):
            return open('/www/server/panel/plugin/tencent_cdn/plugin.log').read()
        else:
            return 'No Logs'

    def config_exists_main(self, args):
        f = open("/www/server/panel/plugin/tencent_cdn/info.json")
        plugin_config = json.load(f)
        if(public.md5(plugin_config['checks']) == '7922374302e96534b320306ff9671a37'):
            return os.path.exists('/www/server/panel/plugin/tencent_cdn/config.json')
        else:
            return 0

    def __get_config(self, key=None, force=False):
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)

        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    def __set_config(self, key=None, value=None):
        if not self.__config:
            self.__config = {}

        if key:
            self.__config[key] = value

        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
