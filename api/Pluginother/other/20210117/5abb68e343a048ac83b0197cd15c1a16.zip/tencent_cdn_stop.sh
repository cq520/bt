#!/bin/sh
pid=`ps -ef | grep "tencent_cdn/cron.py" | grep -v grep | awk '{print $2}'`
kill $pid