#!/bin/bash

### BEGIN INIT INFO
# Provides:          tencent_cdn
# Required-Start:    $all
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: Tencent Cdn
### END INIT INFO

#chkconfig: 2345 81 96
#description:tencent_cdn

start()
{
	if [ ! -f "/www/server/panel/pyenv/bin/python" ];then
		python /www/server/panel/plugin/tencent_cdn/cron.py &
		exit 0
	else
		/www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/cron.py &
		exit 0
	fi
}

case $1 in
	start):
	start
	;;
	stop):
		pid=`ps -ef | grep "tencent_cdn/cron.py" | grep -v grep | awk '{print $2}'`
		kill $pid
	;;
esac

exit 0