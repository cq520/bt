#!/bin/sh
if [ ! -f "/www/server/panel/pyenv/bin/python" ];then
	python /www/server/panel/plugin/tencent_cdn/cron.py
else
	/www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/cron.py
fi