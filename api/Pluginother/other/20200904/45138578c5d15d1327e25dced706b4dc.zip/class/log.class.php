<?php
 
class ProcessLog
{
    private $_filename; //日志文件名
    private $_filehandle; //文件句柄
 
    public function __construct($fileurl = '')
    {
        empty($fileurl) && die('日志路径不能为空');
        $this->_filename = $fileurl.'/'.'compress-process-log-'.date('YmdHis').'-'.rand(0,99999).'.txt';
        $this->_filehandle = fopen($this->_filename, "a+");
        //$this->init();
    }
 
    /**
     *作用:初始化记录类,写入记录
     *输入:要写入的记录,可以是数组
     *输出:写入成功返回true失败返回false
     */
    public function addLog($log)
    {
        if (empty($this->_filehandle))
        {
            return false;
        }
        $strLog = date("Y-m-d H:i:s") . '  ' . $log . "\r\n";
        //写日志
        fwrite($this->_filehandle, $strLog);
    }

    /**
     *功能: 析构函数，释放文件句柄
     *输入: 无
     *输出: 无
     */
    public function __destruct()
    {
        //关闭文件
        if (!empty($this->_filehandle))
            fclose($this->_filehandle);
    }
}
 
?>