<?php
//图片批量压缩优化
//@stephenzync 大贤<85070645@qq.com>

//防止超时或其他原因导致的停止执行
set_time_limit(0);
ignore_user_abort(true);
date_default_timezone_set('PRC');

require_once('class/log.class.php');
require_once('class/image.class.php');

class bt_main{
    
    private $all_direct = [];
    private $file_log;
    
    function __construct()
    {
        
    }
    
    private function add_directory( $dir, $skip_dirs = [] )
    {
        $curr_dir = new DirectoryIterator($dir);
        foreach ($curr_dir as $file){
            if($file -> isDir() && !$file -> isDot() )
            {
                $dir1 = $dir . '/' . $file -> getFilename();
                $dir2 = $dir1 . '/';
                if(!in_array($dir1,$skip_dirs) && !in_array($dir2,$skip_dirs))
                {
                    $this -> all_direct[] = $dir1;
                    $this -> add_directory( $dir2 , $skip_dirs);                
                }
            }
        }
    }

	//获取phpinfo
	public function compress_img(){

        //获取参数
	    extract(_post());
	    
	    //检查文件夹
        !is_dir($filepath) && $this->response_error('图片源文件夹错误，请确认路径是否正确。');
        
        //检查输出文件夹
        if(!empty($savepath))
        {
            !is_dir($savepath) && $this->response_error('出片输出目录有误，请确认是否正确的目录。');
            !is_writeable($savepath) && $this->response_error('出片输出目录不可写入，权限不足。');
        }
        else
        {
            //没填写输出目录，默认覆盖
            !is_writeable($filepath) && $this->response_error('不能覆盖原文件，权限不足。');
        }
        
        //检查备份目录
        if( !empty($backupath) ) 
        {
            !is_dir($backupath) && $this->response_error('备份目录有误，请确认是否正确的目录。');
            !is_writeable($backupath) && $this->response_error('备份目录不可写入，权限不足。');
        }        
        
        //检查图片尺寸
        (int)$maxwidth < 30 && $maxwidth = 30;
        (int)$maxheight < 30 && $maxheight = 30;
        (int)$maxwidth > 10000 && $maxwidth = 10000;
        (int)$maxheight > 10000 && $maxheight = 10000;
        
        //检查图片质量
        (int)$quality < 30 && $quality = 30;
        (int)$quality > 100 && $quality = 100;
        
        //输出图片类型，空代表按照原类型输出
        !in_array(strtolower($exportype),['jpg','png']) && $exportype = '';
        
        $handle_images = [];
        //是否选择遍历文件夹
        $this -> all_direct[] = $filepath;
        $cycle_directory == 1 && $this -> add_directory($filepath,explode(',',$skip_dir));
        
        foreach($this -> all_direct as $val)
        {
            //处理类型，暂时只支持jpg及png
            foreach(explode('|',$importype) as $evdata)
            {
                if(in_array(strtolower($evdata),['jpg','png','bmp','tif','webp']))
                {
                    //获取需要压缩的图片
                    $imglist = glob($val.'/*.'.strtolower($evdata));
                    if(count($imglist) > 0)
                    {
                        $handle_images = array_merge($handle_images,$imglist);
                    }
                }
            }
        }
        
        count($handle_images) < 1 && $this->response_error('文件夹没有图片，请核对。');
        
	    $this -> file_log = new ProcessLog($savepath);
	    $this -> file_log -> addLog('执行开始...');
        
        //开始压缩
        $image_compress = new ImagesCompress();
        $image_compress -> img_display_quality = $quality;
        
        foreach($handle_images as $hval)
        {
            //处理路径问题
            $hval = str_replace('//','/',$hval);
            
            $this -> file_log -> addLog('开始处理图片：'.$hval);
            $fileinfo = new SplFileInfo($hval); 
            $file_extension = $fileinfo -> getExtension();
            $file_basename = $fileinfo -> getBasename('.'.$file_extension);
            $image_compress -> source_type = $file_extension;
            // //输出图片类型，空代表使用原来的类型
            $img_exportype = empty($exportype) ? $file_extension : strtolower($exportype);
            $image_obj = $image_compress -> setSrcImg($hval,$img_exportype);
            $img_save_path = $fileinfo -> getPathInfo();
            // //替换原来的路径
            !empty($savepath) && $img_save_path = str_replace('__SAVEPATH__'.$filepath,$savepath,'__SAVEPATH__'.$img_save_path);
            
            // //备份文件
            if( !empty($backupath) )
            {
                $backup_file = str_replace('__SAVEPATH__'.$filepath,$backupath,'__SAVEPATH__'.$hval);
                $backup_file_info = new SplFileInfo($backup_file);
                $backup_file_path = $backup_file_info -> getPathInfo();
                //创建目录
                !file_exists($backup_file_path) && mkdir($backup_file_path,755,true);
                if(!copy($hval,$backup_file))
                {
                    $this->response_error('文件'.$hval.'备份失败！程序终止。');
                }
            }   
            
            $dst_image = $img_save_path.'/'.$file_basename.'.'.$img_exportype;
            $image_compress -> setDstImg($dst_image);
            $result = $image_compress -> createImg($maxwidth,$maxheight);
            
            $result && $this -> file_log -> addLog('文件压缩成功：'.$dst_image);

        }
        $this -> file_log -> addLog('所有文件压缩完毕，共处理了'. count($handle_images) .'个图片文件。');
        echo json_encode(array('error' => 0, 'msg' => '压缩操作完毕！'));
        exit;
	}
	
	//返回错误，记录日志
	public function response_error($err_text)
	{
	    is_object($this -> file_log) && $this -> file_log -> addLog($err_text);
	    echo json_encode(array('error' => 1, 'msg' => $err_text));
	    exit;
	}
}


?>