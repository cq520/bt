#!/usr/bin/python3
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔第三方应用开发DEMO
# +--------------------------------------------------------------------
import public
import sys
import os
import os.path
import json
import time
import hashlib
import panelTask
import platform
import string
# import MySQLdb
# import sqlite3

t = panelTask.bt_task()

if sys.version[0:1] == '2':
    import ConfigParser

    # 解决ConfigParser小写问题
    class real_conf(ConfigParser.ConfigParser):
        def __init__(self, defaults=None):
            ConfigParser.ConfigParser.__init__(self, defaults=None)

        def optionxform(self, optionstr):
            return optionstr

if sys.version[0:1] == '3':
    import configparser
    # 解决ConfigParser小写问题

    class real_conf(configparser.ConfigParser):
        def __init__(self, defaults=None):
            configparser.ConfigParser.__init__(self, defaults=None)

        def optionxform(self, optionstr):
            return optionstr
# 设置运行目录
panelPath = os.getenv('BT_PANEL')
panelPath = panelPath if panelPath else "/www/server/panel"
os.chdir(panelPath)
# os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")

#from common import dict_obj
#get = dict_obj();


# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 设置缓存(超时10秒) cache.set('key',value,10)
    # 获取缓存 cache.get('key')
    # 删除缓存 cache.delete('key')

    # 设置session:  session['key'] = value
    # 获取session:  value = session['key']
    # 删除session:  del(session['key'])


class btgitea_main:
    __config = ""
    __exe_name = "gitea"
    __plugin_path = panelPath+"/plugin/btgitea/"
    __custom_path = panelPath+"/plugin/btgitea/custom/"
    __public_path = __custom_path+"public/"
    __temp_path = __custom_path+"templates/"
    __config_path = __custom_path+"conf/app.ini"
    __config_tmp = __custom_path+"conf/app_tmp.ini"
    __run_log = __plugin_path+"log/gitea_service.log"
    # 构造方法

    def __init__(self):
        systemOs = self.UsePlatform(self)
        soft_name = self.__exe_name
        if(systemOs == 'windows'):
            self.__exe_name = soft_name+'.exe'
        pass
        #备份必要文件



    # 自定义访问权限检查
    # 一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    # 如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    # 如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    # 示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    # 可通过args.fun获取被请求的方法名称
    # 可通过args.client_ip获取客户IP
    # def _check(self,args):
        #token = '123456'
        #limit_addr = ['192.168.1.2','192.168.1.3']
        # if args.token != token: return public.returnMsg(False,'Token验证失败!')
        # if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
        # return redirect('/login')
        # return True
    # 判断系统是linux还是windows
    def UsePlatform(self, args):
        sysstr = platform.system()
        if sysstr == "Windows":
            return 'windows'
        elif sysstr == "Linux":
            return 'linux'
        else:
            return 3

    # 判断操作系统位数
    def UsePlaceform(self, args):
        import struct

        return struct.calcsize("P")*8

      # 在线安装主程序
    def install(self, args):
        tasks = ''
        taskName = self.__exe_name
        isRunTask=self.__getTaskStatus(taskName)
        if isRunTask[0] != 1:
            return {'status': 0, 'msg': '安装任务已在队列中','task_id':isRunTask[1]}

        if(os.path.exists(self.__plugin_path+self.__exe_name)):
            os.remove(self.__plugin_path+self.__exe_name)

        systemOs = self.UsePlatform(self)
        sysplace = self.UsePlaceform(self)

        geturl = self.__get_config(self, 'get_url')
        file_names = self.__get_config(self, 'file_names')

        if(systemOs != 3 and sysplace == 32 or sysplace == 64):
            tasks = t.create_task('安装 [' + taskName + '-1.9]', 1, geturl+file_names[systemOs]
                                  ['x'+str(sysplace)], self.__plugin_path+self.__exe_name)

        runTask=self.__getTaskStatus(taskName)

        return {'status': 1, 'msg': '已将安装任务添加到队列', 'task': tasks,'task_id':runTask[1]}

    def __getTaskStatus(self, taskName):
        result = public.M('task_list').where(
            "status!=?", ('1',)).field('status,name,id').select()

        status = 1
        task_id=0
        for task in result:
            name = public.getStrBetween('[', ']', task['name'])
            if not name:
                continue
            if name.split('-')[0] == taskName:
                status = int(task['status'])
                task_id=int(task['id'])
        return status,task_id
    # 上传站点logo

    def logo_upload(self, args):
        if not 'upload_type' in args:
            args.upload_type = ''
        try:
            from flask import request
            file = request.files['import']

            filename = self.__public_path + 'img/gitea-logo'+file.filename[-4:]
            file.save(filename)
            return {'status': 1, 'msg': '上传成功'}
        except IOError:
            return {'status': 0, 'msg': '无效文件'}
        return {'status': 0, 'msg': '无效文件'}

    # 上传安装包

    def upload_install(self, args):
        if self.__getTaskStatus(self.__exe_name)[0] != 1:
            return {'status': 0, 'msg': '安装任务已在队列中,请取消安装队列再手动安装！'}
        filename = self.__plugin_path + '/tmp/import'

        try:
            from flask import request
            file = request.files['import']

            if file.filename[-7:] == '.tar.gz':
                filename = filename+file.filename[-7:]
            elif file.filename[-4:] == '.zip':
                filename = filename+file.filename[-4:]

            file.save(filename)
            is_exe = os.access(r"%s" % (filename), os.X_OK)

            if file.filename[-7:] == '.tar.gz' or file.filename[-4:] == '.zip':
                if file.filename[-4:] == '.zip':
                    filename = self.__plugin_path + '/tmp/import.zip'
                os.system('rm -rf ' + self.__plugin_path + '/tmp/import')
                os.system('mkdir -p ' + self.__plugin_path + '/tmp/import')
                import panelTask

                panelTask.bt_task()._unzip(filename, self.__plugin_path +
                                           '/tmp/import', '', '/dev/null')
                success, failed = public.ExecShell(
                    'find %s/tmp/import -name gitea1' % self.__plugin_path)
                # 先按操作系统位数进行挑选
                sysplace = self.UsePlaceform(self)
                # 排除windows
                systemOs = self.UsePlatform(self)
                if(systemOs != 3 and sysplace == 32 or sysplace == 64):

                    if sysplace == 32:
                        success_32, failed = public.ExecShell(
                            'find %s/tmp/import -name \'gitea*386\'' % self.__plugin_path)
                        if success_32.strip() != '':
                            success = success_32
                    if sysplace == 64:
                        success_64, failed = public.ExecShell(
                            'find %s/tmp/import -name \'gitea*amd64\'' % self.__plugin_path)
                        if success_64.strip() != '':
                            success = success_64

                if success.strip() != '':
                    os.system('mv -f %s %s' % (success.strip(),
                                               self.__plugin_path+self.__exe_name))
                    os.system('chown root:root ' +
                              self.__plugin_path+self.__exe_name)
                    os.system('chmod +x ' + self.__plugin_path+self.__exe_name)
                    os.system('rm -rf ' + self.__plugin_path + '/tmp/import')
                    os.system('rm -rf ' + filename)
                    if os.path.isfile(self.__plugin_path+self.__exe_name):
                        public.ExecShell("%soperation.sh service %s" %
                                         (self.__plugin_path, 'start'))
                        return {'status': 1, 'msg': '安装成功！'}

            # 如果不是压缩包则判断是否可执行文件
            elif(is_exe == True):
                os.system('mv -f %s %s' %
                          (filename, self.__plugin_path+self.__exe_name))
                os.system('chown root:root ' +
                          self.__plugin_path+self.__exe_name)
                os.system('chmod +x ' + self.__plugin_path+self.__exe_name)
                os.system('rm -rf ' + self.__plugin_path + '/tmp/import')
                os.system('rm -rf ' + filename)
                if os.path.isfile(self.__plugin_path+self.__exe_name):
                    public.ExecShell("%soperation.sh service %s" %
                                     (self.__plugin_path, 'start'))
                    return {'status': 1, 'msg': '安装成功！'}
            else:
                return {'status': 0, 'msg': '无效文件或未找到gitea', 'aa': file.filename}

        except IOError:
            return {'status': 0, 'msg': '无效文件或未找到gitea'}
        return {'status': 0, 'msg': '无效文件或未找到gitea'}

    # 验证文件是否完整
    def md5sum(self, args):
        if(os.path.isfile(self.__plugin_path+self.__exe_name)):
            files_md5 = self.__get_config(self, 'file_md5')

            fmd5 = public.FileMd5(self.__plugin_path+self.__exe_name)
            if fmd5 in files_md5:
                return 1
            else:
                return -3
        return -3
        
        
    #读取文件最后几行
    def get_last_n_lines(self,logfile, n):
        # n = string.atoi(n)
        n = int(n)
        blk_size_max = 4096
        n_lines = []
        with open(logfile, 'rb') as fp:
            fp.seek(0, os.SEEK_END)
            cur_pos = fp.tell()
            while cur_pos > 0 and len(n_lines) < n:
                blk_size = min(blk_size_max, cur_pos)
                fp.seek(cur_pos - blk_size, os.SEEK_SET)
                blk_data = fp.read(blk_size).decode() #兼容python3 添加decode
                # assert len(blk_data) == blk_size  #断言报错 直接注释居然能正常运行
                lines = blk_data.split('\n')
    
                # adjust cur_pos
                if len(lines) > 1 and len(lines[0]) > 0:
                    n_lines[0:0] = lines[1:]
                    cur_pos -= (blk_size - len(lines[0]))
                else:
                    n_lines[0:0] = lines
                    cur_pos -= blk_size
    
                fp.seek(cur_pos, os.SEEK_SET)
    
        if len(n_lines) > 0 and len(n_lines[-1]) == 0:
            del n_lines[-1]
        return n_lines[-n:]

    # 获取服务状态
    def get_status(self, args):
        to_status = ''
        run_logs = ''
        is_install = 1
        # systemOs=self.UsePlatform(self)
        systemOs = self.UsePlaceform(self)
        logs_file = self.__run_log
        if os.path.isfile(logs_file):
            # 宝塔封装的 public.ReadFile 不适合读取大文件
            # success, failed = public.ExecShell('tail -n 1000 %s' % logs_file)
            # if success.strip() != '':
            #     run_logs = success.strip()
            #读取文件最后500行
            run_logs = self.get_last_n_lines(logs_file,'300')
            run_logs.reverse()
            # run_logs='\n'.join(run_logs)
            run_logs="\n".join('%s' %id for id in run_logs)
            # \u001b[36m
            run_logs=run_logs.replace(u'\u001b[36m', '')
            # \u001b[0m
            run_logs=run_logs.replace(u'\u001b[0m', '')
            # \u001b[32m
            run_logs=run_logs.replace(u'\u001b[32m', '')
            # \u001b[1m
            run_logs=run_logs.replace(u'\u001b[1m', '')
            # \u001b[1;32m
            run_logs=run_logs.replace(u'\u001b[1;32m', '')
            # \u001b[1;36m
            run_logs=run_logs.replace(u'\u001b[1;36m', '')
            # \u001b[1;41m
            run_logs=run_logs.replace(u'\u001b[1;41m', '')
            
            
            
        #赋予可执行权限
        is_exists_file=os.path.exists(r"%s%s" % (self.__plugin_path,self.__exe_name))
        if is_exists_file==True :
            is_exe = os.access(r"%s%s" % (self.__plugin_path,self.__exe_name), os.X_OK)
            if is_exe!=True:
                os.system('chown root:root ' + self.__plugin_path+self.__exe_name)
                os.system('chmod +x ' + self.__plugin_path+self.__exe_name)


        if not 'status' in args:
            args.status = 0
        callback=args.status
        
        args.status = public.ExecShell(
            self.__plugin_path+"btgitservice get_status ")
        
        to_status = args.status[0][0:1]
        
        # if(self.md5sum(self)):
        #     is_install = int(self.md5sum(self))
        # else:
        #     is_install = 0

        
        if self.__getTaskStatus(self.__exe_name)[0] != 1:
            is_install = -2  # 安装中
        else:
          procedure=public.ExecShell("%sgitea -v " %
                          (self.__plugin_path))
          if procedure[0] == '' :
              is_install=0
          else:
              is_install=1


        # 读取备案号
        temp = {}
        temp['keep_on_record'] = public.ReadFile(
            self.__temp_path+'base/keep_on_record.tmpl')
        

        # #链接mysql 
        # # 打开数据库连接
        # db = MySQLdb.connect("localhost", "gitea", "8RxkfrsaN2C283Sf", "gitea", charset='utf8' )
        # # 使用cursor()方法获取操作游标 
        # cursor = db.cursor()
                
        # # 使用execute方法执行SQL语句
        # cursor.execute("SELECT lower_name,name from user where 1 ")

        # # 使用 fetchone() 方法获取一条数据
        # data = cursor.fetchone()

        # # 关闭数据库连接
        # db.close()
        


        # #链接sqlite3数据库
        # conn = sqlite3.connect('test.db')
        # c = conn.cursor()
        # print "Opened database successfully"

        # c.execute("INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) \
        #       VALUES (1, 'Paul', 32, 'California', 20000.00 )")

        # c.execute("INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) \
        #       VALUES (2, 'Allen', 25, 'Texas', 15000.00 )")

        # c.execute("INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) \
        #       VALUES (3, 'Teddy', 23, 'Norway', 20000.00 )")

        # c.execute("INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) \
        #       VALUES (4, 'Mark', 25, 'Rich-Mond ', 65000.00 )")

        # conn.commit()
        # print "Records created successfully"
        # conn.close()


        # return {'status': to_status, 'sys': systemOs, 'temp': temp, 'is_install': is_install,'sts':callback, 'run_logs': run_logs,'user':data}
        return {'status': to_status, 'sys': systemOs, 'temp': temp, 'is_install': is_install,'sts':callback, 'run_logs': run_logs}

    # 设置服务状态(启动 停止 重启 重载)
    def set_status(self, args):
        if not 'status' in args:
            args.status = 0
        args.status = str(args.status)
        # args.status = public.ExecShell(self.__plugin_path+"centos_giteaser get_status ")
        #获取当前主程序状态
        public.ExecShell("%soperation.sh service %s" %
                         (self.__plugin_path, args.status))


        procedure=public.ExecShell("%sgitea -v " %
                         (self.__plugin_path))
        if procedure[0] == '' :
            args.status=0
        else:
          edition=procedure[0].split(' ')[2].split()[0].split('.')
          version=edition[0]+'.'+edition[1]
          if not os.path.exists('%s\/base\/temp%s' % (self.__temp_path,version)) :
              public.ExecShell("rm -rf %s/base/temp* " % (self.__temp_path))
              
              import panelTask
              panelTask.bt_task()._unzip('%stemp/zip/base%s.zip' % (self.__plugin_path,version), '%sbase/'%(self.__temp_path), '', '/dev/null')


        
        

        return {'status': args.status}

    def get_sysset(self, args):
        # 生成配置文件副本(正本python2无法操作 很无赖)
        public.ExecShell(self.__plugin_path+"operation.sh cache ")
        # 不同版本引用不同类库处理
        config = real_conf()
        config.read(self.__config_tmp)  # python2
        sysset = {}
        # 获取所有的section
        sections = config.sections()
        for sec in sections:
            item_s = {}
            items = config.items(sec)
            for inx, item in enumerate(items):
                item_s.update({item[0]: item[1]})
            sysset.update({sec: item_s})

        return {'sysset': sysset}
    # 保存设置

    def save_sysset(self, args):
        if not 'callback' in args:
            args.callback = ''
        if not 'sysset' in args:
            args.sysset = {}
        public.ExecShell(self.__plugin_path+"operation.sh cache ")
        sysset = json.loads(args.sysset)
        # 不同版本引用不同类库处理
        config = real_conf()
        config.read(self.__config_tmp)  # python2
        # sysset={}
        # 获取所有的section
        test_output = {}
        # 没有section的
        for sec in sysset:

            if not config.has_section(sec):
                config.add_section(sec)
                pass
            test_output[sec] = {}
            for opt in sysset[sec]:
                test_output[sec][opt.upper()] = str(sysset[sec][opt])
                config.set(sec, opt.upper(), sysset[sec][opt])
                # if not config.has_option(sec,opt.upper()):
                # wconfig.set(sec, opt.upper(), sysset[sec][opt])

        config.write(open(self.__config_tmp, "w"))
        # 从缓存副本覆盖正本
        public.ExecShell(self.__plugin_path+"operation.sh reduction ")

        return public.returnMsg(True, test_output)
    # 保存模板配置

    def save_temp(self, args):
        if not 'callback' in args:
            args.callback = ''
        if not 'temp' in args:
            args.temp = {}
        args.temp = json.loads(args.temp)
        test_output = {}

        public.WriteFile(
            self.__temp_path+'base/keep_on_record.tmpl', args.temp['keep_on_record'])
        return {'status': 1}

    # 清理运行日志
    def clear_runlog(self, args):
        public.ExecShell('cat /dev/null > %s' % self.__run_log)
        return public.returnMsg(True, '清理成功')
    # 获取面板日志列表
    # 传统方式访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    # 使用动态路由模板输出： /demo/get_logs.html
    # 使用动态路由输出JSON： /demo/get_logs.json

    def get_logs(self, args):
        filename = self.__run_log
        if os.path.isfile(filename):
            # 宝塔封装的 public.ReadFile 不适合读取大文件
            success, failed = public.ExecShell('tail -n 1000 %s' % filename)
            if success.strip() != '':
                return public.returnMsg(True, success.strip())
            return public.returnMsg(True, '暂无运行日志')

    # 读取配置项(插件自身的配置文件)
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_config(self, args, key=None, force=False):
        # 判断是否从文件读取配置

        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)
        # 取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    # 设置配置项(插件自身的配置文件)
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __set_config(self, args, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config:
            self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
