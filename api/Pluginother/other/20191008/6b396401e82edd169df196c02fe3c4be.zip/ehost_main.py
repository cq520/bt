#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发DEMO
#+--------------------------------------------------------------------
import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public



#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

class ehost_main:
    __plugin_path = "/www/server/panel/plugin/ehost/"
    __host_path = "/etc/hosts"
    __config = None

    #构造方法
    def  __init__(self):
        pass


    #读取linux 的host 文件
    def GetHostConfig(self,get  ):
        Hosts=public.ReadFile(self.__host_path)
        Domains = []

        # 按行切割配置文件
        host = Hosts.split("\n")
        # 使用空格切割每行中的数据
        for _host in host:
            info = _host.split(" ")
            i= 0
            for domain in info:
                if domain ==" " or domain =="":
                    pass
                else:
                    _domain = {"host": "", "ip": ""}
                    if i == 0:
                        ip = domain
                    else:
                        _domain["host"] = domain
                        _domain["ip"] = ip
                    if _domain["ip"] == "":
                        pass
                    else:
                        Domains.append(_domain)
                i = i + 1
        num= len(Domains)
        return {"status":"succecss","domains":Domains,"num":num}



    # 添加域名记录
    def AddDomainConfig(self,get):
        if self.CheckDomainExist(get.domain):
            return {"status": "error", "msg": "试图添加的域名[" + get.domain + "]已经存在！"}

        #遍历配置文件 寻找是否存在相同的 ip 地址
        Hosts = public.ReadFile(self.__host_path)
        # 按行切割配置文件
        host = Hosts.split("\n")
        lip = -1
        i = 0
        # 使用空格切割每行中的数据
        for _host in host:
            ip = _host.split(" ")
            if get.ip == ip[0]:
                lip = i
                pass
            else:
                i = i+1
        if lip == -1:
            Hosts = Hosts + "\n" + get.ip + "  "+get.domain
            public.WriteFile(self.__host_path,Hosts)
        else:
            host[lip] = host[lip] + "  "+get.domain
            num = len(host)-1
            i = 0
            NHosts = ""
            while i!=num:
                NHosts = NHosts + host[i] + "\n"
                i = i +1
            public.WriteFile(self.__host_path, NHosts)
        return {"status": "success", "msg": "域名[" + get.domain + "]添加成功！"}


    # 删除域名记录
    def DelDomainConfig(self,get):
        if not self.CheckDomainExist(get.domain):
            return {"status": "error", "msg": "试图删除的域名[" + get.domain + "]不存在！"}
        else:
            # 遍历找到当前域名所在的位置
            Hosts = public.ReadFile(self.__host_path)
            Domains = []
            NHosts = ""
            # 按行切割配置文件
            host = Hosts.split("\n")

            # 使用空格切割每行中的数据
            for _host in host:
                info = _host.split(" ")
                i = 0
                m = -1
                for domain in info:
                    if get.domain == domain:
                        info[i] = ""
                        m = i
                    i = i +1
                num = len(info)
                line = ""
                i = 0
                #组装当前行的数据
                while i != num:
                    line = line + info[i]
                    if i!= m :
                        line = line + " "
                    i = i + 1
                NHosts = NHosts + line + "\n"
            public.WriteFile(self.__host_path,NHosts)
            return {"status": "success", "msg": "域名[" + get.domain + "]删除成功！"}





    # 修改域名记录
    def EditDomainConfig(self,get):
        if not self.CheckDomainExist(get.olddomain):
            return {"status": "error", "msg": "试图修改的域名[" + get.olddomain + "]不存在！"}
        else:
            olddomain = public.dict_obj()
            newdomain = public.dict_obj()
            olddomain.domain = get.olddomain
            olddomain.ip = get.ip
            newdomain.domain = get.newdomain
            newdomain.ip = get.ip
            self.DelDomainConfig(olddomain)
            res=self.AddDomainConfig(newdomain)
            if res["status"]=="success":
                return {"status": "success", "msg": "域名[" + get.olddomain + "]修改成功！"}
            else:
                return res



    # 判断域名是否存在
    def CheckDomainExist(self,cdomain):
        # 获得当前配置文件下的所有域名
        Domains = self.GetHostConfig("")
        for domain in Domains["domains"]:
            if domain["host"] == cdomain:
                return True
        return False





