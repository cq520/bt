//定义窗口尺寸
$('.layui-layer-page').css({ 'width': '880px' });
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});
//第一次打开窗口时调用
get_index();
function  get_index() {
    var index =  layer.msg('加载最新列表',{icon:16});
    request_plugin('get_web_list',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        console.log(res);
        var list = res.data;
        var content = "";
        for(var i in list){
            content +=    "<tr>  " +
                "<td>"+list[i]['host']+"</td>  " +
                // "<td>"+list[i]['type']+"</td>  " +
                "<td>"+list[i]['status']+"</td>  " +
                "<td>"+list[i]['path']+"</td>  " +
                "<td> <a class='btn btn-success btn-xs' target='_blank' href='http://"+list[i]['host']+"/sitemap.xml'>sitemap</a>  <a class='btn btn-success btn-xs' target='_blank' href='http://"+list[i]['host']+"/robots.txt'>robots</a>  <button onclick='show_edit(this)'  data-path = '"+list[i]['path']+"'   data-sm = '"+list[i]['sm_api']+"'  data-baidu = '"+list[i]['baidu_api']+"'  data-index='"+list[i]['id']+"'  data-host = '"+list[i]['host']+"' class='btn btn-primary btn-xs'>完善信息</button> &nbsp; <button  data-index='"+list[i]['id']+"'  onclick='del_web(this)' class='btn btn-xs'>删除</button></td></tr>";
        }
        var html  =  "<div class='u_main'>" +
            "<button class='btn btn-success btn-sm' onclick='sync_data()' >   <i class='fa fa-refresh'></i>   同步宝塔网站 </button> &nbsp;" +
            "<a class='btn btn-success btn-sm' onclick='backup()' >   <i class='fa fa-download'></i>   备份配置 </a> &nbsp;" +
            "<a class='btn btn-success btn-sm' onclick='recover()' >   <i class='fa fa-coffee'></i>   恢复配置 </a> &nbsp;" +
            "* 【此插件依赖PHP7.1】 【建议升级前备份配置，升级后恢复配置】"+
            "<table style='margin-top: 15px' class='table table-hover table-bordered '>" +
            "<thead><th>网站</th>   <th>状态</th>    <th>路径</th>  <th width='250'>操作栏</th></thead>" +
            "<tbody>" +
            content+
            "</tbody>"+
            "</table>" +
            "</div>";
        $('.plugin_body').html(html);
    });
}

/**
 * 备份配置
 */
function backup() {
    request_plugin('backup',{},function (res) {
        tip(res);
    })
}
function recover() {
    layer.confirm('<span class="red">当前配置将会被备份配置覆盖，是否要恢复？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('recover',{},function (res) {
            layer.close(index);
            tip(res,function () {
                get_index();
            });

        })
    });
}
function sync_data() {
    var index =  layer.msg('正在同步',{icon:16});
    request_plugin('sync_data',{},function (res) {
        layer.close(index);
        layer.msg('同步完成!',{icon:1},function () {
            get_index();
        });
    })
}
function show_edit(obj) {
    var host =  $(obj).attr('data-host');
    var id =  $(obj).attr('data-index');
    var baidu_api = $(obj).attr('data-baidu');
    var sm_api = $(obj).attr('data-sm');
    var path = $(obj).attr('data-path');
    layer.open({
        title:'完善信息页面',
        type: 1,
        area: ['620px', '400px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content: '<div style="margin-top: 15px;margin-left: 15px" class="u_main layer-modal">' +
            '<input type="hidden" name="id" value="'+id+' ">'+

            '<p><label>域名</label><input name="host"   value="'+host+'" class="bt-input-text"></p>' +

            '<p><label>路径</label><input placeholder="请输入网站路径" value="'+path+'"  name="path" class="bt-input-text"></p>' +
            '<p><label></label>路径说明:此路径是sitemap.xml保存的路径,一般是网站的运行目录.</p>' +

            '<p><label>百度普通收录</label><input placeholder="请输入百度普通收录API" value="'+baidu_api+'" name="baidu_api" class="bt-input-text"></p>' +
            '<p><label>神马推送</label><input placeholder="请输入神马推送API" value="'+sm_api+'"  name="sm_api" class="bt-input-text"></p>' +
            '<p><label></label><a class="btlink" target="_blank" href="https://www.waytomilky.com/archives/1950.html">如何获取?</a></p>' +
            '<p><button style="margin-right: 77px;"  class="btn btn-success pull-right" onclick="edit_web()">提交</button></p>' +
            '</div>'
    });
}
function edit_web() {
    var id   =  $("input[name = id]").val();
    var host =  $("input[name = host]").val();
    var baidu_api =  $("input[name = baidu_api]").val();
    var sm_api = $("input[name = sm_api]").val();
    var path = $("input[name = path]").val();
    request_plugin('edit_web',
        {id:id,host:host,path:path,baidu_api:baidu_api,sm_api:sm_api},
        function (res) {
            if(res.code == 1){
                layer.close(layer.index);
                get_index();
            }
            tip(res);
        });
}
function del_web(obj) {
    layer.confirm('<span class="red">确定要删除么？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        var id =  $(obj).attr('data-index');
        request_plugin('del_web',
            {id:id},
            function (res) {
                tip(res,function () {
                    layer.close(index);
                    get_index();
                });
            });
    });
}
function get_act() {
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        layer.close(index);
        var op = '';
        var data = res.data;
        for(var i in  data){
            op+="<option>"+data[i].host+"</option>";
        }
        var html = '<div class="u_main">' +
            '<p> <label>协议</label> <select name="protocol" class="bt-input-text"> <option value="http://">http://</option> <option value="https://">https://</option> </select> </p>' +
            '<p> <label>网站</label> <select onchange="remember(this)"  name="host" class="bt-input-text"> '+op+' </select> </p>' +
            '<p> <label>抓取方式</label> <select   name="way" class="bt-input-text"> ' +
            ' <option value="1"> 首页抓取 </option>  ' +
            ' <option value="2">多层抓取(手动抓取最长时间10分钟，建议添加为[定时任务]</option>  ' +
            // ' <option value="3">三级抓取(手动抓取时间漫长,建议添加为[定时任务]执行)</option>  ' +
            '</select> </p>' +
            '<p><label></label> <button onclick="man_push()" class="btn btn-success">一键生成</button>  </p>' +
            '<div class="u_output">' +
            '<p>注意事项</p>' +
            '<p>1.插件依赖PHP7.1</p>' +
            '<p>2.请务必安装,不影响其他网站设置</p>' +
            '<p>3.如已安装,请忽略以上消息</p>' +
            '<p>4.生成sitemap.xml文件将直接保存至网站根目录</p>' +
            '</div>' +
            '<p id="sitemap_url_p"   style="margin-top: 5px"><label></label> ' +
            '<a id="sitemap_url"   onclick="check_href(this)" target="_blank" class="btn btn-primary btn-sm">访问已生成sitemap.xml</a>&nbsp;' +
            '<button onclick="active_push()"  class="btn btn-primary btn-sm">主动推送[根据对应网站配置]</button>&nbsp;' +
            '<button onclick="create_ds()" class="btn btn-success btn-sm">添加定时任务[自动生成sitemap并主动推送]</button> ' +
            '</p>' +
            '<p><label></label><a class="btlink" target="_blank" href="/crontab">查看定时任务</a></p>' +
            '</div>';
        $('.plugin_body').html(html);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
    })
}
function remember() {
    var host  =  $("select[name = host]").val();
    localStorage.setItem("host",host);
}

function man_push() {
    $('.u_output').html('');
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var way   =  $("select[name = way]").val();
    var str = "生成数据中,请耐心等待";
    if ( way ==3) {
        str = "生成数据中,手动执行多级抓取比较慢,容易超时,建议【添加定时任务】";
    }
    if (way ==3) {
        str = "生成数据中,手动执行三级抓取极其缓慢,且会超时,建议直接【添加定时任务】,凌晨执行";
    }
    var index =  layer.msg(str,{
        icon:16,
        time:0,
        shade:0.3
    });
    request_plugin('man_push',{protocol:protocol,host:host,way:way},function (res) {
        layer.close(index);
        if(res.code == 1){
            $('.u_output').html(res.data.content);
            $("#sitemap_url").attr('href',res.data.sitemap_url);
            //layer.alert('sitemap.xml已经保存至网站根目录,访问地址:<br><a class="btlink" target="_blank" href='+res.data.sitemap_url+'>'+res.data.sitemap_url+'</a>',{icon:1,time:5000});
        }else{
            layer.msg(res.msg,{icon:res.code == 1?1:2,time:res.code == 1?500:6000});
        }
    },600*1000)
}
function active_push() {
    var index =  layer.msg('加载数据中',{icon:16,time:0});
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var way   =  $("select[name = way]").val();
    request_plugin('active_push',{protocol:protocol,host:host,way:way},function (res) {
        layer.close(index);
        //layer.alert(res.msg,{icon:res.code == 1?1:2  })
        //页面层
        layer.open({
            title:'推送结果',
            type: 1,
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            area: ['650px', '540px'], //宽高
            content: "<div class='tan'>"+ res.msg +"</div>"
        });
    })
}

//定时推送
function create_ds() {
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var sitemap =  protocol+host+"/sitemap.xml";
    var way = $("select[name = way]").val();

    request_plugin('check_os',{},function (resData) {
        if(resData.data.os == 'linux'){
            request_plugin("getPath",{},function (res) {
                var path = res.path;
                var dir = res.dir;
                var php_path = res.php_path;
                //存储域名
                var args = {
                    "name":"【sitemap插件定时任务】主动推送域名为"+host+",生成网站地图:"+sitemap,
                    "type":"day",
                    "where1":"",
                    "hour":1,
                    "minute": 30,
                    "week":"",
                    "sType": "toShell",
                    "sBody": php_path+" "+path+" -a "+host+" -b "+sitemap+" -c "+dir+" -d "+protocol+" -e "+way,
                    "sName":"",
                    "save":"",
                    "backupTo": "localhost",
                    "urladdress":""
                };
                $.ajax({
                    type:'POST',
                    url: '/crontab?action=AddCrontab',
                    data: args,
                    success: function(rdata) {
                        console.log(rdata);
                        layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                        return;
                    },
                    error: function(ex) {
                        layer.msg('请求过程发现错误!', { icon: 2 });
                        return;
                    }
                });
            });
        }

        if(resData.data.os == 'windows'){
            request_plugin("getPath",{},function (res) {
                var path = res.path;
                var dir = res.dir;
                var php_path = res.php_path;
                //存储域名
                var args = {
                    "name":"【sitemap插件定时任务】主动推送域名为"+host+",生成网站地图:"+sitemap,
                    "type":"day",
                    // "where1":"",
                    "hour":1,
                    "minute": 30,
                    // "week":"",
                    "sType": "toShell",
                    "sBody": php_path+" "+path+" -a "+host+" -b "+sitemap+" -c "+dir+" -d "+protocol+" -e "+way,
                    "sName":"",
                    "save":"",
                    "backupTo": "localhost",
                    // "urladdress":""
                };
                $.ajax({
                    type:'POST',
                    url: '/crontab?action=AddCrontab',
                    data: args,
                    success: function(rdata) {
                        console.log(rdata);
                        layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                        return;
                    },
                    error: function(ex) {
                        layer.msg('请求过程发现错误!', { icon: 2 });
                        return;
                    }
                });
            });
        }
    })
}

function get_robots() {
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        layer.close(index);
        var op = '';
        var data = res.data;
        for(var i in  data){
            op+="<option>"+data[i].host+"</option>";
        }
        var html = '<div class="u_main" >' +
            '<p> <label>网站</label> <select onchange="remember(this)"  name="host" class="bt-input-text"> '+op+' </select> </p>' +
            '<p> <label>限制目录</label> <input name="dir" class="bt-input-text mr5"  placeholder="每个路径之前都要包含,例如 /bin/ 多个用&分割"></p>' +
            '<p> <label>检索间隔</label> <input name="delay"  type="number" class="bt-input-text mr5"  placeholder="为空则不限,限值数字 1-120">秒</p>' +
            '<p> <label>屏蔽搜索引擎</label>   <input  type="checkbox" name="baidu"> 百度 <input type="checkbox" name="sougou" title="搜狗"> 搜狗 <input type="checkbox" name="google" title="Google"> Google  <input type="checkbox" name="bing" title="bing"> Bing </p>' +
            '<p><label></label> <button onclick="gen_r()" class="btn btn-success">生成配置</button>  </p>' +
            '<p ><label></label> <textarea  name="robots"  cols="68" rows="15"></textarea>  </p>' +
            '<p><label></label> <button onclick="wr_robots()" class="btn btn-success btn-sm">写入网站目录</button></p>' +
            '</div>';
        $('.plugin_body').html(html);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
        var host = $("select[name=host]").val();
        request_plugin('get_r',{host,host},function (res) {
            if(res.code == 1 ){
                $('textarea[name=robots]').val(res.data.text);
            }
        })
    })
}
function is_empty(str) {
    if(str=='' || str == null || str == undefined){
        return true;
    }
    return false;
}

function gen_r() {
    var host = $("select[name=host]").val();
    var dir =  $("input[name=dir]").val();
    var delay =  $("input[name=delay]").val();
    var baidu =  $("input[name=baidu]:checked").val();
    var sougou =  $("input[name=sougou]:checked").val();
    var google =  $("input[name=google]:checked").val();
    var bing =  $("input[name=bing]:checked").val();

    var str =  "# robots.txt generated at http://www.waytomilky.com/ \n";
    if(!is_empty(dir)){
        var arr = dir.split('&');
        for(var i in  arr){
            var reg  = /\//;
            if(!reg.test(arr[i])){
                var text = "限值目录中有目录不含有斜杠 /  请更正！";
                layer.msg(text,{icon:2});
                return false;
            }
            str += "Disallow: "+arr[i]+"\n";
        }
    }
    if(!is_empty(delay)){
        str += "Crawl-delay:"+delay+"\n";
        if(delay <1 || delay >120){
            var text = "检索间隔单位过大或过小，<span class='red'>限值1-120 秒</span> ";
            layer.msg(text,{icon:2});
            return false;
        }
    }
    if(!is_empty(baidu)){
        str += "User-agent: Baiduspider\nDisallow: /  \n";
    }
    if(!is_empty(sougou)){
        str += "User-agent: sogou spider\nDisallow: /  \n";
    }
    if(!is_empty(google)){
        str += "User-agent: Googlebot\nDisallow: /  \n";
    }
    if(!is_empty(bing)){
        str += "User-agent: Bingbot\nDisallow: /  \n";
    }
    str += "Sitemap: http://"+host+"/sitemap.xml";
    $('textarea[name=robots]').val(str);

}
function  wr_robots() {
    var index = layer.load(0, {shade: false});
    var text =  $("textarea[name=robots]").val();
    var host =  $("select[name=host]").val();
    request_plugin('wr_robots',{host:host,text:text},function (res) {
        layer.close(index);
        layer.msg(res.msg,{icon:res.code,time:1000},function () {
            if(res.code == 1){
                layer.alert('生成地址:<a class="btlink" target="_blank" href="'+res.data.url+'">'+res.data.url+'</a>');
            }
        });
    })
}
function check_href(obj) {
    var protocol =  $("select[name= protocol]").val();
    var host =  $("select[name= host]").val();
    if($(obj).attr('href') == null){
        layer.msg('正在跳转至网站sitemap.xml,如果内容为空,请先生成哦!',{icon:16},function () {
            window.open(protocol+host+"/sitemap.xml");
        });
    }
}
function  get_log() {
    var index = layer.load(0, {shade: false});
    request_plugin('get_log',{},function (res) {
        layer.close(index);
        var content  = "";
        var em =  res.data.content;
        for(var i in em){
            content +=  "<p>---------------------------------------------------------------------------------</p>";
            content +=  "<p>"+"推送域名:"+em[i].host+"</p>";
            content +=  "<p>推送时间:"+em[i].create_time+"</p>";
            content +=  "<p>"+"推送类型:"+em[i].type+"</p>";
            content +=  "<p>"+"网址数量:"+em[i].num+"</p>";
            content +=  em[i].msg;
            content +=  "<p>推送地址:<a  class='btlink' target='_blank' href='"+em[i].pro+em[i].host+"/sitemap.xml' >"+em[i].pro+em[i].host+"/sitemap.xml</a></p>";
        }
        if(is_empty(content)){
            content =  "<p style='color: white'>没有日志记录</p>";
        }
        var html = '<div class="u_main">' +
            '<div class="u_output" style="height: 530px;margin-left: 14px;width: 709px">' +
            content +
            '</div>' +
            '</div>' +
            '<button onclick="rmlog()" style="margin-top: 5px;margin-bottom: 10px;margin-left: 14px" class="btn btn-success btn-sm">清空日志</button>';
        $('.plugin_body').html(html);
    })
}
function rmlog() {
    layer.confirm('<span class="red">确定要删除么？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('rmlog',{},function (res) {
            tip(res,function () {
                layer.close(index);
                get_log();
            });
        })
    });
}



