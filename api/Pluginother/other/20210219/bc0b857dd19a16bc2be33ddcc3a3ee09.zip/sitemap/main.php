<?php
require  'vendor/autoload.php';
require  'SQLite.php';
use QL\QueryList;
use QL\Ext\AbsoluteUrl;

class main
{
    
    public $chunk;
    public  $ds_file;
    public $db;
    public $user_agent;
    private $dataPath;
    
    function __construct()
    {
        define('PLUGIN_NAME', "sitemap");
        define('MAIN_DB', PLU_PATH.'/../../data/default.db');
        define('PLUGIN_DB', __DIR__ . '/web.db');
        define('PLU_NAME', 'sitemap');
        define('DS', '/');
        $this->dataPath = PLU_PATH.'/static/';
        $this->chunk = 2000;
        $this->ds_file =  PLU_PATH.'/console.php';
        $this->db = new SQLite(PLUGIN_DB);
        $this->user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36";

    }
    function get_info(){
        $plugin_json = file_get_contents(__DIR__.'/../../data/plugin.json');
        $arr =  json_decode($plugin_json,true);
        foreach ($arr['list'] as $v){
            if($v['name']=='sitemap'  && $v['endtime']<time()
                && $v['endtime'] !== 0
            ){
                $txt = file_get_contents(__DIR__.'/static/ms');
                echo base64_decode($txt)."\n";
                exit;
                //$this->error(base64_decode($txt));
                //echo base64_decode($txt);exit;
            }
        }
    }

    function trim_arr($arr)
    {
        if (empty($arr)) {
            return $arr;
        }
        foreach ($arr as &$val) {
            $val = trim($val);
        }
        return $arr;
    }

//success
    function success($msg = 'success', $data = null)
    {
        $this->json([
            'code' => 1,
            'msg' => $msg,
            'data' => $data
        ]);
    }

//error
    function error($msg)
    {
        return $this->json([
            'code' => 0,
            'msg' => $msg,
        ]);
    }

//获取json数据
    function json($data)
    {
        echo json_encode($data);
        exit;
    }
    
    function about()
    {
        try {
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'), true);
            $msg = $json[PLUGIN_NAME]['msg'];
        } catch (Exception $e) {
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    
    function baidu_push($host, $urls)
    {
//        $token = $this->config['baidu_token'];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token;
        $config_json = $this->get_config($host);
        $api = $config_json['baidu_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch), true);
    }
    
    function sm_push($host, $urls)
    {
//        $token  =  $this->config['sm_token'];
//        $email  =  $this->config['sm_email'];
//        $api = 'http://data.zhanzhang.sm.cn/push?site='.$host.'&user_name='.$email.'&resource_name=mip_add&token='.$token;
        $config_json = $this->get_config($host);
        $api = $config_json['sm_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return json_decode($result, true);
    }
    
    function get_config($host)
    {
        $db = new SQLite(PLUGIN_DB);
        $config = $db->query("select * from web where host   =  '{$host}' ")->fetch();
        return $config;
    }
    //抓取链接
    
    /**
     * @action 方法作用
     * @param $urlx
     * @param string $protocol
     * @param int $level
     * @return array
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function getUrls($protocol = 'http://', $urlx, $level = 1)
    {
        $user_agent = $this->user_agent;
        $url = $protocol . $urlx . '/';
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
        $urlsa =
            $ql->get($url,[],[
                'headers' => [
                    'Referer' => 'https://www.waytomilky.com/',
                    'User-Agent' => $user_agent,
                ]
            ])
            ->absoluteUrl($url)
            ->find('a')
            ->attrs('href')
            ->all();
        //过滤
        $urls = [];
        foreach ($urlsa as $key => $v) {
            if (preg_match("/" . $urlx . "/", $v)) {
                $urls[] = $v;
            }
        }
        if ($level == 2) {
            $arr = [];
            try{
                foreach ($urls as $v) {
                    $ql = QueryList::getInstance();
                    $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                    $urlsb =
                        $ql->get($url,[],[
                            'headers' => [
                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' => $user_agent
                            ]
                        ])
                        ->absoluteUrl($v)
                        ->find('a')
                        ->attrs('href')
                        ->all();
                    //过滤
                    $ax = [];
                    foreach ($urlsb as $key => $v) {
                        if (preg_match("/" . $urlx . "/", $v)) {
                            $ax[] = $v;
                        }
                    }
                    foreach ($ax as $vx) {
                        $arr[] = $vx;
                    }
                }
            }catch (\Exception $e){

            }
            return array_unique($arr);
        }
        //三级抓取
        if($level == 3){
            $temp = [];
            try{
                foreach ($urls as $v) {
                    $ql = QueryList::getInstance();
                    $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                    $ua = $ql->get($url,[],[
                            'headers' => [
                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' => $user_agent
                            ]
                        ])
                            ->absoluteUrl($v)
                            ->find('a')
                            ->attrs('href')
                            ->all();
                    foreach ($ua as $va){
                        $ub = $ql->get($url,[],[
                            'headers' => [
                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' => $user_agent
                            ]
                        ])
                            ->absoluteUrl($va)
                            ->find('a')
                            ->attrs('href')
                            ->all();
                        $tt  = [];
                        foreach ($ub as  $v) {
                            if (preg_match("/" . $urlx . "/", $v)) {
                                $tt[] = $v;
                            }
                        }
                        foreach ($tt as $cc){
                            $temp[] = $cc;
                        }
                    }
                }
                return array_unique($temp);
            }catch (Exception $e){

            }
        }

        return array_unique($urls);
    }
    /**
     * @action 保存sitemap
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function save_sitemap($host, $urls)
    {
        $config = $this->get_config($host);
        $map = new Sitemap();
        $urls = array_unique($urls);
        $txt = "";
        foreach ($urls as $v) {
            $v = $this->dlamp($v);
            $txt .= $v . "\n";
            $map->AddItem($v, 1);
        }
        $map->SaveToFile($config['path'] . DS . '/sitemap.xml');
        //判断public目录
        if (is_dir($config['path'] . DS . "/public")) {
            $map->SaveToFile($config['path'] . DS . 'public/sitemap.xml');
        }
        //判断web目录
        if (is_dir($config['path'] . DS . "/web")) {
            $map->SaveToFile($config['path'] . DS . 'web/sitemap.xml');
        }
        //sitemap.txt
//        foreach ($urls as $vx){
//            file_put_contents($vx."\n",$config['path'] . DS . '/sitemap.txt');
//            if (is_dir($config['path'] . DS . "/public")){
//                file_put_contents($vx."\n",$config['path'] . DS . 'public/sitemap.txt');
//            }
//            if (is_dir($config['path'] . DS . "/web")) {
//                $map->SaveToFile($config['path'] . DS . 'web/sitemap.txt');
//            }
//        }
      
    }
    
    //替换&
    function dlamp($str)
    {
        return str_replace('&', '&amp;', $str);
    }
    
    function switchXml2arr($sitemap_url)
    {
        $content = $this->getHtml($sitemap_url);
        //$obj = new SimpleXMLElement($content);
        $xml = simplexml_load_string($content, 'SimpleXMLElement', LIBXML_NOCDATA);
        $jsonStr = json_encode($xml);
        $xml_data = json_decode($jsonStr, true);
        
        foreach ($xml_data['url'] as $key => $value) {
            $urls[] = $value['loc'];
        }
        return $urls;
    }
    
    function getHtml($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    
    function fenPush($host, $urls,$pro)
    {
        $urls = array_unique($urls);
        
        
        if (empty($urls)) {
            return "<div class='red'>插件警告:<br>1.推送的链接全部为重复网址或者过滤后无有效网址.</div>";
        }
        
        
        $chunk = $this->chunk;
        $msg = '';
        if (count($urls) > $chunk) {
            $msg .= '推送总数:' . count($urls);
            $url_chunk = array_chunk($urls, $chunk);
            $i = 0;
            foreach ($url_chunk as $value) {
                $i++;
                $msg .= "<br><b>-------------网址数量大于" . $chunk . ",自动启用分批推送,每批" . $chunk . "条,当前第" . $i . "批--------------</b>" . $this->push_all($host, $value, $pro);
            }
        } else {
            $msg = $this->push_all($host, $urls,$pro);
        }
        if(preg_match('/成功/',$msg)){
            $msg .= "<br>";
            $msg .= "<p>成功推送网址列表:</p>";
            foreach ($urls as $url) {
                $msg .= "<p>" . $url . "</p>";
            }
        }
        
        return $msg;
    }
    
    function push_all($host, $urls,$pro){
        $host_config  = $this->get_config($host);
        if(  empty( $host_config['baidu_api'] )  && empty($host_config['sm_api'])  ){
            $this->error('至少开启一个推送类型');
        }
        //百度主动推送
        $msg = '';
        if( !empty($host_config['baidu_api']) ){
            $res =  $this->baidu_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success'])){
                @$msg .= '<p class="bt-text">百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</p>';
            }else{
                $warn =  isset($res['message'])?$res['message']:'';
                $warn = "推送api填写不正确.";
                if($warn == 'token is not valid'){
                    $warn = "百度api填写错了,别这么粗心哦!请仔细检查下";
                }
                $msg .= "<p class='bt-text-danger'>百度推送失败,$warn</p>";
            }
        }
    
    
        //神马推送
        if( !empty($host_config['sm_api']) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres['returnCode']==200){
                $msg .= '<p class="bt-text">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</p>';
            }else{
                $msg .= '<p class="bt-text-danger">神马mip推送失败:配置错误.'.(isset($smres['returnCode'])?$smres['returnCode']:'')."</p>";
            }
        }
        
        try{
            $this->record_log($msg,$host,count($urls),$pro);
        }catch (\Exception $e){}
        
        return $msg;
    }
    
    function  record_log($msg,$host,$num,$pro="http://"){
        $type = "手动推送";
        if(empty($num)){
            $num = 0;
        }
        $create_time = date('Y-m-d H:i:s',time());
        $this->db->query("insert into `log` (msg,host,type,create_time,pro,num) values('{$msg}','{$host}','{$type}','{$create_time}','{$pro}','{$num}')  ");
    }
}
