#!/usr/bin/python
# coding: utf-8
# -----------------------------
# Name: OpenRasp 管理器
# OpenRasp:https://rasp.baidu.com/
# Author: print("")
# -----------------------------
# date 2020-01-03
import sys, os
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel')
sys.path.append("class/")
import public,time,json,re

class openrasp_main:
    __down_path='/var/tmp/rasp-php-linux.tar.bz2'
    __openrasp='/var/tmp/rasp-php-2019-12-17'
    __install_path='/opt/rasp_php'
    __php_path='/www/server/php/'
    __php_version=['53','54','55','56','70','71','70','72','73']
    def __init__(self):
        pass

    #下载OpenRasp
    def down_rasp(self,get):
        if not os.path.exists(self.__openrasp+'/install.php'):
            public.ExecShell('rm -rf /var/tmp/rasp-php-linux.tar.bz2 && rm -rf /var/tmp/rasp-php-2019-12-17')
            public.ExecShell('cd /var/tmp && wget https://packages.baidu.com/app/openrasp/release/1.2.3/rasp-php-linux.tar.bz2 && tar jxvf rasp-php-linux.tar.bz2 && chattr -R +i /var/tmp/rasp-php-2019-12-17')
            return public.returnMsg(True,'下载成功')
        else:
            return public.returnMsg(True,'已经存在')

    def get_check_rasp(self):
        if not os.path.exists(self.__openrasp + '/install.php'):
            return False
        else:
            return True

    #获取PHP安装的版本
    def get_php_version(self,get):
        return_list=[]
        for i in self.__php_version:
            if os.path.exists(self.__php_path+i):
                return_list.append(i)

        return list(set(return_list))

    #检验是否安装了了openrasp
    def check_openrasp(self,version):
        if os.path.exists(self.__install_path+version):
            if os.path.exists(self.__php_path+version+'/etc/php.ini'):
                file_data=public.ReadFile(self.__php_path+version+'/etc/php.ini')
                if re.search(self.__install_path+version,file_data):
                    data=public.ReadFile(self.__php_path+version+'/etc/php.ini')
                    if re.search('openrasp.so',data):return True
        return False

    #是否开启
    def get_status_openrasp(self,version):
        if os.path.exists(self.__install_path+version+'/plugins/official.js'):
            data=public.ReadFile(self.__install_path+version+'/plugins/official.js')
            if re.findall('all_log:\s+?(.+),', data)[0]=='false':
                data=public.ReadFile(self.__php_path+version+'/etc/php.ini')
                if re.search('openrasp.so',data):return True
            else:
                return False
        return False
            

    #查看哪些版本已经安装了openrasp
    def get_openrasp(self,get):
        php_version=self.get_php_version(get)
        if len(php_version)==0:return []
        data=[]
        for i in php_version:
            data2={}
            data2['version']=i
            data2['openrasp']=self.check_openrasp(i)
            data2['openrasp_open'] = self.get_status_openrasp(i)
            data.append(data2)
        return {"php":data,"check_rasp":self.get_check_rasp()}

    def install_openrasp(self,get):
        self.down_rasp(get)
        if not get.version.strip() in self.__php_version:return public.returnMsg(False,'只支持PHP5.3到PHP7.2')
        if not os.path.exists(self.__php_path+get.version.strip()):return public.returnMsg(False,'你未安装当前PHP版本')
        public.ExecShell(self.__php_path+get.version.strip()+'/bin/php  '+self.__openrasp+'/install.php -d '+self.__install_path+get.version.strip())
        self.start_openrasp(get)
        public.ExecShell('/etc/init.d/php-fpm-%s restart'%get.version.strip())
        return public.returnMsg(True, '安装成功')

    # 开启OpenRsap
    def start_openrasp(self,get):
        version=get.version.strip()
        if not 'is_dev' in get:get.is_dev='false'
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.2')
        if not os.path.exists(self.__install_path+version): return public.returnMsg(False, '你未安装当前PHP版本')
        if os.path.exists(self.__install_path+version+'/plugins/official.js'):
            data=public.ReadFile(self.__install_path+version+'/plugins/official.js')
            data2 = re.sub('all_log:\s+?(.+),', 'all_log: false,', data)
            if not get.is_dev=='false':
                data2 = re.sub('is_dev:\s+?(.+),', 'is_dev: true,', data2)
            public.WriteFile(self.__install_path+version+'/plugins/official.js', data2)
        return public.returnMsg(True, '开启成功')

    #关闭OpenRasp
    def stop_openrasp(self,get):
        version=get.version.strip()
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.2')
        if not os.path.exists(self.__install_path+version): return public.returnMsg(False, '你未安装当前PHP版本')
        if os.path.exists(self.__install_path+version+'/plugins/official.js'):
            data=public.ReadFile(self.__install_path+version+'/plugins/official.js')
            data2 = re.sub('all_log:\s+?(.+),', 'all_log: true,', data)
            public.WriteFile(self.__install_path+version+'/plugins/official.js', data2)
            public.ExecShell('/etc/init.d/php-fpm-%s restart' % get.version.strip())
        return public.returnMsg(True, '关闭成功')

    #卸载openrasp
    def uninstall_openrasp(self,get):
        version = get.version.strip()
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.2')
        if not os.path.exists(self.__install_path + version): return public.returnMsg(False, '你未安装当前PHP版本')
        public.ExecShell(self.__php_path + get.version.strip() + '/bin/php  ' + self.__openrasp + '/uninstall.php -d ' + self.__install_path + version)
        public.ExecShell('/etc/init.d/php-fpm-%s restart' % get.version.strip())
        return public.returnMsg(True, '卸载成功')

    #自定义拦截页面
    def set_lan_html(self,get):
        pass

    #防护日志
    def get_logs(self,get):
        version = get.version.strip()
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.2')
        if not os.path.exists(self.__install_path + version): return public.returnMsg(False, '你未安装当前PHP版本')
        pass


    #

