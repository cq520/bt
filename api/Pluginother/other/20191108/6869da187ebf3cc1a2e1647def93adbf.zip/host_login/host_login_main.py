# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: print("") <1249648969@qq.com>
# +--------------------------------------------------------------------
# |  主机异常登录
# +--------------------------------------------------------------------
import sys
sys.path.append('/www/server/panel/class')
import os,public,json,re
import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
class host_login_main:
    __mail_config = '/dev/shm/stmp_mail.json'
    __user_config = '/dev/shm/user.json'
    ip_data = '/dev/shm/ip.json'
    __qq_mail_user = []
    __user_mail_info=[]
    __www_path='/home/www'
    __ip_data=None
    def __init__(self):
        if not os.path.exists(self.ip_data):
            ret = []
            public.writeFile(self.ip_data, json.dumps(ret))
        else:
            self.__ip_data = json.loads(public.ReadFile(self.ip_data))
        # QQ邮箱基础实例化
        if not os.path.exists(self.__mail_config):
            ret = []
            public.writeFile(self.__mail_config, json.dumps(ret))
        else:
            qq_mail_info = json.loads(public.ReadFile(self.__mail_config))
            if 'qq_mail' in qq_mail_info and 'qq_stmp_pwd' in qq_mail_info and 'hosts' in qq_mail_info:
                self.__qq_mail_user = qq_mail_info
        #发送邮件列表
        if not os.path.exists(self.__user_config):
            ret = []
            public.writeFile(self.__user_config, json.dumps(ret))
        else:
            data = json.loads(public.ReadFile(self.__user_config))
            self.__user_mail_info = data

        if not os.path.exists(self.__www_path):
            os.mkdir(self.__www_path)

    #返回邮件设置信息
    def return_mail(self,get):
        return self.__qq_mail_user

    #返回用户信息
    def return_user(self,get):
        return self.__user_mail_info

    #返回登陆IP
    def return_ip(self,get):
        self.__ip_data = json.loads(public.ReadFile(self.ip_data))
        return self.__ip_data

    #添加白名单IP
    def add_return_ip(self,get):
        if get.ip.strip() in self.__ip_data:
            return public.returnMsg(False, "已经存在")
        else:
            self.__ip_data.append(get.ip.strip())
            public.writeFile(self.ip_data, json.dumps(self.__ip_data))
            return public.returnMsg(True, "添加成功")

    #删除白名单IP
    def del_return_ip(self,get):
        if get.ip.strip() in self.__ip_data:
            self.__ip_data.remove(get.ip.strip())
            public.writeFile(self.ip_data, json.dumps(self.__ip_data))
            return public.returnMsg(True, "删除成功")
        else:
            return public.returnMsg(False, "不存在")

    #添加发送邮件
    def add_mail_user(self,get):
        if get.email in self.__user_mail_info:
            return public.returnMsg(False, "已经存在")
        else:
            self.__user_mail_info.append(get.email)
            public.writeFile(self.__user_config, json.dumps(self.__user_mail_info))
            return public.returnMsg(True, "添加成功")

    #添加发送邮件
    def del_mail_user(self,get):
        if get.email.strip() in self.__user_mail_info:
            self.__user_mail_info.remove(get.email.strip())
            public.writeFile(self.__user_config, json.dumps(self.__user_mail_info))
            return public.returnMsg(True, "删除成功")
        else:
            return public.returnMsg(True, "不存在")

    # QQ邮箱保存账户信息
    def qq_stmp_insert(self,email,stmp_pwd,hosts):
        qq_stmp_info={"qq_mail":email.strip(),"qq_stmp_pwd":stmp_pwd.strip(),"hosts":hosts.strip()}
        self.__qq_mail_user = qq_stmp_info
        public.writeFile(self.__mail_config, json.dumps(qq_stmp_info))
        return True

    # qq发送测试
    def qq_smtp_send(self,email,title,body):
        if 'qq_mail' not in self.__qq_mail_user or 'qq_stmp_pwd' not in self.__qq_mail_user or 'hosts' not in self.__qq_mail_user: return -1
        ret = True
        try:
            msg = MIMEText(body, 'html', 'utf-8')
            msg['From'] = formataddr([self.__qq_mail_user['qq_mail'], self.__qq_mail_user['qq_mail']])
            msg['To'] = formataddr([self.__qq_mail_user['qq_mail'], email.strip()])
            msg['Subject'] = title
            server = smtplib.SMTP_SSL(self.__qq_mail_user['hosts'], 465)
            server.login(self.__qq_mail_user['qq_mail'], self.__qq_mail_user['qq_stmp_pwd'])
            server.sendmail(self.__qq_mail_user['qq_mail'], [email.strip(), ], msg.as_string())
            server.quit()
        except Exception:
            ret = False
        return ret

    #保存STMP并且发送测试邮件
    def test_send_mail(self,get):
        if not 'email' in get:return public.returnMsg(False, "请输入你的邮箱")
        if not 'stmp_pwd' in get: return public.returnMsg(False, "请输入你的STMP密码")
        if not 'hosts' in get: return public.returnMsg(False, "请输入你的hosts地址")
        self.qq_stmp_insert(get.email,get.stmp_pwd,get.hosts)
        if self.qq_smtp_send(get.email,'测试','测试'):
            self.add_mail_user(get)
            return public.returnMsg(True, "保存成功")
        else:
            return public.returnMsg(False, "STMP密码错误")
    #发送
    def smtp_send(self,get):
        return self.qq_smtp_send(get.email,get.title,get.body)

    #发送消息给列表中
    def send_mail_data(self,title,body):
        if len(self.__user_mail_info)>=1:
            for i in self.__user_mail_info:
                self.qq_smtp_send(i,title,body)
            return True

    #检测非UID为0的账户
    def check_user(self):
        data=public.ExecShell('''cat /etc/passwd | awk -F: '($3 == 0) { print $1 }'|grep -v '^root$'  ''')
        data=data[0]
        if re.search("\w+",data):
            self.send_mail_data(public.GetLocalIp()+'服务器存在后门用户',public.GetLocalIp()+'服务器存在后门用户'+data+'检查/etc/passwd文件')
            return True
        else:
            return False

    #取登陆的前50个条记录
    def login_last(self):
        data=public.ExecShell('last -n 50')
        data=re.findall("(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)",data[0])
        if data>=1:
            data2=list(set(data))
            for i in data2:
                if not i in self.__ip_data:
                    self.__ip_data.append(i)
            public.writeFile(self.ip_data, json.dumps(self.__ip_data))
        return self.__ip_data

    #获取ROOT当前登陆的IP
    def Get_IP(self):
        data = public.ExecShell(''' echo $SSH_CLIENT |awk ' { print $1 }' ''')
        data = re.findall("(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)",data[0])
        return data

    #登陆的情况下
    def login(self):
        if not self.__qq_mail_user:return False
        self.check_user()
        #取登陆的前50个条记录
        self.__ip_data = json.loads(public.ReadFile(self.ip_data))
        if len(self.__ip_data)==0:
            self.login_last()
        ip=self.Get_IP()
        if len(ip[0])==0:return False
        if ip[0] in self.__ip_data:
            return False
        else:
            self.send_mail_data(public.GetLocalIp()+'服务器异常登陆',public.GetLocalIp()+'服务器存在异常登陆登陆IP为'+ip[0]+'登陆用户为root')
            self.__ip_data.append(ip[0])
            public.writeFile(self.ip_data, json.dumps(self.__ip_data))
            return True

    #开启监控
    def start_jian(self,get):
        data=public.ReadFile('/etc/bashrc')
        if not re.search('python /www/server/panel/plugin/host_login/host_login_main.py',data):
            public.WriteFile('/etc/bashrc',data.strip()+'\npython /www/server/panel/plugin/host_login/host_login_main.py login\n')
            return True
        return False

    #关闭监控
    def stop_jian(self,get):
        data = public.ReadFile('/etc/bashrc')
        if re.search('python /www/server/panel/plugin/host_login/host_login_main.py', data):
            public.WriteFile('/etc/bashrc',data.replace('python /www/server/panel/plugin/host_login/host_login_main.py login',''))
            return True
        else:
            return False

    #监控状态
    def get_jian(self,get):
        data = public.ReadFile('/etc/bashrc')
        if re.search('python /www/server/panel/plugin/host_login/host_login_main.py login', data):
            return True
        else:
            return False

    #监控www用户
    def get_www_jian(self,get):
        if not os.path.exists('/home/www/.bashrc'):return False
        data = public.ReadFile('/home/www/.bashrc')
        if  re.search('python /dev/shm/www.py', data):
            return True
        return False

    #关闭www的监控
    def stop_www_jian(self,get):
        if not os.path.exists('/home/www/.bashrc'): return False
        data = public.ReadFile('/home/www/.bashrc')
        if re.search('python /dev/shm/www.py', data):
            public.WriteFile('/home/www/.bashrc',data.replace('python /dev/shm/www.py', ''))
            return True
        return False

    #开启www的监控
    def start_www_jian(self,get):
        if not os.path.exists('/home/www/.bashrc'):
            public.WriteFile('/home/www/.bashrc','\npython /dev/shm/www.py\n')
            return True
        else:
            data = public.ReadFile('/home/www/.bashrc')
            if not re.search('python /dev/shm/www.py', data):
                public.WriteFile('/home/www/.bashrc', data+'\npython /dev/shm/www.py\n')
                return True
            else:
                return False

if __name__ == '__main__':
    type = sys.argv[1]
    if type=='login':
        aa = host_login_main()
        aa.login()
    else:
        pass



