# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: print("") <1249648969@qq.com>
# +--------------------------------------------------------------------
# |  主机异常登录
# +--------------------------------------------------------------------
import sys
import os,json
import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
class host_login_main:
    __mail_config = '/dev/shm/stmp_mail.json'
    __user_config = '/dev/shm/user.json'
    __qq_mail_user = None
    __user_mail_info=None
    def __init__(self):
        if  os.path.exists(self.__mail_config):
            qq_mail_info = json.loads(self.ReadFile(self.__mail_config))
            if 'qq_mail' in qq_mail_info and 'qq_stmp_pwd' in qq_mail_info and 'hosts' in qq_mail_info:
                self.__qq_mail_user = qq_mail_info
        #发送邮件列表
        if  os.path.exists(self.__user_config):
            data = json.loads(self.ReadFile(self.__user_config))
            self.__user_mail_info = data

    def ReadFile(self,filename, mode='r'):
        if not os.path.exists(filename): return False
        try:
            fp = open(filename, mode)
            f_body = fp.read()
            fp.close()
        except Exception as ex:
            if sys.version_info[0] != 2:
                try:
                    fp = open(filename, mode, encoding="utf-8");
                    f_body = fp.read()
                    fp.close()
                except Exception as ex2:
                    return False
            else:
                return False
        return f_body

    # qq发送测试
    def qq_smtp_send(self,email,title,body):
        if 'qq_mail' not in self.__qq_mail_user or 'qq_stmp_pwd' not in self.__qq_mail_user or 'hosts' not in self.__qq_mail_user: return -1
        ret = True
        try:
            msg = MIMEText(body, 'html', 'utf-8')
            msg['From'] = formataddr([self.__qq_mail_user['qq_mail'], self.__qq_mail_user['qq_mail']])
            msg['To'] = formataddr([self.__qq_mail_user['qq_mail'], email.strip()])
            msg['Subject'] = title
            server = smtplib.SMTP_SSL(self.__qq_mail_user['hosts'], 465)
            server.login(self.__qq_mail_user['qq_mail'], self.__qq_mail_user['qq_stmp_pwd'])
            server.sendmail(self.__qq_mail_user['qq_mail'], [email.strip(), ], msg.as_string())
            server.quit()
        except Exception:
            ret = False
        return ret

    def get_ip(self):
        try:
            import urllib2
            url = urllib2.urlopen("http://bt.cn/api/getipaddress")
            text = url.read()
            return str(text)
        except:
            return '服务器IP获取失败'



    #发送
    def smtp_send(self,get):
        return self.qq_smtp_send(get.email,get.title,get.body)
    #发送消息给列表中
    def send_mail_data(self,title,body):
        if len(self.__user_mail_info)>=1:
            for i in self.__user_mail_info:
                self.qq_smtp_send(i,title,body)
            return True

    #登陆的情况下
    def login(self):
        if not self.__qq_mail_user:return False
        #取登陆的前50个条记录
        if self.__qq_mail_user and self.__user_mail_info:
            user=os.getenv('USER')
            path=os.getenv('PWD')

           # self.send_mail_data('网站已经反弹shell','网站已经反弹shell')
            self.send_mail_data(self.get_ip()+'服务器中的网站已经被反弹shell',self.get_ip()+'服务器中的网站已经被反弹shell了'+'当前用户'+user+'现所在的路径'+path)

if __name__ == '__main__':
    aa = host_login_main()
    aa.login()


