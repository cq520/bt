#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: f4cklangzi <f4cklangzi@gmail.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   短链接生成器
# +--------------------------------------------------------------------
import json
import os
import sys

# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")
import requests, json

# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect


class shorturl_main:
    __plugin_path = "/www/server/panel/plugin/shorturl/"
    __recent_path = "/www/server/panel/plugin/shorturl/recent.json"
    __config = None

    # 构造方法
    def __init__(self):
        pass

    def short(self, args):
        url = 'http://www.f4cklangzi.cn/api/create.html'
        postData = {'api_key': 'b9ee77466518fbe6e71342a5183769ca', 'original_url': args.long_url, 'mode': args.mode}
        data = requests.post(url, data=postData, timeout=60)
        try:
            jsonData = data.json()
        except:
            return {'code': 1, 'msg': '程序发生错误，请联系作者修复!'}
        else:
            if jsonData['code']==1:
                return {'code': 1, 'msg': jsonData['msg']}
            dataList = self.getRecentList()
            res={"original_url": args.long_url, "short_url": jsonData['data']['short_url']}
            if res in dataList:
                dataList.remove(res)
            if len(dataList)==10:
                dataList.pop()
            dataList.insert(0,res)
            with open(self.__recent_path, mode='w') as f:
                json.dump(dataList, f)
                f.close()
                return jsonData

    def recent(self, args):
        data = self.getRecentList()
        return data

    def getRecentList(self):
        with open(self.__recent_path, mode='r') as f:
            data = json.load(f)
            f.close()
            return data
