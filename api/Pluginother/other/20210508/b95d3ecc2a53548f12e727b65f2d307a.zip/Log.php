<?php
class Log {
    const  PLUGIN_DB = __DIR__ . '/web.db';
    
    protected $db;
    
    function __construct()
    {
       $this->db =  new SQLite(self::PLUGIN_DB);
    }
    
    
    
    function write_log($is_cron,$host,array $urls)
    {
        if(empty($urls)){
            throw new \Exception('网址为空,无法推送');
        }
        $time = time();
        $count = count($urls);
        $url_json = json_encode($urls);
        $sql = "insert into  log(is_cron,host,count,url_json,create_time)    values('{$is_cron}','{$host}','{$count}','{$url_json}','{$time}')";
        $res =  $this->db->query($sql);
        if(empty($res)){
            throw  new  \Exception('SQL插入未成功');
        }
    }
    function url_log($host,$urls){
        foreach ($urls as $url){
            $sql  = "insert into url_log(host,url,baidu_res,sm_res,push_times) values()";
            $this->db->query($sql);
        }
    }
    
    /**
     * @action 日志记录
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/10/27
     */
    function record($is_cron,$host,$log_arr,array $urls)
    {
        if(empty($urls)){
            throw new \Exception('网址为空,无法推送');
        }
        $time = time();
        $count = count($urls);
        $url_json = json_encode($urls);
        if(!empty($log_arr['baidu'])){
            $success = $log_arr['baidu']['success'];
            $remain  = $log_arr['baidu']['remain'];
            $not_same_site = $log_arr['baidu']['not_same_site'];
            $not_valid = $log_arr['not_valid']['not_valid'];
        }else{
            $success = 0;
            $remain  = 0;
            $not_same_site = 0;
            $not_valid = 0;
        }
        if(!empty($log_arr['sm'])){
            $sm_success = $log_arr['sm'];
        }else{
            $sm_success = 0;
        }
        $sql = <<<EOF
INSERT INTO log(is_cron,host,count,success,remain,not_same_site,not_valid,sm_success,url_json)
VALUES('{$is_cron}','{$host}','{$count}','{$success}','{$remain}','{$not_same_site}','{$not_valid}','{$sm_success}')
EOF;
        $res =  $this->db->query($sql);
        if(empty($res)){
            throw  new  \Exception('SQL插入未成功');
        }
        return $res;
    }
    
}