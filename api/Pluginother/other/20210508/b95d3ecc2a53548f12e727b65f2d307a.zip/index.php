<?php
//网址推送插件 v2.5
//@author 阿修罗<610176732@qq.com>
require  'vendor/autoload.php';
require  'common.php';
require  'SQLite.php';
require  'Log.php';

use QL\QueryList;
use QL\Ext\AbsoluteUrl;
use QL\Ext\Baidu;

/**
 * Class bt_main
 * 宝塔实现的默认方法
 * _post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
 * 可通过_version()函数获取面板版本
 * 可通过_post('client_ip') 来获取访客IP
 * 常量说明：
 * PLU_PATH 插件所在目录
 * PLU_NAME 插件名称
 * PLU_FUN  当前被访问的方法名称
 */
class bt_main extends Common{
	//不允许被面板访问的方法请不要设置为公有方法
    const DS = '/';
    public  function checkPhp(){
        $this->success('success');
    }
    //不允许被面板访问的方法请不要设置为公有方法
    protected $dataPath;
    protected $config;
    public $ds_file;
    public $ds_main_file;
    protected $ds_log;
    protected $config_json;
    public  $chunk;
    protected  $urls_log;
    protected  $db;
    public     $log;
    public     $post;
    public     $get;
    public  function  __construct()
    {
        $this->dataPath = PLU_PATH.'/static/';
        $this->urls_log = PLU_PATH."/static/urls.log";
        @chmod($this->dataPath,0777);
        @chmod($this->urls_log,0777);
        $this->ds_file =  PLU_PATH.'/console.php';
        $this->ds_main_file = PLU_PATH.'/mainconsole.php';
        $this->ds_log  =  PLU_PATH.'/static/console.log';
        $this->config_json = PLU_PATH.'/static/config.json';
        //常量定义
        define('PLUGIN_DB', __DIR__ . '/web.db');
        define('PLUGIN_NAME', 'urlpush');
        $this->get_info();
        $this->db = new SQLite(PLUGIN_DB);
        //分批数量
        $this->chunk = 2000;
        $this->log  =  new Log();
        //注入请求
        $this->post = _post();
        $this->get =  _get();
    }
    
    
    //推送网址上的链接
    public function tsMain(){
       $param = $this->trim_arr(_post());
       $host = $param['host'];
       $url =  $param['mainurl'];
       if(empty($param['host']) || empty($param['mainurl'])){
           $this->error('域名或网址为空');
       }
       try{
           $urls = $this->getMainUrls($url);
           if(empty($urls)){
               throw new \Exception('插件爬虫无法爬取目标网址，可能被防火墙拦截或者目标网址协议不对，请到目标服务器配置防火墙或者网站的强制Https选项');
           }
           $msg =  $this->fenPush($host,$urls,false);
       }catch (\Exception $e){
           $this->error($e->getMessage());
       }
       
       if(empty($msg)){
           $this->error('抓取异常');
       }
       $this->success($msg);
    }
    function get_info(){
        $plugin_json = file_get_contents($this->dataPath.'/../../../data/plugin.json');
        $arr =  json_decode($plugin_json,true);
        foreach ($arr['list'] as $v){
            if($v['name']=='urlpush'  && $v['endtime']<time()
                && $v['endtime'] !== 0
            ){
                $txt = file_get_contents($this->dataPath.'ms');
                $this->error(base64_decode($txt));
                //echo base64_decode($txt);exit;
            }
        }
    }
    //抓取链接
    function getMainUrls($url){
        try{
            $ql = QueryList::getInstance();
            $ql->use(AbsoluteUrl::class,'absoluteUrl','absoluteUrlHelper');
            $urls = $ql->get($url,[],[
                'Referer' => 'https://www.waytomilky.com/',
                'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1',
            ])
                ->absoluteUrl($url)
                ->find('a')
                ->attrs('href');
            return $urls->all();
        }catch (\Exception $e){
            return [];
        }
    }
    
    public function getMainPath(){
        $this->json([
            'path'=>$this->ds_main_file,
            'dir'=> PLU_PATH
        ]);
    }
    
    public function getPath(){
        $this->json([
            'path'=>$this->ds_file,
            'dir'=> PLU_PATH,
            'php_path'=>$this->get_php_path()
        ]);
    }
    //保存配置
//    function save_config(){
//        $post = _post();
//        $config_data = [
//            'hosts'=>$post['hosts'],
//            'baidu_token'=>$post['baidu_token'],
//            'is_zhu'=>$post['is_zhu'],
//            'is_mip' => $post['is_mip'],
//            'is_xiong' => $post['is_xiong'],
//            'sm_token'=>$post['sm_token'],
//            'sm_email'=>$post['sm_email'],
//            'is_sm_mip'=>$post['is_sm_mip']
//        ];
//        if(empty($config_data['hosts']) || empty($config_data['baidu_token']) ||  (int)$config_data['is_zhu'] !== 1 ){
//            $this->error('至少要配置:域名,百度token,开启主动推送');
//        }
//        $res = file_put_contents($this->config_file,serialize($config_data));
//        if($res){
//            $this->success('写入配置成功');
//        }
//        $this->error('配置失败');
//    }
    //获取域名列表
    public function  get_hosts(){
        $config =  $this->get_config_json();
        $str = '';
        foreach ($config as  $key=> $v){
            if(empty($v)){
                continue;
            }
            $str .= "<option value='".$key."'>".$key."</option>";
        }
        $this->success('success', ['options'=>$str]);
    }
    //获取json数据
    public function json($data){
        echo json_encode($data);
        exit;
    }
    protected function success($msg = 'success',$data = null){
        $this->json([
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
    protected function error($msg){
        $this->json([
            'code'=>-1,
            'msg'=>$msg,
        ]);
    }
    function getHtml($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    
    function switchXml2arr($sitemap_url){
        $content =  $this->getHtml($sitemap_url);
        //$obj = new SimpleXMLElement($content);
        $xml = simplexml_load_string($content , 'SimpleXMLElement' , LIBXML_NOCDATA );
        $jsonStr = json_encode($xml);
        $xml_data = json_decode($jsonStr,true);
    
        foreach ($xml_data['url'] as $key => $value) {
            $urls[] =  $value['loc'];
        }
        return $urls;
    }

    function  mpush(){
        $param =  _post();
        if(empty($param['host']) || empty($param['sitemap_url']) ){
            $this->error('请选择域名和输入sitemap远程地址');
        }

        $urls = [];
        //$content = file_get_contents($param['sitemap_url']);
        $urls = $this->switchXml2arr($param['sitemap_url']);
        

//        try{
//
//        }catch (\Exception $e){
//            $this->error('非规范xml地图格式');
//        }
      
        //分批推送
        $msg = $this->fenPush($param['host'],(array)$urls);
        $this->success($msg);
    }
    
    
    //写入urls.log
    function save_urls_log($host,array $urls){
        file_put_contents($this->dataPath."/".$host,serialize($urls) );
    }
    
    //获取推送过的地址
    function get_urls_arr($host){
        $info = file_get_contents($this->dataPath."/".$host);
        return unserialize($info);
    }
    
    
    //是否上次推送
    function get_last_push($host){
        if(!file_exists($this->dataPath."/".$host))
            return [];
        return json_decode(file_get_contents($this->dataPath."/".$host),true);
    }
    
    //处理重复网址
    function handle_repeat_urls($host,$urls){
        $last_urls = $this->get_last_push($host);
        if( empty($last_urls) )
            return $urls;
        $new_arr  = [];
        foreach ($urls as $val){
            if ( !in_array($val,$last_urls) )
                $new_arr[] = $val;
        }
        return $new_arr;
    }
    
    function write_urls($host,$urls){
        $last_push_urls = $this->get_last_push($host);
        $no_history = [];
        if(empty($last_push_urls)){
            file_put_contents($this->dataPath.self::DS.$host,json_encode($urls));
            return;
        }
        foreach ($urls as $val){
            if(!in_array($val,$last_push_urls)){
                $no_history[] = $val;
            }
        }
        if(empty($urls)){
            return;
        }
        $urls = array_merge($no_history,$last_push_urls);
        file_put_contents($this->dataPath.self::DS.$host,json_encode($urls));
    }
    function get_nei($host,$urls){
        $arr = [];
        foreach ($urls as $url){
            if(preg_match("/$host/",$url)){
                $arr[] = $url;
            }
        }
        return $arr;
    }
    function get_gl_url($host,$urls){
        $config  = $this->get_config_json();
        $new_arr = [];
        if(preg_match("/#/",$config[$host]['gl'])) {
            $gl_arr = explode("#",$config[$host]['gl']);
            foreach ($gl_arr as $val){
                foreach ($urls as $v){
                    if(preg_match("/".$val."/",$v)){
                        $new_arr[] = $v;
                    }
                }
            }
        }else{
            foreach ($urls as $v){
                if(preg_match("/".$config[$host]['gl']."/",$v)){
                    $new_arr[] = $v;
                }
            }
        }
        
        return $new_arr;
        
    }
    
    //智能推送,分批推送
    function fenPush($host,$urls,$isLog = false){
        $urls = array_unique($urls);
        //内链过滤
        $urls = $this->get_nei($host,$urls);
        
        //去重
        $config  = $this->get_config_json();
        if($config[$host]['is_push_last'] == 1){
            $urls = $this->handle_repeat_urls($host,$urls);
        }
        if(!empty($config[$host]['gl'])){
            $urls = $this->get_gl_url($host,$urls);
        }
        
        if(empty($urls)){
            return "<div class='red'>插件警告:<br>1.推送的链接全部为重复网址或者过滤后无有效网址.<br>2.请尝试修改该域名的[网址去重]和[网址过滤]设置进行调整.</div>";
        }
        
        
        
        $chunk = $this->chunk;
        $msg   = '';
        if(count($urls)>$chunk){
            $msg .= '推送总数:'.count($urls);
            $url_chunk = array_chunk($urls,$chunk);
            $i  =  0;
            foreach ($url_chunk as $value){
                $i ++;
                $msg .= "<br><b>-------------网址数量大于".$chunk.",自动启用分批推送,每批".$chunk."条,当前第".$i."批--------------</b>".$this->push_all($host,$value,true);
            }
        }else{
            $msg = $this->push_all($host,$urls,true);
        }
        
        $msg .= "<br>----------------------------我是分隔线,觉得好的话还请给个五星好评-----------------------------<br>推送网址列表:<br>";
        foreach ($urls as $url ){
            $msg.= $url."<br>";
        }
        $this->write_urls($host,$urls);
        //写入日志
        //$this->log->write_log('手动推送',$host,$urls);
       
        return $msg;
    }
    
    
    //手动推送
    function sdpush(){
        $param =  _post();
        $sd_hosts = $param['sd_hosts'];
        $config  = $this->get_config_json();
        if(empty($param['host']) || empty($sd_hosts)){
            $this->error('请选择域名和输入网址');
        }
        $sd_hosts = trim($sd_hosts);
        $host_config = $config[$param['host']];
        $urls = explode("\n",$sd_hosts);
        $msg = '';
        
        
        $msg = $this->fenPush($param['host'],$urls);
        
        $this->success($msg);
    }
    function baidu_push($host,$urls){
//        $token = $this->config['baidu_token'];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['zhu'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch),true);
    }
    function mip_push($host,$urls){
//        $token = $this->config['baidu_token'];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token."&type=mip";
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['mip'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch),true);
    }
    function sm_push($host,$urls){
//        $token  =  $this->config['sm_token'];
//        $email  =  $this->config['sm_email'];
//        $api = 'http://data.zhanzhang.sm.cn/push?site='.$host.'&user_name='.$email.'&resource_name=mip_add&token='.$token;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['shenma'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    function  xpush($host,$urls){
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['xiong'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    
    function tian($host,$urls){
//        $result = [
//            'success'=>10,
//            'remain'=>9,
//            "success_daily"=>1,
//            "remain_daily"=>9
//        ];
//        return $result;
        $config_json = $this->get_config_json();
        $api =  $config_json[$host]['tian'];
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return  json_decode($result,true);
    }
    
    
    function getlog(){
        $log =  file_get_contents($this->dataPath.'/p.log');
        return $this->success($log);
    }
    //清空日志
    function rmlog(){
        $log =  file_put_contents($this->dataPath.'/p.log','');
        return $this->success();
    }
    //保存host
    function  saveHost(){
        $param = _post();
        if(empty($param['host']) || empty($param['sitemap']) ){
            $this->error('域名或sitemap.xml地址为空');
        }
    }

    //保存host_config
    function save_host_config(){
        $data  = $this->get_config_json();
        $post = $this->trim_arr(_post());
        if(empty($post['zhu'])  || empty($post['host'] )){
            $this->error('【域名】与【百度普通收录API】不能为空');
        }
        if(!empty($post['tian']) && empty($post['xian'])){
            $this->error('百度快速收录必须填写限制数量!');
        }
        if(!empty($post['host']) && !empty($post['zhu']) || !empty($post['bing_token']) || !empty($post['xiong']) || !empty($post['shenma'])  || !empty($post['tian']) ){
            $post['host'] = str_replace(" ",'',$post['host']);
            $post['tian'] = str_replace(" ",'',$post['tian']);
            $post['zhu'] = str_replace(" ",'',$post['zhu']);
            $post['shenma'] = str_replace(" ",'',$post['shenma']);
            $data[$post['host']] = $post;
            $json =  json_encode($data);
            file_put_contents($this->config_json,$json);
            $this->success('新增或修改成功!');
        }
        $this->error('请输入必要数据');
    }


    public function get_pro_config(){
        $config = $this->get_config_json();
        if(!is_array($config) && !empty($config)){
            $this->error('配置文件格式错误！请点击【配置管理】按钮，删除配置！');
        }
        $table = "<table class='table table-hover' >
          <thead>
          <tr><th >域名</th><th width='150'>操作栏【<a class='btlink' onclick='daochu()'>配置管理</a>】</th></tr>
            </thead><tbody>
        ";
        if(!empty($config)){
            $config =  array_reverse($config);
            foreach ($config as $k=>$v){
                $table.= "<tr><td>$k</td><td><button onclick=bianji('".$k."') class='btn btn-primary btn-sm'>编辑</button>&nbsp;<button onclick=del('".$k."') class='btn  btn-sm btn-danger'>删除</button></td></tr>";
            }
        }
        $table .= "</tbody></table>";
        $this->success('success',['table'=>$table]);
    }


    function get_config_json(){
        return json_decode(file_get_contents($this->config_json),true);
    }

    function trim_arr($arr){
        if(empty($arr)){
            return $arr;
        }
        foreach ($arr as &$val){
            $val = trim($val);
        }
        return $arr;
    }

    function bianji(){
        $post = _post();
        $host = trim($post['host']);
        $config = $this->get_config_json();
        $this->success('success',$config[$host]);
    }

    function del(){
        $post = _post();
        $host = trim($post['host']);
        $config = $this->get_config_json();
        if(!empty($host)){
            unset($config[$host]);
            file_put_contents($this->config_json,json_encode($config));
            $this->success('删除成功');
        }
        $this->error();
    }

    function edit(){
        $post = _post();
        $host = trim($post['host']);
        $config = $this->get_config_json();
        $this->success('success',$config[$host]);
    }
    
    
    function  push_all($host,$urls,$is_log = false){
        $config  = $this->get_config_json();
        $host_config = $config[$host];
        //百度普通推送
        $msg = '';
        $log_arr = [];
        if( !empty($host_config['zhu']) ){
            $res =  $this->baidu_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success'])){
                @$msg .= '<a class="btlink big-size">百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</a>';
                $log_arr['baidu'] =  $res;
            }else{
                $log_arr['baidu'] = null;
                $msg .= '<a class="red">百度普通收录推送失败:'.(isset($res['message'])?$res['message']:'').'</a>';
            }
        }
        //百度mip推送
        if( !empty($host_config['mip'])){
            $res =  $this->mip_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success_mip'])){
                if($res['success_mip'] == 0){
                   $msg .= '百度mip推送警告:您百度mip接口没有推送额度';
                }else{
                    @$msg .= '<br><a class="big-size btlink">百度mip推送成功:'.$res['success_mip'].'条,剩余额度'.(int)$res['reamin_mip'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</a>';
                }
            }else{
                $msg .= '<br>百度mip推送失败,'.(isset($res['message'])?$res['message']:'');
            }
        }
        
        //神马推送
        if( !empty($host_config['shenma']) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres['returnCode']==200){
                $msg .= '<br><a class="btlink big-size">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</a>';
                $log_arr['sm'] =  count($urls);
            }else{
                $msg .= '<br><a class="red">神马mip推送失败:配置错误,'.(isset($smres['returnCode'])?$smres['returnCode']:'').'</a>';
                $log_arr['sm'] =  null;
            }
        }

        if(!empty($host_config['tian'])){
            $xian = $host_config['xian'];
            list($offset,$length) = explode('#',$xian);
            $urls = array_slice($urls,$offset,$length);
            $str = "(目标网址从第".$offset."开始,共".$length."条)";
            $tt = $this->tian($host,$urls);
            if(isset($tt['success'])){
                $msg .= '<br><a class="btlink big-size">百度快速收录推送成功:'.$tt['success'].'条'.$str.',剩余'.$tt['remain'].'条</a>';
                $msg .= "<br>快速收录推送目标网址如下:";
                foreach ($urls as $url){
                    $msg .= "<br>".$url;
                }
                if($tt['not_valid']){
                    $msg.= "<a class=btlink big-size>,其中不合法网址".count($tt['not_valid']).'条,网址如下:</a>';
                    foreach ($tt['not_valid'] as $v){
                        $msg .= "<p style='color: red'>".$v."</p>";
                    }
                }
                $log_arr['tian'] =  $tt['success_daily'];
            }else{
                $log_arr['tian'] = null;
                $msg .= '<br>百度快速收录推送失败,API配置错误或者超额 '.(isset($tt['message'])?$tt['message']:'');
            }

        }

        //必应推送
//        if( !empty($host_config['bing_token']) ){
//            $smres =  $this->bing_push($host,$urls);
//            if($smres['returnCode']==200){
//                $msg .= '<br><a class="btlink big-size">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</a>';
//                $log_arr['sm'] =  count($urls);
//            }else{
//                $msg .= '<br><a class="red">神马mip推送失败:配置错误,接口返回'.(isset($smres['returnCode'])?$smres['returnCode']:'').'</a>';
//                $log_arr['sm'] =  null;
//            }
//        }
        
        if(empty($msg)){
            $this->error('至少开启一个推送类型');
        }
        
        if($is_log){
            file_put_contents($this->dataPath.'/p.log',"【手动推送】<br>推送域名:".$host."<br>推送时间:".date('Y-m-d H:i:s')."<br>推送结果:<br>".$msg.'<br>-----------------------------------------------------------------<br>',FILE_APPEND);
            
        }
        //todo 日志需要更详细的记录
        //$this->log->record('手动推送',$host,$log_arr,$urls);
        return $msg;
    }

    /**
     * Notes:  bing_push
     * Author: wenhainan
     * DateTime: 2021/4/23
     * Email: whndeweilai@gmail.com
     */
    function bing_push(){

    }
    
    function about(){
        try{
            @$json = json_decode(file_get_contents('http://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    
    /**
     * @action 快速收录
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/10/12
     */
    function  ks_push_action(){
        $param =  _post();
        $sd_hosts = $param['ks_url'];
        $config  = $this->get_config_json();
        if(empty($param['host']) || empty($sd_hosts)){
            $this->error('请选择域名和输入网址');
        }
        $sd_hosts = trim($sd_hosts);
        $host_config = $config[$param['host']];
        $urls = explode("\n",$sd_hosts);
        $msg = '';
    
        //$msg = $this->fenPush($param['host'],$urls);

        $urls = array_unique($urls);
        $chunk = $this->chunk;
        
        if(empty($host_config['tian'])){
            $this->error('该域名未配置快速推送API，请前往【域名配置】配置该域名的快速推送API');
        }
        
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $host_config['tian'],
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        $result = json_decode($result,true);
        
        if( !empty($result['success']) ){
            $this->success("<b>推送成功【".$result['success']."】条,剩余额度【".$result['remain']."】条</b> <br>快速收录额度珍贵，建议推送重要网址，留意额度消耗！");
        }else{
            $this->error("【超出今日限额】或者【网址与域名不配】，请留意！".$result['message']);
        }
       
    }
    /**
     * des    收录查询
     * auther wenhainan
     * qq     610176732
     * date   2020-10-14
     */
    function slcx_action()
    {
//        $param  =  _post();
//        $keyword = 'site:'.$param['host'];
//        $ql = QueryList::getInstance();
//        $ql->use(Baidu::class);
//        $baidu = $ql->baidu(10);
//        $searcher = $baidu->search($keyword);
//        $count = $searcher->getCount(); // 获取搜索结果总条数
//        $countPage = $searcher->getCountPage();
//        $data = $searcher->setHttpOpt([
//            'headers' => [
//                'User-Agent' => 'testing/1.0',
//                'Accept'     => 'application/json',
//                'X-Foo'      => ['Bar', 'Baz']
//            ],
//            'timeout' => 60,
//        ])->page(1);
//        print_r($data->all());
        $param  =  _post();
        $ql = QueryList::getInstance();
        $ql->use(Baidu::class);
        $keyword = 'site:'.$param['host'];
        $baidu = $ql->baidu(20);
        $searcher = $baidu->search($keyword);
        $count = $searcher->getCount(); // 获取搜索结果总条数
//        $data = $searcher->setHttpOpt([
//            'headers' => [
//                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36 Edg/86.0.622.38',
//            ],
//            'timeout' => 60,
//        ])->page(1,true);
        print_r($count);
    }
    
    function slcx_gen_action(){
        $param =  _post();
        $urls =  [];
        if(empty($param['host']) || empty($param['url_rule'])){
            $this->error('请选择域名或者填写URL规则');
        }
        for($i = 1;$i<=$param['num'];$i++ ){
            $urls[] = $this->gen_url($param['xieyi'],$param['host'],$param['url_rule']);
        }
        $this->success('success',$urls);
    }
    
    function slcx_push_action(){
        $param =  _post();
        $config = $this->get_config_json();
        $sd_hosts = trim($param['slcx_textarea']);
        $host_config = $config[$param['host']];
        $urls = explode("\n",$sd_hosts);
        $msg   =  $this->fenPush($param['host'],$urls,true);
        $this->success($msg);
    }

    /**
     * des    测试加入日志方法
     * func   write_log
     * auther <闻海南>whndeweilai@163.com/610176732
     * date   2020/10/27
     * @throws Exception
     */
    function write_log(){
        $urls = [1,2,3];
        $res =  $this->log->write_log('自动推送','www',$urls);
    }

    /**
     * des    获取插件
     * func   get_plugin_path
     * auther <闻海南>whndeweilai@163.com/610176732
     * date   2020/10/27
     */
    public function get_php_path(){
        $php_version = PHP_VERSION;
        $php_version = str_replace('.','',$php_version);
        $php_version = substr($php_version,0,2);

        if(PHP_OS == 'Linux'){
            $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
        }
//        if(PHP_OS == 'Linux'){
//            $php_path = PLU_PATH."/../../../php/71/bin/php";
//        }else{
//            $php_path = PLU_PATH."/../../../php/71/php.exe";
//        }

//        $this->json([
//            'path'=>$this->ds_file,
//            'dir'=> PLU_PATH,
//            'php_path'=>$php_path
//        ]);
        return $php_path;
    }
    
    public function get_config_content()
    {
        $file_content =  $this->config_json;
        $content = file_get_contents($file_content);
        
        $this->success('success',['content'=>$content,'file_path'=>'/urlpush/static/config.json'  ]);
    }
    
    /**
     * @action 写入配置
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/11/15
     */
    public  function wconfig()
    {
        try {
            $param  = $this->post;
            $msg = "写入成功";
            if(empty($param['content'])){
                $msg = "已初始化配置！";
            }
            file_put_contents($this->config_json,$param['content']);
            $this->success($msg,[
                'content'=>$param['content']
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
       
    }
}


?>