<?php
class  Common {
    function gen_url($xieyi,$host,$url_rule){
        while(strstr($url_rule,'{字母}')){
            $randstr = $this->rand_str();
            $url_rule = preg_replace('/{字母}/',$randstr,$url_rule,1);
        }
        while(strstr($url_rule,'{数字}')){
            $randstr = $this->rand_num();
            $url_rule = preg_replace('/{数字}/',$randstr,$url_rule,1);
        }
        while(strstr($url_rule,'{日期}')){
            $randstr = date('Ymd');
            $url_rule = preg_replace('/{日期}/',$randstr,$url_rule,1);
        }
        
        return $xieyi.$host.$url_rule."\n";
    }
    public function rand_str($lenth = 3){
        $chars    = 'abcdefghijklmnopqrstuvwxyz';
        $password = '';
        for ($i = 0; $i < $lenth; $i++) {
            $password .= $chars[mt_rand(0, strlen($chars) - 1)];
        }
        return $password;
    }
    public function rand_num(){
        return  rand(100,999);
    }
}
