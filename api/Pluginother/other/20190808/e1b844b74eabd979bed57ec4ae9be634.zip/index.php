<?php
//宝塔Linux面板插件demo for PHP
//@author 阿良<287962566@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：["56","71","72","73"]，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节
class bt_main
{
    //不允许被面板访问的方法请不要设置为公有方法

    public function portblast()
    {
        $ip = _post('ip');
        $dk = _post('dk');
        if($ip==''||$dk==''){
            return ['state'=>'0'];
        }
        //IP拆分为数组之后判断是否为正确的IP
        $ips = explode(".", $ip);

        if (intval($ips[0]) < 1 or intval($ips[0]) > 255 or intval($ips[3]) < 1 or intval($ips[3] > 255)) {
            return ['state'=>'0'];
        }

        if (intval($ips[1]) < 0 or intval($ips[1]) > 255 or intval($ips[2]) < 0 or intval($ips[2] > 255)) {
            return ['state'=>'0'];
        }

        $fp = @fsockopen($ip, $dk, $errno, $errstr, 1); //打开数据流

        if (!$fp) {
            //如果打开出错
            $arr = array('ip' => $ip, 'dk' => $dk, 'state' => '0');
            return $arr; //输出内容
        } else {
            //如果成功打开
            $arr = array('ip' => $ip, 'dk' => $dk, 'state' => '1');
            fclose($fp);
            return $arr;
        }
    }

    /**
     * 获取IP
     * @Author   Youngxj
     * @DateTime 2019-08-08
     * @return   [type]     [description]
     */
    public function getip(){
        $unknown = '127.0.0.1';
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown)) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown)) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        $ip = preg_match("/[\d\.]{7,15}/", $ip, $matches) ? $matches[0] : $unknown;
        if (false !== strpos($ip, ',')) {
            $ip = reset(explode(',', $ip));
        }

        return $ip;
    }

}
