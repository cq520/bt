CREATE TABLE "project" (
	"id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
	"title" TEXT,
	"info" TEXT,
	"branch" TEXT,
	"project_path" TEXT,
	"exclude" TEXT,
	"repository" TEXT,
	"deploy_shell" TEXT,
	"webhooks_url" TEXT,
	"webhooks_password" TEXT,
	"webhooks_types" TEXT,
	"webhooks_status" INTEGER DEFAULT 0,
	"add_time" INTEGER DEFAULT 0,
	"update_time" INTEGER DEFAULT 0
);

CREATE TABLE "sshkeys" (
	"id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
	"title" TEXT,
	"info" TEXT,
	"key" TEXT,
	"add_time" INTEGER DEFAULT 0,
	"update_time" INTEGER DEFAULT 0
);