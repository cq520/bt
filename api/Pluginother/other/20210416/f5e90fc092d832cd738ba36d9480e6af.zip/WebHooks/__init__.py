#!/usr/bin/python
# coding: utf-8

import sys,json,os,string,time,logging,re
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
panel_path = os.path.dirname(os.path.dirname(plugin_path))
os.chdir(panel_path);

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db,time

from flask import Flask,request
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def webhooks():
    deploy_shell_path = '/www/server/git_repository_deploy'
    data = {}
    data.update(request.form.to_dict())
    data.update(request.args.to_dict())
    # print(data)

    return_data = {
        "status":0,
        "msg":"操作失败",
    }

    id = data.get('id')
    project_config_file = "%s/%s.conf" % (deploy_shell_path,id)
    # print(project_config_file)
    if not os.path.exists(project_config_file):
        return_data["msg"] = "项目配置文件不存在"
        return json.dumps(return_data)

    projectData = public.ReadFile(project_config_file)
    
    if projectData == False or projectData == '':
        return_data["msg"] = "读取项目配置文件失败"
        return json.dumps(return_data)

    projectData = json.loads(projectData)
    # print(projectData)

    if len(projectData) == 0:
        return_data["msg"] = "项目配置文件格式不正确"
        return json.dumps(return_data)

    # print(request.headers)
    # print(request.data)

    if 'User-Agent' in request.headers:
        UserAgent = request.headers.get('User-Agent')
    else:
        UserAgent = []

    # 判断平台
    if 'GitHub-Hookshot' in UserAgent:
        print('github')
        import hashlib
        import hmac
        sha1_sign = hmac.new(projectData['webhooks_password'].encode("utf-8"), request.data.decode("utf-8").encode("utf-8"), hashlib.sha1).hexdigest()
        # print(sha1_sign)
        sign_parts = request.headers.get('X-Hub-Signature').split("=", 1)
        if projectData['webhooks_password'] == '' or  len(sign_parts) < 2 or sign_parts[0] != "sha1" or sha1_sign != sign_parts[1]:
            return_data["msg"] = "秘钥校验失败"
            return json.dumps(return_data)
        print("秘钥校验成功")

        if request.headers.get('X-Github-Event') != 'push':
            return_data["msg"] = "事件类型校验失败"
            return json.dumps(return_data)
        print("事件类型校验成功")

        if not request.json.get('ref').endswith('/'+projectData['branch']):
            return_data["msg"] = "分支校验失败"
            return json.dumps(return_data)
        print("分支校验成功")

    elif 'git-oschina-hook' in UserAgent:
        print('gitee')
        if projectData['webhooks_password'] == '' or projectData['webhooks_password'] != request.json.get('password'):
            return_data["msg"] = "秘钥校验失败"
            return json.dumps(return_data)
        print("秘钥校验成功")

        if request.headers.get('X-Gitee-Event') == 'Push Hook':
            if not request.json.get('ref').endswith('/'+projectData['branch']):
                return_data["msg"] = "分支校验失败"
                return json.dumps(return_data)
            print("分支校验成功")
        elif request.headers.get('X-Gitee-Event') == 'Merge Request Hook':
            if request.json.get('target_branch') != projectData['branch']:
                return_data["msg"] = "分支校验失败"
                return json.dumps(return_data)
            print("分支校验成功")
        else:
            return_data["msg"] = "事件类型校验失败"
            return json.dumps(return_data)
        print("事件类型校验成功")

    elif 'Coding.net Hook' in UserAgent:
        print('coding')
        import hashlib
        import hmac
        sha1_sign = hmac.new(projectData['webhooks_password'].encode("utf-8"), request.data.decode("utf-8").encode("utf-8"), hashlib.sha1).hexdigest()
        # print(sha1_sign)
        sign_parts = request.headers.get('X-Coding-Signature').split("=", 1)
        if projectData['webhooks_password'] == '' or  len(sign_parts) < 2 or sign_parts[0] != "sha1" or sha1_sign != sign_parts[1]:
            return_data["msg"] = "秘钥校验失败"
            return json.dumps(return_data)
        print("秘钥校验成功")

        if request.headers.get('X-Coding-Event') != 'push':
            return_data["msg"] = "事件类型校验失败"
            return json.dumps(return_data)
        print("事件类型校验成功")

        if not request.json.get('ref').endswith('/'+projectData['branch']):
            return_data["msg"] = "分支校验失败"
            return json.dumps(return_data)
        print("分支校验成功")

    else:

        if 'X-Gitea-Event' in request.headers:
            if request.json.get('secret') != projectData['webhooks_password']:
                return_data["msg"] = "秘钥校验失败"
                return json.dumps(return_data)
            print("秘钥校验成功")

            if request.headers.get('X-Gitea-Event') != 'push':
                return_data["msg"] = "事件类型校验失败"
                return json.dumps(return_data)
            print("事件类型校验成功")

            if not request.json.get('ref').endswith('/'+projectData['branch']):
                return_data["msg"] = "分支校验失败"
                return json.dumps(return_data)
            print("分支校验成功")

        elif 'X-Gitlab-Event' in request.headers:

            if request.headers.get('X-Gitlab-Token') != projectData['webhooks_password']:
                return_data["msg"] = "秘钥校验失败"
                return json.dumps(return_data)
            print("秘钥校验成功")

            if request.headers.get('X-Gitlab-Event') != 'Push Hook':
                return_data["msg"] = "事件类型校验失败"
                return json.dumps(return_data)
            print("事件类型校验成功")

            if not request.json.get('ref').endswith('/'+projectData['branch']):
                return_data["msg"] = "分支校验失败"
                return json.dumps(return_data)
            print("分支校验成功")

        else:
            if not 'key' in data or data.get('key') != projectData['webhooks_password']:
                return_data["msg"] = "秘钥校验失败"
                return json.dumps(return_data)

    # 执行部署脚本
    deploy_shell = "%s/%s.sh" % (deploy_shell_path,projectData['id'])
    if not os.path.exists(deploy_shell):
        return_data["msg"] = "部署脚本不存在"
        return json.dumps(return_data)
    os.system('chmod +x %s' % deploy_shell)
    os.system(deploy_shell)

    return_data = {
        "status":1,
        "msg":"操作成功",
    }

    return json.dumps(return_data)